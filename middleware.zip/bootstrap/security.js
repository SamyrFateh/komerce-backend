'use strict';

const cors = require('cors');
const helmet = require('helmet');

function isAllowedOrigin(origin, frontendUrl = process.env.FRONTEND_URL || '', allowedOrigins = process.env.ALLOWED_ORIGINS || '') {
  if (!origin) return true;
  if (/^https?:\/\/localhost(:\d+)?$/.test(origin)) return true;
  if (frontendUrl && origin === frontendUrl) return true;
  if (allowedOrigins) {
    const allowed = allowedOrigins.split(',').map(s => s.trim()).filter(Boolean);
    if (allowed.includes(origin)) return true;
  }
  return false;
}

function buildCorsOptions() {
  return {
    origin: (origin, callback) => {
      if (isAllowedOrigin(origin)) {
        callback(null, true);
      } else {
        callback(new Error(`Not allowed by CORS: ${origin}`));
      }
    },
    methods:     ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    credentials: true,
  };
}

function buildHelmetOptions() {
  return {
    contentSecurityPolicy: {
      directives: {
        defaultSrc:  ["'self'"],
        scriptSrc:   ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com", "https://unpkg.com", "https://cdn.jsdelivr.net", "https://js.stripe.com"],
        styleSrc:    ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc:     ["'self'", "https://fonts.gstatic.com", "https://cdnjs.cloudflare.com", "data:"],
        imgSrc:      ["'self'", "data:", "https:", "http:"],
        connectSrc:  ["'self'", "https://fonts.googleapis.com", "https://fonts.gstatic.com", "https://cdnjs.cloudflare.com", "https://unpkg.com", "https://cdn.jsdelivr.net", "https://api.stripe.com"],
        frameSrc:    ["'self'", "https://js.stripe.com", "https://hooks.stripe.com"],
        mediaSrc:    ["'self'"],
        objectSrc:   ["'none'"],
        frameAncestors: ["'none'"],
        baseUri:     ["'self'"],
        formAction:  ["'self'"],
        scriptSrcAttr: ["'unsafe-inline'"],
      },
    },
  };
}

function applySecurity(app) {
  app.use(helmet(buildHelmetOptions()));
  app.use(cors(buildCorsOptions()));
}

module.exports = {
  isAllowedOrigin,
  buildCorsOptions,
  buildHelmetOptions,
  applySecurity,
};
