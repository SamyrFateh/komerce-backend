/**
 * KOMERCE — Order Service v2.0
 *
 * Helpers commandes : références, codes, wallet.
 * v2.0 : wallet remplace store_credits.
 */

'use strict';

const { randomBytes }   = require('crypto');
const walletService     = require('./wallet-service');

// ─── Génération de références ──────────────────────────────────────────────────

function generateRef() {
  const chars  = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const result = [];
  while (result.length < 6) {
    const byte = randomBytes(1)[0];
    if (byte < 252) result.push(chars[byte % 36]);
  }
  return 'K' + result.join('');
}

async function getUniqueRef(db) {
  for (let attempt = 0; attempt < 5; attempt++) {
    const ref      = generateRef();
    const { rows } = await db.query('SELECT id FROM orders WHERE reference = $1', [ref]);
    if (!rows.length) return ref;
  }
  throw new Error('Impossible de générer une référence unique après 5 tentatives');
}

function generateCashCode() {
  const digits = [];
  while (digits.length < 6) {
    const b = randomBytes(1)[0];
    if (b < 250) digits.push(b % 10);
  }
  return digits.join('');
}

function generatePickupCode() {
  const PICKUP_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  return Array.from({ length: 6 }, () => {
    let b;
    do { b = randomBytes(1)[0]; } while (b >= 216);
    return PICKUP_CHARS[b % 36];
  }).join('');
}

// ─── Wallet balance (remplace store_credits) ─────────────────────────────────

async function getAvailableCredits(dbOrClient, userId) {
  const balance = await walletService.getBalance(userId);
  return { total_kmf: balance };
}

module.exports = {
  generateRef,
  getUniqueRef,
  generateCashCode,
  generatePickupCode,
  getAvailableCredits,
};
