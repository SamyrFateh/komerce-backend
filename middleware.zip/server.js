/**
 * KOMERCE — Serveur API v12.4 (Cash reconciliation + Inventory proposals + Transitaire)
 *
 * Point d'entrée Node.js + Express
 * Déployé sur Railway — PORT fourni par la variable d'environnement
 *
 * Changelog v11.2: Parcel-First API v2 (routes/parcel-api-v2.js) — refonte COLIS-FIRST
 * Changelog v10.18: routes/invoices.js ajouté (mini-facture client)
 * Changelog v10.15: routes/transit-dashboard.js ajouté (parcel-first)
 * Changelog v10.14: routes/hub-dashboard.js ajouté, hub.html
 * Changelog v10.13: routes/relay-dashboard.js ajouté, suivi.html exempté auth-guard
 * Changelog v10.12: F34 stock constraint garantit admin au démarrage
 */

const { loadAndValidateEnv } = require('./bootstrap/env');
loadAndValidateEnv();

const log          = require('./utils/logger').child({ module: 'server' });
const express      = require('express');
const cookieParser = require('cookie-parser');
const path         = require('path');
const db           = require('./db');

const {
  globalLimiter,
  authLimiter,
  cashConfirmLimiter,
  scanCollectLimiter,
  orderCreateLimiter,
  dashboardLimiter,
  adminLimiter,
} = require('./middleware/rate-limit');

const { fixAdminHash, fixMissingSchema } = require('./scripts/fix-schema');
const { runAllSeeds }                     = require('./scripts/seed');
const { errorHandler } = require('./middleware/error-handler');
const { requestIdMiddleware } = require('./middleware/request-id');

const app = express();

app.set('trust proxy', 1);

app.get('/webhook/authkey-whatsapp', async (req, res) => {
  try {
    log.info('[AUTHKEY-WA][WEBHOOK]', req.query);

    const mobile = req.query.Mobile || null;
    const email = req.query.Email || null;
    const status = req.query.Status || null;
    const logId = req.query['Log ID'] || req.query.LogID || req.query.log_id || null;
    const time = req.query.Time || null;

    return res.status(200).send('OK');
  } catch (e) {
    log.error('[AUTHKEY-WA][WEBHOOK][ERROR]', e.message);
    return res.status(500).send('ERROR');
  }
});

const { applySecurity } = require('./bootstrap/security');



// ── Security headers + CORS ───────────────────────────────────────────────
applySecurity(app);

// ── Stripe webhook MUST receive raw body for signature verification ──────────
app.use('/api/payments/stripe/webhook', express.raw({ type: 'application/json' }));
app.use('/api/shared-carts/stripe/webhook', express.raw({ type: 'application/json' }));
app.use('/api/collective-payments/stripe/webhook', express.raw({ type: 'application/json' }));

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use(cookieParser());
app.use(requestIdMiddleware);

// ── Rate limiting ────────────────────────────────────────────────────────────

app.use('/api/', globalLimiter);
app.use('/api/auth/login', authLimiter);
app.use('/api/auth/register', authLimiter);
app.use('/api/payments/cash/confirm', cashConfirmLimiter);
app.use('/api/scans/collect', scanCollectLimiter);
app.use('/api/orders', (req, res, next) => {
  if (req.method === 'POST' && req.path === '/') {
    return orderCreateLimiter(req, res, next);
  }
  next();
});
app.use('/api/dashboard', dashboardLimiter);
app.use('/api/admin/', adminLimiter);


// ── Auth guard injection — auto-injects session checker into admin pages ────
const _fs = require('fs');
app.get('/*.html', (req, res, next) => {
  if (req.path.includes('Boutique') || req.path === '/boutique.html' || req.path === '/portal.html' || req.path === '/suivi.html' || req.path === '/mon-compte.html') return next();
  const filePath = path.join(__dirname, 'public', req.path);
  _fs.readFile(filePath, 'utf8', (err, html) => {
    if (err) return next();
    html = html.replace('</body>', '<script src="/js/auth-guard.js"></script>\
</body>');
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.send(html);
  });
});

app.use(express.static(path.join(__dirname, 'public'), {
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.html')) {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
    }
  }
}));

// ── Routes API ────────────────────────────────────────────────────────────

const {
  mountApiRoutesBeforeStripeOwnedBlocks,
  mountApiRoutesAfterStripeOwnedBlocks,
} = require('./bootstrap/api-routes');
const { mountHtmlRoutes } = require('./bootstrap/html-routes');

const walletService    = require('./services/wallet-service');
const routingService   = require('./services/routing');
const parcelSecurity   = require('./services/parcel-security');
const sharedCart = require('./routes/shared-cart');
const sharedCartRefundAdmin = require('./routes/shared-cart-refund-admin');

mountApiRoutesBeforeStripeOwnedBlocks(app);

// ═══ Panier Partagé MVP (Niveau 1) ═══
app.post('/api/shared-carts/stripe/webhook', sharedCart.stripeWebhookHandler);
app.use('/api/shared-carts',       sharedCart.router);
app.use('/api/admin/shared-carts', sharedCartRefundAdmin.router);
app.use('/api/admin/shared-carts', sharedCart.adminRouter);

// ═══ Panier Événement Collectif V1 ═══
const collectiveWS = require('./routes/collective-workspaces');
const collectivePaymentOrchestrator = require('./services/collective-payment-orchestrator');
app.post('/api/collective-payments/stripe/webhook', collectiveWS.stripeWebhookHandler);
app.use('/api/collective-workspaces', collectiveWS.router);
app.use('/api/collective-payments',   collectiveWS.paymentsRouter);
if (process.env.NODE_ENV !== 'test') {
  const intervalMs = process.env.NODE_ENV === 'production' ? 5 * 60 * 1000 : 30 * 1000;
  collectivePaymentOrchestrator.startExpirationCron(intervalMs);
}
mountApiRoutesAfterStripeOwnedBlocks(app);


// ── Healthcheck ─────────────────────────────────────────────────────────────

app.get('/api/health', async (req, res) => {
  try {
    const start = Date.now();
    await db.query('SELECT 1');
    res.json({
      status:        'ok',
      version:       '12.3',
      db_latency_ms: Date.now() - start,
      timestamp:     new Date().toISOString(),
      env:           process.env.NODE_ENV || 'development',
    });
  } catch {
    res.status(503).json({ status: 'degraded', db: 'unreachable' });
  }
});

// ── Public config ─────────────────────────────────────────────
app.get('/api/public/config', (req, res) => {
  res.setHeader('Cache-Control', 'public, max-age=300');
  res.json({
    stripe_public_key: process.env.STRIPE_PUBLIC_KEY || process.env.STRIPE_PK || '',
    eur_kmf_rate:      Number(process.env.EUR_KMF_RATE)  || 492,
    aed_kmf_rate:      Number(process.env.AED_KMF_RATE)  || 138,
    whatsapp_number:   process.env.SUPPORT_WHATSAPP    || '',
    support_email:     process.env.SUPPORT_EMAIL       || '',
    env:               process.env.NODE_ENV || 'development',
  });
});

// ── HTML routes / SPA fallback ─────────────────────────────────────────────
mountHtmlRoutes(app, __dirname);

app.use(errorHandler);

// ── Operational crons ───────────────────────────────────────────────────────
const { startOperationalCrons } = require('./bootstrap/crons');
startOperationalCrons();
const { runStartupMigrations } = require('./bootstrap/startup-migrations');

// ── Server lifecycle ────────────────────────────────────────────────────────
const { startServerLifecycle } = require('./bootstrap/server-lifecycle');
startServerLifecycle({
  app,
  db,
  walletService,
  routingService,
  parcelSecurity,
  runStartupMigrations,
  fixAdminHash,
  fixMissingSchema,
  runAllSeeds,
});
module.exports = app;
