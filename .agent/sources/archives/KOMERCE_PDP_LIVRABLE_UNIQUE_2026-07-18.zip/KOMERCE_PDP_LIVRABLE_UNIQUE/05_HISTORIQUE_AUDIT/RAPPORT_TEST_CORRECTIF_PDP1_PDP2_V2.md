# Rapport de test pré-merge — correctif PDP-1 / PDP-2 (V2)

**Archive contrôlée :** `pdp1-pdp2-suite-correctif.zip`  
**Date du contrôle :** 18 juillet 2026  
**Décision :** **NE PAS MERGER EN L’ÉTAT**

## 1. Synthèse exécutive

Le correctif répare réellement plusieurs défauts du premier audit :

- la règle CSS `[hidden]` fonctionne dans le style calculé ;
- la machine d’état partagée du footer produit est correcte lorsqu’elle est appelée ;
- les trois états mobile sont compacts, exclusifs et sur une seule ligne ;
- la canonicalisation de l’identité de ligne panier fonctionne dans son module dédié ;
- la composition desktop trois colonnes est bien présente et compacte ;
- le bouton **Me prévenir** est honnêtement désactivé et annoncé comme fonctionnalité à venir.

Cependant, deux régressions d’intégration bloquent toujours le merge :

1. **La machine d’état corrigée n’est pas branchée aux renderers réels mobile et desktop.**  
   `renderPdpActions()` et `syncBuyboxActions()` existent et passent les tests isolés, mais aucun renderer produit ne les appelle. Les deux renderers utilisent à nouveau leur ancienne fonction locale `renderActions()`.

2. **Le panier a perdu le câblage par `line_id` déjà présent dans la livraison précédente.**  
   L’ajout, le tiroir panier et le side-cart redeviennent partiellement pilotés par le seul `product.id`. Deux variantes d’un même produit peuvent donc être confondues, incrémentées ou supprimées sur la mauvaise ligne.

Ces défauts sont des problèmes d’intégration réels, pas des écarts esthétiques.

---

## 2. Périmètre et méthode

Contrôles réalisés :

- intégrité et sécurité de l’archive ZIP ;
- vérification syntaxique JavaScript ;
- validation structurelle HTML ;
- contrôle des imports/exports livrés ;
- tests unitaires autonomes sur les modules d’identité panier et d’état de CTA ;
- exécution Chromium synthétique avec le CSS réellement livré ;
- exécution de la fonction réelle `syncBuyboxActions()` dans Chromium ;
- inspection du chemin d’appel des renderers mobile/desktop ;
- comparaison avec la livraison PDP-1 → PDP-2 précédemment auditée ;
- inspection des mutations du panier dans le drawer et le side-cart.

La suite complète annoncée à **1 765 tests** n’est pas certifiable depuis cette archive différentielle seule : elle ne contient ni le dépôt complet ni ses dépendances installées.

---

## 3. Contrôles validés

### 3.1 Archive et structure

- 31 entrées ;
- aucun chemin dangereux ou traversée de répertoire ;
- extraction réussie ;
- 14 fichiers JavaScript livrés : `node --check` réussi pour chacun ;
- HTML : 100 identifiants, 100 uniques, aucun doublon ;
- balises équilibrées ;
- versions de cache CSS cohérentes avec l’état livré.

### 3.2 Correction CSS `[hidden]`

La correction est effective dans Chromium : un élément portant `hidden` obtient bien `display: none` dans le style calculé.

Les états isolés donnent :

| État | Éléments visibles | Hauteur footer | Même ligne |
|---|---|---:|---|
| Sélection requise | Ajouter + Acheter, désactivés | 69 px | Oui |
| Panier vide | Ajouter + Acheter | 69 px | Oui |
| Produit déjà au panier | Stepper + Acheter | 69 px | Oui |
| Rupture | Me prévenir uniquement | 69 px | Oui |

Tests effectués sur 360×800, 375×812, 390×844 et 430×932, sans scroll horizontal.

### 3.3 Machine d’état partagée

La fonction réelle `syncBuyboxActions()` a été exécutée avec les modules corrigés. Les quatre scénarios produisent le bon `data-cart-state`, les bons attributs `hidden` et les bons styles calculés.

**Conclusion isolée :** le module partagé est correct.

### 3.4 Identité panier — module dédié

Les tests autonomes confirment :

- ordre des clés canonicalisé ;
- deux combinaisons logiquement identiques produisent la même clé ;
- deux variantes différentes restent distinctes ;
- `lineIdOf()` et `findCartLineById()` résolvent la ligne exacte.

**Conclusion isolée :** `cart-line-identity.js` est correct.

### 3.5 Desktop

Le CSS et le rendu synthétique livrés valident :

- modal centrée et plafonnée ;
- trois colonnes : miniatures / image / panneau commercial ;
- quatre emplacements de miniatures avec tuile `+N` ;
- compteur visible ;
- agrandissement visible sous forme d’icône ;
- CTA dans la colonne droite ;
- aucun débordement horizontal aux largeurs testées.

Exemples mesurés :

- 1024 px : `84px / 464px / 380px` ;
- 1440 px : `84px / 676px / 380px`.

---

## 4. Blocant n°1 — machine d’état non branchée aux renderers réels

### Constat

Le fichier partagé exporte bien :

- `syncBuyboxActions()` ;
- `renderPdpActions()`.

Mais aucun renderer réel ne les utilise.

#### Mobile

Dans `b-modal-mobile-product.js` :

- ligne 53 : seul `getCurrentPrice` est importé depuis le module partagé ;
- ligne 319 : une fonction locale `renderActions(detail, selection)` est redéfinie ;
- ligne 579 : le renderer appelle cette fonction locale.

Cette fonction locale :

- active ou désactive seulement Ajouter/Acheter ;
- ne pilote pas `hidden` ;
- ne fixe pas `data-cart-state` ;
- ne distingue pas `empty`, `filled` et `out-of-stock` ;
- ne pilote pas le bouton Me prévenir.

#### Desktop

Dans `b-modal-desktop-product.js` :

- ligne 30 : `renderPdpActions` n’est pas importé ;
- ligne 142 : l’ancienne fonction locale `renderActions()` est présente ;
- ligne 534 : elle est appelée à la place de la fonction partagée.

### Preuve de régression

Dans la combinaison précédente PDP-1 → PDP-2, les deux renderers importaient et appelaient `renderPdpActions()`. L’archive corrective a réintroduit les anciennes fonctions locales.

Autrement dit : **le code corrigé existe, mais il est devenu du code mort dans le parcours réel de la PDP.**

### Risque utilisateur

Le shell HTML initialise quantité, Ajouter et Acheter. Comme le renderer réel ne synchronise pas les états partagés, la PDP peut conserver une composition incohérente ou seulement désactiver certains contrôles sans appliquer les trois états exclusifs validés.

### Correctif requis

Dans les deux renderers :

```js
import { getCurrentPrice, renderPdpActions } from './b-modal-buybox-shared.js';
```

Puis :

```js
renderPdpActions(detail, selection);
```

Supprimer les deux fonctions locales `renderActions()` pour empêcher toute divergence future.

### Test d’intégration requis

Ne pas tester uniquement `syncBuyboxActions()` en isolation. Ajouter un test qui appelle réellement :

- `renderMobileProductDetail()` ;
- `renderDesktopProductDetail()` ;

puis vérifie `hidden`, `data-cart-state` et `getComputedStyle()` sur les CTA.

---

## 5. Blocant n°2 — régression de l’identité des lignes dans le panier réel

### 5.1 Ajout au panier encore sensible à l’ordre des clés

Dans `b-cart.js`, lignes 198 à 201 :

```js
const existing = state.cart.find(i =>
  String(i.product?.id ?? i.id) === String(product.id)
  && JSON.stringify(i.variant_combo || null) === JSON.stringify(combo)
);
```

Le module canonicalisé existe, mais `addToCart()` ne l’utilise pas.

Conséquence :

```js
{ Couleur: 'Rouge', Taille: '44' }
{ Taille: '44', Couleur: 'Rouge' }
```

peuvent encore être considérés comme deux lignes différentes.

La livraison précédente utilisait déjà :

```js
const lineId = computeLineId(product, combo);
const existing = findCartLineById(state.cart, lineId);
```

Cette correction a été perdue dans le nouveau ZIP.

### 5.2 Tiroir panier piloté par `product.id`

Les boutons du drawer utilisent encore :

- ligne 631 : `setQty(p.id, ...)` ;
- ligne 642 : `setQty(p.id, ...)` ;
- ligne 662 : `removeFromCart(p.id)`.

Avec deux variantes du même produit, ces fonctions résolvent le premier produit correspondant et peuvent modifier la mauvaise ligne.

### 5.3 Side-cart piloté par `data-pid`

Le side-cart génère uniquement `data-pid` et recherche :

```js
state.cart.find(i => String(i.product?.id ?? i.id) === pid)
```

Il n’y a plus de `data-line-id`. Les actions `+`, `−` et supprimer peuvent donc cibler la mauvaise variante.

### 5.4 Badge potentiellement obsolète après suppression par ligne

`setCartLineQty()` appelle `updateCartBadge()`, mais `removeCartLine()` ne le fait pas. Une décrémentation de 1 vers 0 via la voie `line_id` peut laisser le badge du header obsolète.

### Correctif requis

Restaurer le câblage déjà présent dans la livraison précédente :

- importer `computeLineId`, `lineIdOf`, `findCartLineById` ;
- utiliser `computeLineId()` et `findCartLineById()` dans `addToCart()` ;
- conserver/stocker le `line_id` canonicalisé ;
- utiliser `lineIdOf(item)` dans le drawer ;
- générer `data-line-id` dans le side-cart ;
- résoudre les clics par `line_id`, jamais par le seul `product.id` ;
- appeler `updateCartBadge()` dans `removeCartLine()`.

### Tests requis

1. Ajouter deux fois la même combinaison avec les clés dans un ordre différent → une seule ligne, quantité incrémentée.
2. Mettre deux variantes du même produit au panier → `+` du drawer ne modifie que la ligne visée.
3. Même test pour `−` et suppression.
4. Même couverture dans le side-cart.
5. Décrémenter une ligne de 1 à 0 → badge header mis à jour immédiatement.

---

## 6. Point A2 — Me prévenir

Le bouton est désormais livré avec :

- `disabled` ;
- `aria-disabled="true"` ;
- un titre indiquant que la fonctionnalité est à venir.

C’est acceptable comme état transitoire : le système ne prétend plus offrir une action fonctionnelle inexistante.

Il faudra cependant décider avant mise en production si une rupture doit :

- afficher ce bouton désactivé ;
- ou masquer entièrement l’action tant que la collecte de notification n’existe pas.

Ce point n’est plus le blocant principal du merge technique.

---

## 7. Tests manquants dans la livraison

Le test `b-modal-buybox-shared-cart-state.test.js` valide le module partagé, mais pas son utilisation par les renderers.

Les tests actuels peuvent donc être verts tout en laissant le parcours réel sur l’ancien code.

Il manque au minimum :

- un test de liaison renderer → `renderPdpActions()` ;
- un test DOM complet mobile ;
- un test DOM complet desktop ;
- des tests multi-variantes sur le drawer ;
- des tests multi-variantes sur le side-cart ;
- un test d’ajout canonicalisé via la vraie fonction `addToCart()`.

---

## 8. Décision pré-merge

### Validé

- archive saine ;
- syntaxe ;
- HTML ;
- CSS `[hidden]` ;
- machine d’état partagée en isolation ;
- identité canonicalisée en isolation ;
- composition visuelle mobile ;
- composition visuelle desktop ;
- bouton Me prévenir non trompeur.

### Non validé / bloquant

- renderers réels non reliés à la machine d’état partagée ;
- régression de `addToCart()` vers `JSON.stringify()` brut ;
- drawer encore muté par `product.id` ;
- side-cart encore muté par `product.id` ;
- badge non mis à jour dans `removeCartLine()` ;
- absence de tests d’intégration capables de détecter ces régressions.

## Verdict final

> **NE PAS MERGER `pdp1-pdp2-suite-correctif.zip` en l’état.**

Le correctif visuel et les modules isolés sont bons, mais l’archive a été reconstruite avec des versions plus anciennes de plusieurs fichiers d’intégration. Il faut réappliquer les correctifs sur une base unique et conserver les versions avancées déjà présentes dans la livraison précédente.

Après correction, la prochaine validation devra porter sur le ZIP complet résultant — pas seulement sur les fichiers isolés — avec les renderers réels et deux variantes du même produit dans le panier.

---

## 9. Artifacts de contrôle

- Résultats Chromium des états isolés : `browser-results.json`
- Exécution de la fonction réelle partagée : `actual-state-machine.json`
- Audit statique du câblage : `integration-linkage-results.json`
- Captures : mobile empty, mobile filled, mobile rupture, desktop 1024 et desktop 1440.
