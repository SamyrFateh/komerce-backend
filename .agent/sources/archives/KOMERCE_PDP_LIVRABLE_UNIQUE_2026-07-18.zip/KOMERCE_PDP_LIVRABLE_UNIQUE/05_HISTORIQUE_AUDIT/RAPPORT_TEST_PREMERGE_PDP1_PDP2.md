# Rapport de test pré-merge — PDP-1 / PDP-2

Date : 18 juillet 2026

## Verdict

**NE PAS MERGER EN L'ÉTAT.**

L'ordre d'intégration correct est **PDP-1 puis PDP-2**. La superposition des deux archives est cohérente et PDP-2 conserve les changements de PDP-1, mais deux défauts bloquants subsistent dans la barre d'achat mobile.

## Contrôles effectués

- Intégrité des deux archives ZIP : OK
- Superposition PDP-1 → PDP-2 : OK
- Analyse syntaxique des 19 fichiers JavaScript livrés : OK
- Analyse des sources CSS livrées : OK
- Parsing HTML et recherche d'IDs dupliqués : OK — 100 IDs, aucun doublon
- Tests unitaires ciblés exécutables depuis la livraison : **32/32 OK**
- Scénarios supplémentaires de machine d'état panier : **12 scénarios attendus OK**
- Tests navigateur Chromium synthétiques : 360, 375, 390, 430, 900, 1024, 1440 et 1920 px
- Vérification de l'absence de scroll horizontal : OK sur les viewports testés
- Hero mobile à 240 px : OK
- Structure desktop en trois colonnes : OK techniquement

## Bloquants

### B1 — L'attribut `hidden` ne masque pas les actions

Le JavaScript positionne correctement `hidden = true`, mais les règles CSS `display:flex` restent prioritaires pour :

- `.k-qty`
- `.k-add-cart-btn`
- `.k-buy-now-btn`

Résultat observé dans Chromium :

- état vide : le stepper reste affiché ;
- état rempli : « Ajouter au panier » reste affiché ;
- rupture : stepper, ajout et achat restent affichés en même temps que « Me prévenir ».

C'est exactement le comportement visible dans la capture mobile précédente.

Correctif minimal recommandé :

```css
#k-modal .k-modal-product-zone .k-modal-actions .k-qty[hidden],
#k-modal .k-modal-product-zone .k-modal-actions .k-add-cart-btn[hidden],
#k-modal .k-modal-product-zone .k-modal-actions .k-buy-now-btn[hidden] {
  display: none;
}
```

Ajouter un test navigateur basé sur `getComputedStyle(element).display === 'none'` pour chaque état.

### B2 — Le footer mobile reste sur deux lignes

Le layout livré conserve :

- première ligne : quantité + ajouter ;
- deuxième ligne : acheter en pleine largeur.

La maquette et la spécification imposent :

- état vide : **Ajouter au panier + Acheter maintenant**, côte à côte ;
- état rempli : **Stepper + Acheter maintenant**, côte à côte ;
- rupture : **Me prévenir**, pleine largeur.

La hauteur mesurée du footer est de 123 px sur mobile. Il faut piloter la grille selon l'état du panier, idéalement avec un attribut explicite tel que `data-cart-state="empty|filled|out-of-stock"`.

## Anomalies importantes

### A1 — Identité de ligne panier non canonique

`computeLineId(product, combo)` sérialise directement `combo` avec `JSON.stringify`.

Ces deux sélections logiquement identiques produisent donc deux IDs différents :

```js
{ Couleur: 'Rouge', Taille: '44' }
{ Taille: '44', Couleur: 'Rouge' }
```

Il faut trier les clés avant sérialisation et ajouter un test de non-régression.

### A2 — Bouton « Me prévenir » sans comportement

Le bouton et ses états visuels sont présents, mais aucun gestionnaire de clic, capture d'adresse ou appel API n'a été trouvé dans la livraison. Le bouton ne doit pas être livré actif sans action associée.

## Desktop — écarts à la spécification

La structure trois colonnes est fonctionnelle : miniatures, image principale, panneau commercial. Toutefois, la livraison ne respecte pas encore plusieurs contraintes de la spécification validée :

- breakpoint desktop à 900 px au lieu de 1024 px ;
- modal plein écran `100vw × 100dvh`, au lieu d'un contenu centré et plafonné ;
- hero desktop prenant presque toute la hauteur du viewport ;
- toutes les miniatures sont rendues dans un rail, sans limite à quatre ni tuile `+N` ;
- bouton d'agrandissement masqué sur desktop ;
- suggestions entièrement repoussées sous la ligne de flottaison.

La structure est donc bonne, mais la composition n'est pas encore conforme à la maquette contractuelle.

## Dette CSS héritée

Les bundles `css/dist/base.css` et `css/dist/components.css` contiennent déjà sur la branche principale une déclaration orpheline ressemblant à une valeur de `box-shadow` sans propriété. Cette anomalie n'est pas introduite par PDP-1/PDP-2, mais empêche un parsing CSS strict complet. Elle doit être corrigée séparément.

## Décision de merge recommandée

1. Corriger B1 et B2 avant tout merge.
2. Corriger A1 dans le même lot, car il touche l'identité panier.
3. Brancher ou retirer temporairement « Me prévenir ».
4. Arbitrer puis corriger les écarts desktop avant de considérer PDP-2 conforme à la maquette.
5. Rejouer les tests complets du dépôt après application, les ZIP étant des livraisons différentielles et non un dépôt autonome.
