import re, json
from playwright.sync_api import sync_playwright
root='/mnt/data/pdp_correctif_review/final_delivery/public/boutique'
css=open(root+'/css/dist/components.css',encoding='utf8').read()
identity=open(root+'/js/cart-line-identity.js',encoding='utf8').read()
resolver=open(root+'/js/view-models/modal-cart-state.js',encoding='utf8').read()
buybox=open(root+'/js/b-modal-buybox-shared.js',encoding='utf8').read()
def transform(s):
    s=re.sub(r'import\s+[\s\S]*?\s+from\s+[\'\"][^\'\"]+[\'\"]\s*;','',s)
    s=re.sub(r'\bexport\s+','',s)
    return s
identity=transform(identity)
resolver=transform(resolver)
buybox=transform(buybox)
stubs='''
const state={cart:[],modalProductDetail:null,modalSelection:null};
const dom={};
function fmtPrice(v){return String(v)+' KMF'}
function closeModal(){}
function addToCart(product,qty,btn){window.__calls.push(['add',product?.id,qty]);}
function setCartLineQty(lineId,qty){window.__calls.push(['set',lineId,qty]);}
function removeCartLine(lineId){window.__calls.push(['remove',lineId]);}
function startShareFlow(){}
window.__calls=[];
'''
script=stubs+identity+'\n'+resolver+'\n'+buybox+'\nwindow.__syncBuyboxActions=syncBuyboxActions; window.__state=state;'
html=f'''<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><style>{css}</style><style>:root{{--white:#fff;--sand:#f5efdf;--sand-dark:#ece7da;--text:#222;--border:#ddd;--ocean:#4caf50;--ocean-dark:#2c6b2e;--coral:#d85a30;--overlay-black-sm:rgba(0,0,0,.08);--ease:ease}}*{{box-sizing:border-box}}body{{margin:0}}#k-modal{{height:100vh;display:flex;flex-direction:column}}.spacer{{flex:1}}</style><div id="k-modal"><div class="spacer"></div><div class="k-modal-actions" id="actions"><div class="k-qty" id="qty"><button id="minus"></button><span id="val"></span><button id="plus"></button></div><button class="k-add-cart-btn" id="add"></button><button class="k-buy-now-btn" id="buy"></button><button class="k-notify-btn" id="notify" hidden disabled></button></div></div>'''
res={}
with sync_playwright() as p:
  b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=b.new_page(viewport={'width':390,'height':844})
  page.set_content(html)
  page.add_script_tag(content=script)
  cases={
    'selection-required':({'inventory_model':'SKU','product':{'id':'p1'},'option_axes':[{'key':'Couleur'}],'sellable_units':[{'sku_id':'s1','stock_status':'AVAILABLE'}]},{'selected_options':{},'selected_sku_id':None},[]),
    'empty':({'inventory_model':'SKU','product':{'id':'p1'},'option_axes':[{'key':'Couleur'}],'sellable_units':[{'sku_id':'s1','stock_status':'AVAILABLE'}]},{'selected_options':{'Couleur':'Rouge'},'selected_sku_id':'s1'},[]),
    'filled':({'inventory_model':'SKU','product':{'id':'p1'},'option_axes':[{'key':'Couleur'}],'sellable_units':[{'sku_id':'s1','stock_status':'AVAILABLE'}]},{'selected_options':{'Couleur':'Rouge'},'selected_sku_id':'s1'},[{'product':{'id':'p1'},'variant_combo':{'Couleur':'Rouge'},'qty':2}]),
    'out-of-stock':({'inventory_model':'SKU','product':{'id':'p1'},'option_axes':[{'key':'Couleur'}],'sellable_units':[{'sku_id':'s1','stock_status':'OUT_OF_STOCK'}]},{'selected_options':{'Couleur':'Rouge'},'selected_sku_id':'s1'},[]),
  }
  for name,(detail,selection,cart) in cases.items():
    page.evaluate('''({detail,selection,cart})=>{
      __state.cart=cart;
      const els={addBtn:add,buyBtn:buy,qtyWrap:qty,qtyMinus:minus,qtyPlus:plus,qtyVal:val,notifyBtn:notify};
      __syncBuyboxActions(els,detail,selection);
    }''',{'detail':detail,'selection':selection,'cart':cart})
    page.wait_for_timeout(10)
    d=page.evaluate('''()=>{const ids=['qty','add','buy','notify'];const o={};for(const id of ids){const e=document.getElementById(id),r=e.getBoundingClientRect();o[id]={hidden:e.hidden,disabled:e.disabled,display:getComputedStyle(e).display,width:r.width,height:r.height,centerY:(r.top+r.bottom)/2}}const a=actions.getBoundingClientRect();return {cartState:actions.dataset.cartState,els:o,footerHeight:a.height,footerBottom:a.bottom};}''')
    d['visible']=[k for k,v in d['els'].items() if v['display']!='none' and v['width']>0]
    centers=[d['els'][k]['centerY'] for k in d['visible']]
    d['sameRow']=(max(centers)-min(centers)<=1.1) if centers else True
    res[name]=d
  b.close()
print(json.dumps(res,indent=2))
open('/mnt/data/pdp_browser_correctif/actual-state-machine.json','w').write(json.dumps(res,indent=2))
