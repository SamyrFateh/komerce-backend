import json
from playwright.sync_api import sync_playwright
root='/mnt/data/pdp_browser_correctif'
html=open(root+'/harness.html',encoding='utf8').read()
css=open(root+'/components.css',encoding='utf8').read()
html=html.replace('<link rel="stylesheet" href="components.css">', '<style>'+css+'</style>')
results={'mobile':{},'desktop':{}}
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    for w,h in [(360,800),(375,812),(390,844),(430,932)]:
        key=f'{w}x{h}';results['mobile'][key]={}
        for state in ['empty','filled','out-of-stock']:
            page=browser.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
            page.set_content(html,wait_until='load')
            page.evaluate("document.getElementById('k-modal').appendChild(document.getElementById('actions'))")
            page.evaluate('(s)=>setState(s)',state)
            page.wait_for_timeout(450)
            data=page.evaluate('''() => {
              const ids=['qty','add','buy','notify']; const out={};
              for(const id of ids){const e=document.getElementById(id),r=e.getBoundingClientRect();out[id]={hidden:e.hidden,display:getComputedStyle(e).display,left:r.left,top:r.top,right:r.right,bottom:r.bottom,width:r.width,height:r.height};}
              const a=document.getElementById('actions'),ar=a.getBoundingClientRect();
              return {state:a.dataset.cartState,actions:{display:getComputedStyle(a).display,left:ar.left,top:ar.top,right:ar.right,bottom:ar.bottom,width:ar.width,height:ar.height,scrollWidth:a.scrollWidth,clientWidth:a.clientWidth},els:out,body:{scrollWidth:document.documentElement.scrollWidth,clientWidth:document.documentElement.clientWidth}};
            }''')
            visible=[k for k,v in data['els'].items() if v['display']!='none' and v['width']>0 and v['height']>0]
            data['visible']=visible
            centers=[round((data['els'][k]['top']+data['els'][k]['bottom'])/2,1) for k in visible]
            data['sameRow']=(max(centers)-min(centers)<=1.1) if centers else True
            data['noHorizontalOverflow']=data['body']['scrollWidth']<=data['body']['clientWidth'] and data['actions']['scrollWidth']<=data['actions']['clientWidth']+1
            expected={'empty':['add','buy'],'filled':['qty','buy'],'out-of-stock':['notify']}[state]
            data['expectedVisible']=visible==expected
            data['footerCompact']=data['actions']['height']<=80
            results['mobile'][key][state]=data
            if w==430: page.screenshot(path=f'{root}/correctif-mobile-{state}.png',full_page=True)
            page.close()
    for w,h in [(900,768),(1024,768),(1440,900),(1920,1080)]:
        key=f'{w}x{h}'
        page=browser.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
        page.set_content(html,wait_until='load');page.evaluate("setState('empty')");page.wait_for_timeout(450)
        data=page.evaluate('''() => {
          const sels={modal:'#k-modal',zone:'.k-modal-product-zone',thumbs:'.k-modal-thumbs',img:'.k-modal-img-wrap',details:'.k-modal-details',actions:'.k-modal-actions',counter:'.k-modal-counter',view:'.k-modal-view-full'};
          const o={};for(const [k,s] of Object.entries(sels)){const e=document.querySelector(s),r=e.getBoundingClientRect();o[k]={display:getComputedStyle(e).display,left:r.left,top:r.top,right:r.right,bottom:r.bottom,width:r.width,height:r.height,gridColumn:getComputedStyle(e).gridColumn,gridRow:getComputedStyle(e).gridRow,position:getComputedStyle(e).position};}
          const z=getComputedStyle(document.querySelector('.k-modal-product-zone'));
          return {els:o,gridTemplateColumns:z.gridTemplateColumns,gridTemplateRows:z.gridTemplateRows,thumbCount:document.querySelectorAll('.k-modal-thumb').length,moreText:document.querySelector('.k-modal-thumb--more')?.textContent||null,doc:{scrollWidth:document.documentElement.scrollWidth,clientWidth:document.documentElement.clientWidth}};
        }''')
        e=data['els']
        data['threeColumnsOrdered']=e['thumbs']['left'] < e['img']['left'] < e['details']['left']
        data['actionsInRightColumn']=abs(e['actions']['left']-e['details']['left'])<2
        data['counterVisible']=e['counter']['display']!='none'
        data['viewFullVisible']=e['view']['display']!='none'
        data['modalPlafonnee']=(e['modal']['width']<=1180.5 and e['modal']['height']<=880.5 and (e['modal']['width']<w if w>1228 else e['modal']['width']<=w-40))
        data['noHorizontalOverflow']=data['doc']['scrollWidth']<=data['doc']['clientWidth']
        results['desktop'][key]=data
        if w in (1024,1440):page.screenshot(path=f'{root}/correctif-desktop-{w}.png',full_page=True)
        page.close()
    browser.close()
open(root+'/browser-results.json','w').write(json.dumps(results,indent=2))

summary={'mobile':{},'desktop':{}}
for vp,states in results['mobile'].items():
 summary['mobile'][vp]={s:{'visible':d['visible'],'expectedVisible':d['expectedVisible'],'sameRow':d['sameRow'],'footerHeight':d['actions']['height'],'footerBottom':d['actions']['bottom'],'viewportHeight':int(vp.split('x')[1]),'noOverflow':d['noHorizontalOverflow']} for s,d in states.items()}
for vp,d in results['desktop'].items(): summary['desktop'][vp]={k:d[k] for k in ['gridTemplateColumns','thumbCount','moreText','threeColumnsOrdered','actionsInRightColumn','counterVisible','viewFullVisible','modalPlafonnee','noHorizontalOverflow']}
print(json.dumps(summary,indent=2))
