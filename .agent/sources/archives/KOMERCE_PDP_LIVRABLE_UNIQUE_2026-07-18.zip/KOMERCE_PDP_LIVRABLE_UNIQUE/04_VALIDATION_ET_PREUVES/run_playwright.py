from pathlib import Path
from playwright.sync_api import sync_playwright
import base64, json, re

root=Path('/mnt/data/pdp_runtime_test')

def data_url(code):
    return 'data:text/javascript;base64,' + base64.b64encode(code.encode()).decode()

# Build leaf modules first.
bus_code=(root/'b-bus.js').read_text()
store_code=(root/'b-store.js').read_text() + "\nglobalThis.__pdpState = state; globalThis.__pdpDom = dom;"
catalog_code=(root/'b-catalog.js').read_text()
utils_code=(root/'b-utils.js').read_text()
scroll_code=(root/'b-scroll-owner.js').read_text()
schema_code=(root/'shop-schema.js').read_text()
identity_code=(root/'cart-line-identity.js').read_text()
core_code='''
export const metrics = { badge: 0, saves: 0 };
export function showToast() {}
export function updateCartBadge() { metrics.badge += 1; }
export function saveCart() { metrics.saves += 1; }
export function cartQty() { return globalThis.__pdpState.cart.reduce((s,i)=>s+(Number(i.qty)||0),0); }
export function cartTotal() { return globalThis.__pdpState.cart.reduce((s,i)=>s+((Number(i.product?.price_kmf || i.price || 0))*(Number(i.qty)||0)),0); }
export function saveFavs() {}
'''
urls={
 './b-bus.js':data_url(bus_code),
 './b-store.js':data_url(store_code),
 './b-catalog.js':data_url(catalog_code),
 './b-utils.js':data_url(utils_code),
 './b-cart-core.js':data_url(core_code),
 './b-scroll-owner.js':data_url(scroll_code),
 './shop-schema.js':data_url(schema_code),
 './cart-line-identity.js':data_url(identity_code),
}
main=(root/'b-cart.js').read_text()
for spec,url in urls.items():
    main=main.replace(f"'{spec}'", f"'{url}'").replace(f'"{spec}"', f'"{url}"')
main_url=data_url(main)

html='''
<div id="cart-body"></div><div id="cart-footer"></div><div id="cart-header-title"></div><div id="cart-header"></div>
<div id="cart-overlay"></div><div id="cart-drawer"></div><div id="cart-total"></div><div id="cart-conv"></div>
<button id="cart-btn"></button><button id="add-btn"></button>
<aside id="k-side-cart"><div class="k-sc-header"></div><div id="k-sc-total"></div><span id="k-sc-count-inline"></span><div id="k-sc-items"></div><button id="k-sc-cta"></button><button id="k-sc-checkout"></button><button id="k-sc-share"></button><button id="k-sc-clear"></button></aside>
<span id="k-bnav-cart-label"></span>
'''
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page()
    page.set_content(html)
    result=page.evaluate('''async ({mainUrl, identityUrl, coreUrl, busUrl}) => {
      const main = await import(mainUrl);
      const identity = await import(identityUrl);
      const core = await import(coreUrl);
      const busModule = await import(busUrl);
      const state = globalThis.__pdpState;
      const dom = globalThis.__pdpDom;
      const checks=[];
      const check=(name, condition, detail='')=>{checks.push({name,ok:!!condition,detail}); if(!condition) throw new Error(name+': '+detail);};
      dom.cartBody=document.getElementById('cart-body');
      dom.cartFooter=document.getElementById('cart-footer');
      dom.cartHeaderTitle=document.getElementById('cart-header-title');
      dom.cartHeader=document.getElementById('cart-header');
      dom.cartOverlay=document.getElementById('cart-overlay');
      dom.cartDrawer=document.getElementById('cart-drawer');
      dom.cartTotalVal=document.getElementById('cart-total');
      dom.cartTotalConv=document.getElementById('cart-conv');
      dom.cartBtn=document.getElementById('cart-btn');
      dom.addCartBtn=document.getElementById('add-btn');
      const product={id:77,name:'T-shirt',price_kmf:100,image_url:''};
      state.cart=[]; state.favs=[]; state.products=[]; state.editSharedCart=null;
      state.modalProduct=product;
      state.modalVariantCombo={Couleur:'Rouge',Taille:'44'};
      main.addToCart(product,1);
      state.modalVariantCombo={Taille:'44',Couleur:'Rouge'};
      main.addToCart(product,1);
      check('canonical add one line',state.cart.length===1,JSON.stringify(state.cart));
      check('canonical add qty=2',state.cart[0].qty===2,String(state.cart[0].qty));
      check('line_id stored',state.cart[0].line_id===identity.computeLineId(product,{Couleur:'Rouge',Taille:'44'}),state.cart[0].line_id);

      state.modalProduct=null; state.modalVariantCombo=null;
      state.cart=[
        {product,id:77,name:'T-shirt',price:100,image:'',qty:2,variant_combo:{Couleur:'Rouge'},variant_label:'Rouge'},
        {product,id:77,name:'T-shirt',price:100,image:'',qty:3,variant_combo:{Couleur:'Bleu'},variant_label:'Bleu'}
      ];
      main.renderCartBody();
      let rows=dom.cartBody.querySelectorAll('.k-cart-item');
      rows[1].querySelectorAll('.k-qty-btn')[1].click();
      check('drawer plus blue only',state.cart.find(i=>i.variant_combo.Couleur==='Bleu').qty===4,JSON.stringify(state.cart));
      check('drawer red unchanged after plus',state.cart.find(i=>i.variant_combo.Couleur==='Rouge').qty===2,JSON.stringify(state.cart));
      rows=dom.cartBody.querySelectorAll('.k-cart-item');
      rows[1].querySelectorAll('.k-qty-btn')[0].click();
      check('drawer minus blue only',state.cart.find(i=>i.variant_combo.Couleur==='Bleu').qty===3,JSON.stringify(state.cart));
      check('drawer red unchanged after minus',state.cart.find(i=>i.variant_combo.Couleur==='Rouge').qty===2,JSON.stringify(state.cart));

      busModule.bus.emit('side-cart:render');
      let first=document.querySelector('.k-sc-item');
      check('side item line id',!!first?.dataset.lineId,first?.outerHTML||'missing');
      first.querySelector('.k-sc-step-plus').click();
      check('side plus blue only',state.cart.find(i=>i.variant_combo.Couleur==='Bleu').qty===4,JSON.stringify(state.cart));
      check('side red unchanged after plus',state.cart.find(i=>i.variant_combo.Couleur==='Rouge').qty===2,JSON.stringify(state.cart));
      busModule.bus.emit('side-cart:render');
      first=document.querySelector('.k-sc-item');
      first.querySelector('.k-sc-step-minus').click();
      check('side minus blue only',state.cart.find(i=>i.variant_combo.Couleur==='Bleu').qty===3,JSON.stringify(state.cart));
      check('side red unchanged after minus',state.cart.find(i=>i.variant_combo.Couleur==='Rouge').qty===2,JSON.stringify(state.cart));
      busModule.bus.emit('side-cart:render');
      first=document.querySelector('.k-sc-item');
      first.querySelector('.k-sc-item-remove').click();
      check('side remove blue only',state.cart.length===1&&state.cart[0].variant_combo.Couleur==='Rouge',JSON.stringify(state.cart));

      const before=core.metrics.badge;
      main.removeCartLine(identity.computeLineId(product,{Couleur:'Rouge'}));
      check('remove target empties cart',state.cart.length===0,JSON.stringify(state.cart));
      check('remove updates badge',core.metrics.badge===before+1,`${before}->${core.metrics.badge}`);
      return {status:'ok',checks};
    }''', {'mainUrl':main_url,'identityUrl':urls['./cart-line-identity.js'],'coreUrl':urls['./b-cart-core.js'],'busUrl':urls['./b-bus.js']})
    print(json.dumps(result,ensure_ascii=False))
    browser.close()
