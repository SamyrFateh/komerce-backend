# Rapport de validation — correctif final PDP-1 / PDP-2

**Date :** 18 juillet 2026  
**Base :** `pdp1-pdp2-suite-correctif.zip`  
**Décision sur le delta corrigé :** **les deux blocants V2 sont corrigés**.

## Corrections réalisées

### 1. Machine d'état PDP réellement branchée

Fichiers :

- `public/boutique/js/b-modal-mobile-product.js`
- `public/boutique/js/b-modal-desktop-product.js`

Les deux renderers importent et appellent désormais le point d'entrée partagé :

```js
renderPdpActions(detail, selection);
```

Les deux fonctions locales `renderActions()` ont été supprimées afin d'éviter
qu'une nouvelle divergence mobile/desktop ne réapparaisse.

### 2. Panier multi-variantes piloté par `line_id`

Fichier : `public/boutique/js/b-cart.js`

- `addToCart()` calcule l'identité avec `computeLineId()` ;
- la recherche d'une ligne existante utilise `findCartLineById()` ;
- le `line_id` canonique est stocké sur les nouvelles lignes ;
- les steppers du drawer utilisent `setCartLineQty(lineIdOf(item), ...)` ;
- la suppression du drawer utilise `removeCartLine(lineIdOf(item))` ;
- le side-cart résout `+`, `−` et supprimer par `line_id` ;
- `removeCartLine()` appelle désormais `updateCartBadge()`.

### 3. Sécurisation de l'attribut `data-line-id`

Le `line_id` contient du JSON et donc des guillemets. Il n'est pas interpolé
directement dans la chaîne `innerHTML`. Après création du DOM, il est affecté
aux boutons avec `button.dataset.lineId = lineId`.

## Tests ajoutés

- `tests/unit/pdp-renderer-action-wiring.test.js` ;
- test d'ajout canonique avec ordre de clés inversé ;
- tests drawer multi-variantes : `+`, `−`, suppression ;
- tests side-cart multi-variantes : `+`, `−`, suppression ;
- assertion de mise à jour du badge après suppression par ligne.

## Contrôles exécutés localement

- syntaxe Node réussie sur les **15 fichiers JavaScript** livrés ;
- garde statique : import/appel `renderPdpActions()` dans les deux renderers ;
- absence de fonction locale `renderActions()` ;
- absence de comparaison directe `JSON.stringify(i.variant_combo...)` ;
- **11/11** contrôles purs sur identité panier et état PDP ;
- test Chromium Playwright avec le vrai `b-cart.js` :
  - même combinaison avec ordre de clés différent → une seule ligne ;
  - `line_id` stocké ;
  - drawer : `+` et `−` ciblent uniquement la variante choisie ;
  - side-cart : `+`, `−` et supprimer ciblent uniquement la variante choisie ;
  - suppression par ligne met à jour le badge.

## Limite de certification

Le ZIP est différentiel et ne contient pas le dépôt complet, `package.json`, les
dépendances installées ni l'ensemble des scripts de gouvernance. Je ne revendique
donc pas avoir relancé les 1 765 tests historiques. Après superposition dans le
dépôt, exécuter la suite Jest, le build CSS et les gates habituels avant le merge.
