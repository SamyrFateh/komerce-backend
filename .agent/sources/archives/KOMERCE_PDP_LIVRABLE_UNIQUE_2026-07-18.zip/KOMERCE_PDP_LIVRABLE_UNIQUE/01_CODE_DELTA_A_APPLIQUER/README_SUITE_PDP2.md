# Correctif post-audit — intégration finale (18 juillet 2026)

Cette archive intègre le correctif demandé après le rapport
`RAPPORT_TEST_CORRECTIF_PDP1_PDP2_V2.md`. Les deux blocants restants ont été
corrigés directement dans la livraison :

1. les renderers mobile et desktop appellent désormais tous les deux
   `renderPdpActions()` ; les fonctions locales divergentes `renderActions()`
   ont été supprimées ;
2. le panier réel est de nouveau piloté par `line_id` canonique pour l'ajout,
   le drawer et le side-cart, avec mise à jour du badge après suppression.

Durcissement supplémentaire : le `line_id`, qui contient une sérialisation JSON,
n'est pas interpolé brut dans le HTML du side-cart. Il est affecté via
`HTMLElement.dataset` après construction du DOM, ce qui évite de casser les
attributs HTML avec les guillemets du JSON.

Tests ajoutés :

- garde d'architecture empêchant la réintroduction de `renderActions()` dans un
  renderer ;
- ajout canonique d'une variante quel que soit l'ordre des clés ;
- ciblage exact de `+`, `−` et suppression dans le drawer et le side-cart ;
- mise à jour du badge après `removeCartLine()`.

Validation locale réalisée sur l'archive différentielle : syntaxe des 15 fichiers
JavaScript, gardes statiques d'intégration, 11 contrôles purs d'identité/état et
un test Chromium Playwright exécutant le vrai `b-cart.js` avec deux variantes du
même produit. La suite complète du dépôt et les gates doivent encore être relancés
après application sur le dépôt complet, celui-ci n'étant pas contenu dans le ZIP.

---

# Suite du chantier PDP-1 / PDP-2 — 18 juillet 2026

Reprise de la session précédente. Point de départ reconstitué à partir de :
- `monokomerce.zip` (dépôt de référence)
- `pdp1-pdp2-correctif-premerge.zip` (correctif B1/B2/A1/A2 du rapport pré-merge)
- 3 fichiers livrés isolément, plus avancés que le zip ci-dessus : `b-modal-product.js`,
  `modal-media.css`, `modal-shell.css` (correctifs des écarts desktop #2/#3/#4/#5/#6)

**Verdict de cette session : les trois sources ci-dessus, une fois superposées,
ne démarraient pas.** Deux bugs bloquants ont été trouvés et corrigés avant de
pouvoir reprendre le travail restant (Lots A/B/C/D de `PDP-2_FIDELITE_MOCKUP.md`).

## 🔴 Bugs bloquants trouvés et corrigés

### 1. Module manquant : `js/view-models/modal-cart-state.js`

`b-modal-buybox-shared.js` (livré dans le correctif premerge) importe
`resolvePdpCartState`/`PDP_CART_STATUS` depuis ce fichier — absent du zip.
Toute ouverture de fiche produit SKU aurait levé une erreur de résolution de
module au chargement. Reconstruit à partir des tests fournis
(`b-modal-buybox-shared-cart-state.test.js`) et du modèle sœur
`view-models/modal-selection-model.js` pour rester cohérent avec le contrat
`product_detail_v1` : résout `SELECTION_REQUIRED` / `OUT_OF_STOCK` /
`AVAILABLE_EMPTY` / `AVAILABLE_FILLED` à partir de la sélection courante, du
stock (`sellable_units`) et du panier (via `cart-line-identity.js`).

### 2. Imports fantômes : `setCartLineQty` / `removeCartLine`

`b-modal-buybox-shared.js` appelle ces deux fonctions sur `js/b-cart.js`, qui
ne les exportait pas (seuls `setQty`/`removeFromCart`, résolution par
`product.id` seul — exactement l'ambiguïté que `cart-line-identity.js`
documente et que le lot A1 était censé éliminer). `node scripts/check-js-imports.js`
l'a détecté ([I-1], bloquant — `ReferenceError` au runtime dès l'appel).
Ajoutées dans `b-cart.js` comme pendants *line_id-aware* de `setQty`/
`removeFromCart` : elles résolvent la ligne exacte via `findCartLineById`, donc
deux variantes du même produit dans le panier ne se marchent plus dessus.
6 tests dédiés ajoutés dans `tests/unit/b-cart.test.js`.

## ✅ Lots PDP-2 terminés (`PDP-2_FIDELITE_MOCKUP.md`)

- **Lot A** — `category` manquait dans l'objet passé à `buildCarouselSlides`
  depuis `b-modal-mobile-product.js` et `b-modal-desktop-product.js` : la
  ligne 2 du hero-meta ne s'affichait donc jamais. Ajouté (2 lignes). Le rendu
  lui-même (masquage si absent, aucun champ inventé) était déjà correct côté
  `b-modal-product.js`.
- **Lot B** — le compteur "N/Total" restait limité au mobile
  (`max-width:899px`) alors que l'écart desktop du rapport pré-merge demandait
  sa présence aussi en desktop dès qu'une fiche enrichie est chargée. Le CSS
  bloquant (`#k-modal .k-modal-counter{display:none}`) avait déjà été retiré
  dans la livraison isolée ; il manquait le déverrouillage JS
  (`b-modal-image-ux.js`, fonction renommée `_hasEnrichedDetail`).
- **Lot C** — texte "Voir en grand" retiré du bouton loupe (icône seule,
  `aria-label` conservé pour l'accessibilité). CSS déjà conforme (cercle clair
  32/36px) dans la livraison isolée.
- **Lot D** — `grid-template-columns` de `.k-modal-product-zone` était resté à
  2 colonnes (`48%/52%`) dans `modal-product-lot4-hybrid.css` (seul
  propriétaire, invariant B-M-11) alors que `modal-shell.css` plaçait déjà les
  miniatures en `grid-column:1` et les détails en `grid-column:3` — un vrai
  écart entre les deux fichiers qui aurait cassé la mise en page desktop (3e
  colonne implicite non dimensionnée). Passé à 3 colonnes
  (`84px minmax(360px,1fr) minmax(320px,380px)`, gap 20px). Padding compensatoire
  du rail (`.k-modal-slide { padding-left:92px }`, hérité de l'ancien overlay
  absolu à l'intérieur de l'image) retiré au profit d'un padding symétrique,
  devenu obsolète depuis que les miniatures sont un sibling de grille.

## Tests ajoutés cette session

| Fichier | Ajouts |
|---|---|
| `tests/unit/b-cart.test.js` | 6 tests — `setCartLineQty`/`removeCartLine` |
| `tests/unit/b-modal-product.test.js` | 8 tests — hero-meta (Lot A), rail +N / garde aria-current (Lot D) |
| `tests/unit/b-modal-image-ux.test.js` | 1 test corrigé (compteur desktop, Lot B) |
| `tests/unit/b-modal-mobile-product-pdc6-coverage.test.js` | 2 assertions mises à jour (category) |

**95/95 suites, 1765/1765 tests verts.** Tous les gates de gouvernance passent :
`check:html`, `check:imports` (0 fantôme — était 2), `check:important`,
`check:css-guard`, `check:css-specificity-guard`, `check:css-dist-only`,
`check:body-classes` (warnings pré-existants uniquement), `check:no-injection`,
`audit:gate`, `audit:arch`.

## Non traité (hors périmètre, décisions explicites déjà actées)

- Breakpoint desktop 900px vs 1024px (écart #1 du rapport pré-merge) — décision
  déjà actée en session précédente : le seuil 900px est partagé par une
  quinzaine de règles CSS bien au-delà de la PDP, à arbitrer séparément.
- Dette CSS héritée (déclaration orpheline `box-shadow` dans les bundles) —
  signalée dans le rapport pré-merge comme non liée à PDP-1/PDP-2.

## Fichiers livrés (delta à appliquer sur `monokomerce.zip`)

Tous les fichiers listés reflètent l'état final : correctif premerge B1/B2/A1/A2
+ écarts desktop #2/#3/#4/#5/#6 + Lots A/B/C/D + les deux bugs bloquants
ci-dessus. `css/dist/components.css` et `.cache-buster-state.json` sont
régénérés (`node scripts/deploy-css.js`), `index.html` a ses `?v=` à jour.
