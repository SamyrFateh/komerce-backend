/**
 * @komerce-arch
 * @role          boutique-cart-and-side-cart
 * @domain        boutique
 * @layer         ui-component
 * @criticality   critical
 * @inputs        cart_state, shared_cart_context, product_actions, viewport
 * @outputs       cart_drawer, side_cart, quantity_changes, shared_cart_item_updates
 * @depends       b-store.js, b-cart-core.js, b-catalog.js, b-scroll-owner.js, shop-schema.js, routes/shared-cart.js
 * @used-by       boutique.js, b-checkout.js, b-modal-core.js, b-nav.js, b-share-cart.js
 * @doctrine      panier_ouvert_ferme, participant_lecture_seule, side_cart_non_intrusif, modal_produit_sans_chevauchement
 * @impact-areas  checkout-entry, side-cart, shared-cart-editing, participant-flow, responsive-layout
 * @version       2026-06
 */
'use strict';

/**
 * b-cart.js — Module ES · §7 CART INTERACTIONS + §10 CART PANEL & SHARE + §14 STEPPER
 * Extrait de boutique.js Sprint 2F — Option C
 *
 * §7  : addToCart, setQty, fly animation, cart badge sync
 * §10 : tiroir panier, partage WhatsApp, shareCartWhatsApp, showShareChoiceModal
 * §14 : stepper +/- haptic, renderStepper (setupLongPressSteppers IIFE)
 */

import { bus }           from './b-bus.js';
import {
  state, dom, $, $$, scroll,
}                         from './b-store.js';
import { scrollToCategorySection } from './b-catalog.js';
import {
  sanitize, fmt, fmtPrice, optimizeImgUrl,
  productEmoji, _currency, apiGet, apiPost,
}                         from './b-utils.js';
import {
  showToast, updateCartBadge, saveCart, cartQty, cartTotal, saveFavs,
}                         from './b-cart-core.js';
import { isDesktop, getScrollY, scrollToPosition } from './b-scroll-owner.js';
import { getCategoryIcon, normalizeCategoryKey } from './shop-schema.js';
import { computeLineId, lineIdOf, findCartLineById } from './cart-line-identity.js';

'use strict';

  // ║  §7 · CART INTERACTIONS — addToCart, setQty, fly animation       ║
  // ╚══════════════════════════════════════════════════════════════════╝
  //  → Futur module: b-cart.js

  /**
   * Animation "fly to cart" — produit vole de la carte vers l'avatar panier.
   * Clone l'image → arc de Bézier → burst sparkles → updateCartBadge.
   * Exception légitime : animation frame-by-frame (rAF).
   * @param {HTMLElement} btn - Bouton panier cliqué
   * @param {number} productId - ID du produit ajouté
   */
  function flyToCart(sourceEl, product) {
    const cartIcon = dom.cartBtn;
    if (!cartIcon || !sourceEl) return;
    const srcRect = sourceEl.getBoundingClientRect();
    const dstRect = cartIcon.getBoundingClientRect();
    const startX = srcRect.left + srcRect.width / 2;
    const startY = srcRect.top + srcRect.height / 2;
    const endX = dstRect.left + dstRect.width / 2;
    const endY = dstRect.top + dstRect.height / 2;

    // Main particle
    const particle = document.createElement('div');
    particle.style.cssText = [
      'position:fixed', 'z-index:9999', 'pointer-events:none',
      'border-radius:50%', 'background:var(--ocean)',
      'width:56px', 'height:56px',
      'display:flex', 'align-items:center', 'justify-content:center',
      'font-size:1.5rem',
      'box-shadow:0 4px 20px rgba(67,160,71,0.6)',
      'overflow:hidden',
      'left:' + startX + 'px', 'top:' + startY + 'px',
      'transform:translate(-50%,-50%) scale(0)', 'opacity:0'
    ].join(';');

    if (product.image_url) {
      const img = document.createElement('img');
      img.src = optimizeImgUrl(product.image_url, 80);
      img.style.cssText = 'width:100%;height:100%;object-fit:cover;border-radius:50%;';
      particle.appendChild(img);
    } else {
      particle.textContent = productEmoji(product);
    }
    document.body.appendChild(particle);

    // Sparkle trail
    const sparkles = [];
    for (let s = 0; s < 6; s++) {
      const sp = document.createElement('div');
      sp.style.cssText = [
        'position:fixed', 'z-index:9998', 'pointer-events:none',
        'border-radius:50%', 'background:var(--coral)',
        'width:8px', 'height:8px',
        'left:' + startX + 'px', 'top:' + startY + 'px',
        'transform:translate(-50%,-50%)', 'opacity:0'
      ].join(';');
      document.body.appendChild(sp);
      sparkles.push(sp);
    }

    // Phase 1: Pop-in
    particle.getBoundingClientRect();
    particle.style.transition = 'transform 0.35s cubic-bezier(0.34,1.56,0.64,1), opacity 0.2s ease-out';
    particle.style.transform = 'translate(-50%,-50%) scale(1.15)';
    particle.style.opacity = '1';

    // Phase 2: Arc flight
    const duration = 900;
    let startTime = null;

    /**
     * Frame d'animation rAF pour l'arc de vol panier (flyToCart).
     * Calcule la position courbe via Bézier quadratique.
     * @param {DOMHighResTimeStamp} timestamp - Horodatage fourni par requestAnimationFrame
     */
    function animateArc(timestamp) {
      if (!startTime) startTime = timestamp;
      const elapsed = timestamp - startTime;
      const t = Math.min(elapsed / duration, 1);
      const ease = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
      const x = startX + (endX - startX) * ease;
      const arcT = 1 - Math.pow(2 * t - 1, 2);
      const y = startY + (endY - startY) * ease - arcT * 120;
      const scale = 1.15 - (0.85 * ease);
      const rot = ease * 360;

      particle.style.transition = 'none';
      particle.style.left = x + 'px';
      particle.style.top = y + 'px';
      particle.style.transform = 'translate(-50%,-50%) scale(' + scale + ') rotate(' + rot + 'deg)';
      particle.style.opacity = String(1 - ease * 0.3);

      for (let i = 0; i < sparkles.length; i++) {
        const delay = i * 0.12;
        const st = Math.max(0, t - delay);
        if (st > 0 && st < 1) {
          const sx = startX + (endX - startX) * st;
          const sArc = 1 - Math.pow(2 * st - 1, 2);
          const sy = startY + (endY - startY) * st - sArc * 120;
          const scatter = (Math.random() - 0.5) * 16;
          sparkles[i].style.transition = 'none';
          sparkles[i].style.left = (sx + scatter) + 'px';
          sparkles[i].style.top = (sy + scatter) + 'px';
          sparkles[i].style.opacity = String(0.8 - st);
          sparkles[i].style.transform = 'translate(-50%,-50%) scale(' + (1 - st * 0.7) + ')';
        }
      }

      if (t < 1) {
        requestAnimationFrame(animateArc);
      } else {
        // Phase 3: Impact
        particle.style.transition = 'transform 0.15s ease-in, opacity 0.15s ease-in';
        particle.style.transform = 'translate(-50%,-50%) scale(0)';
        particle.style.opacity = '0';
        cartIcon.style.transition = 'transform 0.15s ease-out';
        cartIcon.style.transform = 'scale(1.3)';
        setTimeout(() => {
          cartIcon.style.transition = 'transform 0.25s cubic-bezier(0.34,1.56,0.64,1)';
          cartIcon.style.transform = 'scale(1)';
        }, 150);
        setTimeout(() => {
          particle.remove();
          sparkles.forEach(sp => sp.remove());
        }, 200);
        // Badge bump
        dom.cartBadge.classList.remove('bump');
        void dom.cartBadge.offsetWidth;
        dom.cartBadge.classList.add('bump');
      }
    }

    setTimeout(() => requestAnimationFrame(animateArc), 350);
  }

  /* ── ADD TO CART ────────────────────────────────────────── */
  /* ── ADD TO CART ────────────────────────────────────────── */
/**
 * Ajoute un produit au panier ou incrémente sa quantité.
 * @param {number|string} id - ID produit
 * @param {Object} [opts] - { fromModal, qty }
 */
  function addToCart(product, qty, sourceBtn) {
  qty = qty || 1;

  // Lot 2 — capturer le variant_combo au moment de l'ajout (snapshot)
  let combo = null;
  let comboLabel = '';
  if (state.modalProduct && String(state.modalProduct.id) === String(product.id)
      && state.modalVariantCombo && Object.keys(state.modalVariantCombo).length > 0) {
    combo = Object.assign({}, state.modalVariantCombo);
    comboLabel = Object.values(combo).join(' / ');
  }

  // Une ligne panier est identifiée par produit + combinaison canonique.
  // Ne jamais comparer variant_combo via JSON.stringify direct : l'ordre des
  // clés dépend du parcours de sélection et ne fait pas partie de l'identité.
  const lineId = computeLineId(product, combo);
  const existing = findCartLineById(state.cart, lineId);

  if (existing) {
    existing.qty += qty;
    if (!existing.line_id) existing.line_id = lineId;
    if (!existing.product) existing.product = product;
    if (!existing.id) existing.id = product.id;
    if (!existing.name) existing.name = product.name;
    if (existing.price == null) existing.price = product.price_kmf ?? product.price ?? 0;
    if (!existing.image) existing.image = product.image_url || product.image || '';
  } else {
    state.cart.push({
      product: product,
      id: product.id,
      name: product.name,
      price: product.price_kmf ?? product.price ?? 0,
      image: product.image_url || product.image || '',
      qty: qty,
      variant_combo: combo,
      variant_label: comboLabel,
      line_id: lineId,
    });
  }

  // Fly animation
  if (sourceBtn) {
    flyToCart(sourceBtn, product);
  }

  saveCart();

  const isModalAdd  = sourceBtn === dom.addCartBtn;
  // Buy-now btn est un bouton modal mais n'est pas dom.addCartBtn → détecter explicitement
  const isBuyNowBtn = sourceBtn && sourceBtn.id === 'k-buy-now-btn';

  // Mark button feedback (grid / rail buttons only — pas modal, pas buy-now)
  if (sourceBtn && !isModalAdd && !isBuyNowBtn) {
    sourceBtn.classList.add('added');
    sourceBtn.disabled = true;
    setTimeout(() => {
      sourceBtn.classList.remove('added');
      sourceBtn.classList.add('in-cart');
      sourceBtn.disabled = false;
    }, 800);
  }

  // Mark all grid buttons for this product
  markAllCartButtons();

  // Animation "coucou" : la petite dame fait signe
  // On cible LES DEUX dames (header catalogue + topbar modale) pour que
  // l'animation soit toujours visible quel que soit le contexte.
  const cartBtns = [
    document.getElementById('k-cart-btn'),
    document.getElementById('k-modal-cart-btn'),
  ].filter(Boolean);

  cartBtns.forEach(btn => {
    // Ring pulse coral
    btn.classList.remove('ring-pulse');
    void btn.offsetWidth;
    btn.classList.add('ring-pulse');
    setTimeout(() => btn.classList.remove('ring-pulse'), 1500);

    // Animation "coucou" de l'avatar
    btn.classList.remove('avatar-wave');
    void btn.offsetWidth;
    btn.classList.add('avatar-wave');
    setTimeout(() => btn.classList.remove('avatar-wave'), 900);
  });

  if (isModalAdd) {
    // Fix 8 : modal button → "✓ Dans le panier | Voir (N) →"
    setTimeout(() => {
      const count = cartQty();
      dom.addCartBtn.classList.remove('added');
      dom.addCartBtn.classList.add('confirmed');
      dom.addCartBtn.disabled = false;
      dom.addCartBtn.innerHTML = '✓ Ajouté';
      dom.addCartBtn.onclick = function() {
        bus.emit('modal:close');
        // Desktop : le side-cart est déjà visible — on ne rouvre pas le tiroir
        if (isDesktop()) {
          let sc = document.getElementById('k-side-cart');
          if (sc) { sc.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }
        } else {
          setTimeout(openCart, 150);
        }
      };
    }, 700);
  } else if (isBuyNowBtn) {
    // Buy-now depuis la modal : rafraîchir le side-cart desktop silencieusement
    // (la modal gère elle-même le feedback visuel du bouton et l'ouverture du panier)
    if (isDesktop()) {
      // ARCH-1 : remplace window.__kmrcSideCart → bus.emit
      bus.emit('side-cart:render');
    }
  } else if (sourceBtn) {
    // Toast de confirmation (grid / rail uniquement)
    showToast('✓ ' + (product.name || 'Produit') + ' ajouté', 'success');
  }
}

  /**
   * @brief setQty — Met à jour la quantité d'un article dans le panier
   * Si newQty < 1 → supprime l'article (removeFromCart)
   * Met à jour le DOM stepper + badge + localStorage
   * @param {string|number} productId - ID du produit
   * @param {number} newQty - Nouvelle quantité cible
   */
    function setQty(productId, newQty) {
    const pid = String(productId);
    if (newQty < 1) { removeFromCart(pid); return; }
    const item = state.cart.find(i => String(i.product.id) === pid);
    if (item) {
      item.qty = newQty;
      saveCart();
      renderCartBody();
      markAllCartButtons();
      updateCartBadge();
    }
  }

  /**
   * Synchronise l'état visuel de tous les boutons panier dans les grilles.
   * 🧺 → stepper si produit dans le panier, reset sinon.
   * Appelé après chaque modification du panier.
   */
  function markAllCartButtons() {
    // IDs actuellement dans le panier
    const inCartIds = new Set(state.cart.map(i => String(i.product.id)));

    // OPTION C : panier tressé visuel + stepper "− qty +" visible dès ajout
    //            (plus besoin de long-press, le stepper est directement accessible)
    document.querySelectorAll('.k-card-add').forEach(btn => {
      const pid = String(btn.dataset.add);
      if (inCartIds.has(pid)) {
        const item = state.cart.find(i => String(i.product.id) === pid);
        btn.classList.add('in-cart');
        // Stepper compact : − quantité + (tous cliquables indépendamment)
        btn.innerHTML =
          '<span class="k-add-minus" data-pid="' + pid + '">−</span>' +
          '<span class="k-add-qty">' + item.qty + '</span>' +
          '<span class="k-add-plus-ic">+</span>';
      } else {
        // Produit plus dans le panier → remettre juste le "+"
        btn.classList.remove('in-cart');
        btn.innerHTML = '<img src="/images/panier_tresse_vert.png" class="k-card-add-basket" alt="+" width="20" height="20">';
      }
    });
  }

  /**
   * @brief setCartLineQty — Met à jour la quantité d'une ligne panier précise,
   * identifiée par line_id (product + variant_combo), pas seulement product.id.
   * Contrairement à setQty (legacy, 1er match par product.id), résout la ligne
   * exacte via cart-line-identity.js — nécessaire dès qu'un même produit peut
   * avoir plusieurs variantes dans le panier (A1, rapport pré-merge PDP1/PDP2).
   * Si newQty < 1 → supprime la ligne (removeCartLine).
   * @param {string} lineId - identifiant de ligne (computeLineId)
   * @param {number} newQty - nouvelle quantité cible
   */
  function setCartLineQty(lineId, newQty) {
    if (newQty < 1) { removeCartLine(lineId); return; }
    const item = findCartLineById(state.cart, lineId);
    if (item) {
      item.qty = newQty;
      saveCart();
      renderCartBody();
      markAllCartButtons();
      updateCartBadge();
    }
  }

  /**
   * @brief removeCartLine — Retire une ligne panier précise par line_id
   * (cf. setCartLineQty ci-dessus pour le rationnel A1).
   * @param {string} lineId - identifiant de ligne (computeLineId)
   */
  function removeCartLine(lineId) {
    const item = findCartLineById(state.cart, lineId);
    if (!item) return;
    state.cart = state.cart.filter(i => i !== item);
    saveCart();
    renderCartBody();
    markAllCartButtons();
    updateCartBadge();
  }

  /* ── REMOVE FROM CART ───────────────────────────────────── */
  /**
 * Retire complètement un produit du panier.
 * @param {number|string} id - ID produit
 */
  function removeFromCart(productId) {
    const pid = String(productId);
    state.cart = state.cart.filter(i => String(i.product.id) !== pid);
    saveCart();
    renderCartBody();
    markAllCartButtons();
  }

  /* ── QUICK ADD FROM GRID ────────────────────────────────── */
/**
 * Ajout rapide depuis une carte (bouton 🧺).
 * @param {number|string} id - ID produit
 * @param {HTMLElement} btn - Bouton déclencheur
 */
  function quickAdd(productId, btnEl) {
  const pid = String(productId);
  const product = state.products.find(p => String(p.id) === pid);

  if (!product) {
    console.warn('[quickAdd] Produit introuvable:', productId);
    return;
  }

  addToCart(product, 1, btnEl);
}

/**
 * Supprime instantanément un produit du panier (swipe left sur mobile).
 * @param {number|string} productId - ID produit à supprimer
 */
function quickRemove(productId, btnEl) {
    const pid = String(productId);
    const item = state.cart.find(i => String(i.product.id) === pid);
    if (!item) return;
    if (item.qty <= 1) {
      removeFromCart(pid);
    } else {
      setQty(pid, item.qty - 1);
    }
  }

  /* ── TOGGLE FAV ─────────────────────────────────────────── */
  /**
 * Bascule un produit en favori / non favori.
 * @param {number|string} id - ID produit
 * @param {HTMLElement} [btn] - Bouton cœur
 */
  function toggleFav(id, btnEl) {
    const idx = state.favs.indexOf(id);
    if (idx >= 0) {
      state.favs.splice(idx, 1);
      btnEl.classList.remove('liked');
      btnEl.innerHTML = '🤍';
      showToast('Retiré des favoris');
    } else {
      state.favs.push(id);
      btnEl.classList.add('liked');
      btnEl.innerHTML = '❤️';
      btnEl.classList.add('k-pop');
      setTimeout(() => btnEl.classList.remove('k-pop'), 300);
      showToast('❤️ Ajouté aux favoris');
    }
    saveFavs();
  }

  /* ── CATEGORIES ─────────────────────────────────────────── */

  // ╔══════════════════════════════════════════════════════════════════╗
  // ║  §10 · CART PANEL & SHARE — Tiroir panier + partage WhatsApp     ║
  // ╚══════════════════════════════════════════════════════════════════╝
  //  → Futur module: b-cart.js (même module §7)

  /**
   * Ouvre le panneau panier latéral (slide-in depuis la droite).
   * Met à jour le rendu complet + synchronise les badges.
   */
  function openCart() {
    renderCartBody();
    dom.cartHeaderTitle.textContent = 'Mon Panier (' + cartQty() + ')';
    // Desktop : le panier EST le side-cart inline (liste + total toujours visibles
    // à droite). Cliquer la dame n'ouvre donc pas un drawer-liste en doublon :
    // ça lance DIRECTEMENT le checkout, même flux que le bouton « Commander » du
    // side-cart (bus 'checkout:open' → checkoutCart(), qui gère le panier vide).
    if (isDesktop()) {
      bus.emit('checkout:open');
      return;
    }
    // ── Mobile uniquement (le return desktop est passé avant) ──
    dom.cartOverlay.classList.add('open');
    dom.cartDrawer.classList.add('open');
    scroll.savedY = getScrollY();
    document.body.classList.add('cart-open');
  }

  /**
   * Ferme le panneau panier + restore le scroll catalogue.
   */
  function closeCart() {
    dom.cartOverlay.classList.remove('open');
    dom.cartDrawer.classList.remove('open');
    document.body.classList.remove('cart-open');
    document.body.classList.remove('cart-empty');
    if (scroll.savedY) {
      scrollToPosition(scroll.savedY);
      scroll.savedY = 0;
    }
  }

  /**
   * Ouvre le panneau panier et met en surbrillance un produit spécifique.
   * @param {number|string} productId - ID du produit à mettre en avant
   */
  function openCartWithHighlight(productId) {
    renderCartBody(productId);
    // Celebrating header
    dom.cartHeader.classList.add('celebrating');
    dom.cartHeaderTitle.textContent = '🎊 C\'est dans le panier !';
    setTimeout(() => {
      dom.cartHeader.classList.remove('celebrating');
      dom.cartHeaderTitle.textContent = 'Mon Panier (' + cartQty() + ')';
    }, 2400);

    // Desktop : side cart inline — pas de drawer ni cart-open
    if (!isDesktop()) {
      dom.cartOverlay.classList.add('open');
      dom.cartDrawer.classList.add('open');
      scroll.savedY = getScrollY();
      document.body.classList.add('cart-open');
    }

    setTimeout(() => {
      const newItem = dom.cartBody.querySelector('.k-cart-item.new-item');
      if (newItem) newItem.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 120);
  }

  /**
   * Re-rend le contenu du panneau panier (liste items + totaux + CTA).
   * @param {number|string} [highlightId] - ID produit à mettre en évidence (optionnel)
   */
  function renderCartBody(highlightId) {
    dom.cartBody.innerHTML = '';

    // FIX UX : marquer le body avec 'cart-empty' si panier vide
    // → permet au CSS de garder la bnav visible pour naviguer
    if (state.cart.length === 0) {
      document.body.classList.add('cart-empty');
    } else {
      document.body.classList.remove('cart-empty');
    }

    if (state.cart.length === 0) {
      dom.cartBody.innerHTML = `
        <div class="k-cart-empty">
          <div class="k-cart-empty-icon">🧺</div>
          <p class="k-cart-empty-title">Votre panier est vide</p>
          <p class="k-cart-empty-sub">Découvrez notre sélection de produits livrés aux Comores.</p>
          <button type="button" class="k-cart-empty-cta" id="k-cart-empty-shop">
            🛍️ Découvrir la boutique
          </button>
        </div>`;
      dom.cartFooter.classList.add('u-hidden');

      // Binding bouton découvrir
      const shopBtn = document.getElementById('k-cart-empty-shop');
      if (shopBtn) {
        shopBtn.addEventListener('click', () => {
          closeCart();
          if (typeof switchView === 'function') switchView('shop');
          // Marquer l'onglet Boutique actif dans la bnav
          document.querySelectorAll('.k-bnav-item').forEach(i => i.classList.remove('active'));
          const shopNav = document.querySelector('.k-bnav-item[data-tab="shop"]');
          if (shopNav) shopNav.classList.add('active');
        });
      }
      return;
    }

    state.cart.forEach(item => {
      const p = item.product;
      const unitKmf = p.price_kmf || 0;
      const isNew = highlightId && String(p.id) === String(highlightId);

      const row = document.createElement('div');
      row.className = 'k-cart-item' + (isNew ? ' new-item' : '');
      row.dataset.pid = String(p.id);

      // Image
      const imgBox = document.createElement('div');
      imgBox.className = 'k-cart-item-img';
      if (p.image_url) {
        const img = document.createElement('img');
        img.src = optimizeImgUrl(p.image_url, 100);
        img.alt = p.name || '';
        img.loading = 'lazy';
        imgBox.appendChild(img);
      } else {
        imgBox.textContent = productEmoji(p);
      }
      // Clic sur l'image → fermer le panier puis rouvrir la fiche produit
      imgBox.addEventListener('click', () => {
        closeCart();
        bus.emit('modal:open', { id: p.id });
      });
      row.appendChild(imgBox);

      // Info
      const info = document.createElement('div');
      info.className = 'k-cart-item-info';

      const name = document.createElement('div');
      name.className = 'k-cart-item-name';
      name.textContent = p.name || 'Produit';
      // Clic sur le nom → fermer le panier puis rouvrir la fiche produit
      name.addEventListener('click', () => {
        closeCart();
        bus.emit('modal:open', { id: p.id });
      });
      info.appendChild(name);

      if (item.qty > 1) {
        const unitLine = document.createElement('div');
        unitLine.className = 'k-cart-item-unit';
        unitLine.textContent = fmt(unitKmf, 'KMF') + ' × ' + item.qty;
        info.appendChild(unitLine);
      }

      const price = document.createElement('div');
      price.className = 'k-cart-item-price';
      price.textContent = fmt(unitKmf * item.qty, 'KMF');
      info.appendChild(price);

      // Qty controls
      const qtyRow = document.createElement('div');
      qtyRow.className = 'k-cart-item-qty';

      const minusBtn = document.createElement('button');
      minusBtn.className = 'k-qty-btn';
      minusBtn.textContent = '−';
      minusBtn.addEventListener('click', () => setCartLineQty(lineIdOf(item), item.qty - 1));
      qtyRow.appendChild(minusBtn);

      const qtyVal = document.createElement('span');
      qtyVal.className = 'k-qty-val';
      qtyVal.textContent = item.qty;
      qtyRow.appendChild(qtyVal);

      const plusBtn = document.createElement('button');
      plusBtn.className = 'k-qty-btn';
      plusBtn.textContent = '+';
      plusBtn.addEventListener('click', () => setCartLineQty(lineIdOf(item), item.qty + 1));
      qtyRow.appendChild(plusBtn);

      info.appendChild(qtyRow);

      // Ajouté badge
      if (isNew) {
        const badge = document.createElement('span');
        badge.className = 'k-cart-item-badge';
        badge.textContent = '✨ Ajouté';
        info.appendChild(badge);
      }

      row.appendChild(info);

      // Remove button
      const removeBtn = document.createElement('button');
      removeBtn.className = 'k-cart-item-remove';
      removeBtn.textContent = '✕';
      removeBtn.title = 'Retirer';
      removeBtn.addEventListener('click', () => removeCartLine(lineIdOf(item)));
      row.appendChild(removeBtn);

      dom.cartBody.appendChild(row);
    });

    // Footer
    dom.cartFooter.classList.remove('u-hidden');

    // PR-1 : le bouton "📤 Partager" est statique dans index.html (#k-cart-share)
    // géré par b-share-cart.js — plus d'injection dynamique ici.

    // SC-EDIT-04 — En mode édition panier collectif, masquer checkout + share
    // et afficher un bandeau de confirmation dans le tiroir.
    const editCtxDrawer = state.editSharedCart;
    const cartCheckoutBtn = document.getElementById('k-cart-checkout');
    const cartShareBtn    = document.getElementById('k-cart-share');
    const cartClearBtn    = document.getElementById('k-cart-clear');
    if (cartCheckoutBtn) cartCheckoutBtn.style.display = editCtxDrawer ? 'none' : '';
    if (cartShareBtn)    cartShareBtn.style.display    = editCtxDrawer ? 'none' : '';
    // SC-EDIT-04 — Masquer aussi le bouton Vider en mode édition collective :
    // vider le panier de travail détruirait silencieusement les articles en cours d'édition.
    if (cartClearBtn)    cartClearBtn.style.display    = editCtxDrawer ? 'none' : '';

    // Injecter/retirer le bloc d'action edit dans le footer du drawer
    let drawerEditBar = document.getElementById('k-cart-edit-bar');
    if (editCtxDrawer && !drawerEditBar) {
      drawerEditBar = document.createElement('div');
      drawerEditBar.id = 'k-cart-edit-bar';
      // Lot 2 — styles inline supprimés ; owner : cart.css § k-cart-edit-bar
      drawerEditBar.innerHTML = `
        <div class="k-cart-edit-header">
          ✏️ Mode édition — Panier collectif
        </div>
        <button id="k-cart-edit-update" type="button">
          ✅ Mettre à jour le panier collectif
        </button>
        <button id="k-cart-edit-cancel" type="button">
          ✕ Annuler les modifications
        </button>
        <p id="k-cart-edit-err"></p>`;
      // Insérer dans la zone boutons du footer
      const footerBtns = document.querySelector('.k-cart-footer-btns');
      if (footerBtns) footerBtns.after(drawerEditBar);
      else dom.cartFooter.appendChild(drawerEditBar);

      // SC-EDIT-06 — Câbler update dans le drawer
      drawerEditBar.querySelector('#k-cart-edit-update')?.addEventListener('click', async () => {
        const ctx    = state.editSharedCart;
        const errEl  = drawerEditBar.querySelector('#k-cart-edit-err');
        const upBtn  = drawerEditBar.querySelector('#k-cart-edit-update');
        if (!ctx) return;
        if (errEl) errEl.textContent = '';

        const cartItems = (state.cart || [])
          .map(it => ({ product_id: it.product?.id || it.id, quantity: Number(it.qty) || 1 }))
          .filter(it => it.product_id);
        if (!cartItems.length) {
          if (errEl) errEl.textContent = 'Le panier est vide. Ajoutez au moins un article.';
          return;
        }
        upBtn.disabled = true; upBtn.textContent = '⏳ Mise à jour…';
        try {
          await fetch(`/api/shared-carts/${ctx.shared_cart_id}/items`, {
            method: 'PUT', credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cart_items: cartItems }),
          }).then(async r => {
            if (!r.ok) { const d = await r.json().catch(() => ({})); throw new Error(d?.error || d?.message || `Erreur ${r.status}`); }
          });
          state.editSharedCart = null;
          clearCart();
          // Fermer le tiroir
          dom.cartOverlay?.classList.remove('open');
          dom.cartDrawer?.classList.remove('open');
          document.body.classList.remove('cart-open');
          showToast('✅ Panier collectif mis à jour. Les participants ont été notifiés.', 'success');
          import('./b-nav.js').then(({ switchView }) => {
            document.querySelectorAll('.k-bnav-item, .k-header-nav-btn')
              .forEach(i => i.classList.toggle('active', i.dataset.tab === 'group'));
            switchView('group');
            import('./b-group-view.js').then(({ renderGroupView }) => renderGroupView());
          });
        } catch (err) {
          if (errEl) errEl.textContent = err?.message || 'Impossible de mettre à jour.';
          upBtn.disabled = false; upBtn.textContent = '✅ Mettre à jour le panier collectif';
        }
      });

      // SC-EDIT-08 — Câbler annuler dans le drawer
      drawerEditBar.querySelector('#k-cart-edit-cancel')?.addEventListener('click', () => {
        if (!confirm('Annuler les modifications ? Vous revenez dans l\'onglet Groupe sans sauvegarder.')) return;
        // Supprimer le contexte d'édition — le panier boutique est laissé intact.
        state.editSharedCart = null;
        dom.cartOverlay?.classList.remove('open');
        dom.cartDrawer?.classList.remove('open');
        document.body.classList.remove('cart-open');
        showToast('Modifications annulées.', 'success');
        import('./b-nav.js').then(({ switchView }) => {
          document.querySelectorAll('.k-bnav-item, .k-header-nav-btn')
            .forEach(i => i.classList.toggle('active', i.dataset.tab === 'group'));
          switchView('group');
          import('./b-group-view.js').then(({ renderGroupView }) => renderGroupView());
        });
      });
    } else if (!editCtxDrawer && drawerEditBar) {
      drawerEditBar.remove();
    }

    const qty = cartQty();
    const total = cartTotal();

    // Récap détaillé : nombre d'articles + sous-total
    const itemCountEl = document.getElementById('k-cart-item-count');
    const itemPluralEl = document.getElementById('k-cart-item-plural');
    const subtotalEl = document.getElementById('k-cart-subtotal-val');
    if (itemCountEl) itemCountEl.textContent = qty;
    if (itemPluralEl) itemPluralEl.textContent = qty > 1 ? 's' : '';
    if (subtotalEl) subtotalEl.textContent = fmt(total, 'KMF');

    // Total
    dom.cartTotalVal.textContent = fmt(total, 'KMF');
    if (_currency === 'EUR') {
      dom.cartTotalConv.textContent = '≈ ' + fmt(total, 'EUR');
    } else {
      dom.cartTotalConv.textContent = '';
    }
  }

  /* ── SHARE CART WHATSAPP ────────────────────────────────── */
  /* ── SHARED CART — API v2 ──────────────────────────────────── */

  /**
 * Construit l'URL de partage du panier via l'API.
 * @param {Object} opts - { type: 'simple'|'event', eventLabel? }
 * @returns {Promise<string>} URL de partage
 */
  async function buildCartShareURL(opts) {
    opts = opts || {};
    const payload = {
      cart_items: state.cart.map(function(item) {
        return {
          product_id: item.product.id,
          qty: item.qty,
          price_kmf: item.product.promo_price_kmf || item.product.price_kmf || 0
        };
      }),
      type:        opts.type        || 'simple',
      event_label: opts.event_label || null,
      sharer_name: opts.sharer_name || null
    };
    const res = await apiPost('/api/shares', payload);
    if (res && (res.url || res.share_url)) return res.url || res.share_url;
    throw new Error('url manquante');
  }

  /**
   * Construit l'URL de partage de secours si l'API share échoue.
   * Encode les items du panier en query string.
   * @returns {string} URL de partage fallback
   */
  function _buildFallbackCartURL() {
    // Fallback legacy URL si l'API échoue
    const items = state.cart.map(function(item) {
      return item.product.id + ':' + item.qty;
    });
    return window.location.origin + '/Komerce_Boutique.html?cart=' + encodeURIComponent(items.join(','));
  }

  /* ======= SHARE CHOICE MODAL — DEPRECATED PR-1 =======
     Remplacé par b-share-cart.js (owner exclusif du flow "📤 Partager").
     Stubs conservés pour compatibilité exports. À supprimer en nettoyage PR-event. */

  function _closeShareModal() {
    let ov = document.getElementById('k-share-overlay');
    if (ov) ov.remove();
  }

  /** @deprecated PR-1 — stub, flow géré par b-share-cart.js */
  function showShareChoiceModal() {
    // no-op — b-share-cart.js prend en charge le flow "📤 Partager"
  }

  /** @deprecated PR-1 — stub */
  function _showEventForm() { /* no-op */ }
  /** @deprecated PR-1 — stub */
  async function _doEventShare() { /* no-op */ }
  /** @deprecated PR-1 — stub */
  async function shareCartWhatsApp() {
    // no-op — b-share-cart.js prend en charge le flow "📤 Partager"
  }

    /* ── AUTO-POPULATE CART FROM SHARED URL ──────────────────── */
  /**
 * Charge et affiche un panier partagé depuis un token URL.
 * @param {string} token - Token de partage
 */
  function loadSharedCart() {
    let params = new URLSearchParams(window.location.search);

    // Nouveau : ?share=token → API
    let shareToken = params.get('share');
    if (shareToken) {
      state.shareToken = shareToken;
      _loadSharedCartFromAPI(shareToken);
      return;
    }

    // Legacy : ?cart=id1:qty1,id2:qty2
    let cartParam = params.get('cart');
    if (!cartParam) return;

    let entries = cartParam.split(',').map(function(e) {
      let parts = e.split(':');
      return { id: parts[0], qty: parseInt(parts[1]) || 1 };
    }).filter(function(e) { return e.id; });

    if (entries.length === 0) return;

    let checkProducts = setInterval(function() {
      if (!state.products || state.products.length === 0) return;
      clearInterval(checkProducts);

      state.cart = [];
      entries.forEach(function(entry) {
        let product = state.products.find(function(p) { return p.id === entry.id; });
        if (product) state.cart.push({ product: product, qty: entry.qty });
      });

      if (state.cart.length > 0) {
        saveCart();
        renderCartBody();
        setTimeout(function() {
          if (!isDesktop()) {
            dom.cartDrawer.classList.add('open');
            dom.cartOverlay.classList.add('open');
            document.body.classList.add('cart-open');
          }
          showToast('🧺 Panier partagé chargé ! ' + state.cart.length + ' article(s)', 'success');
        }, 500);
      }
      window.history.replaceState({}, '', window.location.pathname);
    }, 200);
    setTimeout(function() {
      clearInterval(checkProducts);
      if (state.cart.length === 0) showToast('⚠️ Panier partagé introuvable — réessayez depuis le lien d\'origine.', 'error');
    }, 10000);
  }

  /**
 * Appel API pour charger les données d'un panier partagé.
 * @param {string} token - Token de partage
 * @returns {Promise<Object>} Données du panier
 */
  async function _loadSharedCartFromAPI(token) {
    // GET /api/shares/:token → { sharer_name, items:[{product_id,qty,product:{...}}] }
    try {
      const data = await apiGet('/api/shares/' + encodeURIComponent(token));

      let checkProducts = setInterval(function() {
        if (!state.products || state.products.length === 0) return;
        clearInterval(checkProducts);

        state.cart = [];
        let items = data.items || data.cart_items || [];
        items.forEach(function(item) {
          // Le back peut retourner product_id ou product.id
          let pid = item.product_id || (item.product && item.product.id);
          let product = state.products.find(function(p) { return p.id === pid; });
          if (product) state.cart.push({ product: product, qty: item.qty || 1 });
        });

        if (state.cart.length > 0) {
          saveCart();
          renderCartBody();
          setTimeout(function() {
            let sharerName = data.sharer_name || data.shared_by || null;
            if (!isDesktop()) {
              dom.cartDrawer.classList.add('open');
              dom.cartOverlay.classList.add('open');
              document.body.classList.add('cart-open');
            }
            let msg = sharerName
              ? '🎁 ' + sharerName + " t'a partagé son panier !"
              : '🧺 Panier partagé chargé !';
            showToast(msg, 'success');
            if (sharerName && dom.cartHeaderTitle) {
              dom.cartHeaderTitle.textContent = '🎁 Panier de ' + sharerName;
            }
          }, 500);
        }
        window.history.replaceState({}, '', window.location.pathname);
      }, 200);
      setTimeout(function() {
        clearInterval(checkProducts);
        if (state.cart.length === 0) showToast('⚠️ Panier partagé introuvable — réessayez depuis le lien d\'origine.', 'error');
      }, 10000);
    } catch(e) {
      console.warn('[share] API error:', e);
      showToast('Impossible de charger le panier partagé.', 'error');
    }
  }

  /* ══════════════════════════════════════════════════════════
     CHECKOUT / ORDER
     ══════════════════════════════════════════════════════════ */


  // ╔══════════════════════════════════════════════════════════════════╗
//  OPTION C : Long-press sur panier tressé → stepper flottant
//  - Tap court : +1 au panier (comportement normal)
//  - Long-press (400ms) : ouvre un stepper flottant [- qty +] au-dessus
//  - Tap ailleurs : ferme le stepper
//  - Pas d'activité 3s : ferme le stepper automatiquement
// ═══════════════════════════════════════════════════════════════════════
(function setupLongPressSteppers() {
  const LONG_PRESS_MS = 400;
  const STEPPER_AUTOCLOSE_MS = 3000;
  let pressTimer = null;
  let activeStepperBtn = null;
  let autoCloseTimer = null;
  let isLongPress = false;


  // ╔══════════════════════════════════════════════════════════════════╗
  // ║  §14 · STEPPER — Bouton panier → stepper +/- avec haptic         ║
  // ╚══════════════════════════════════════════════════════════════════╝
  //  → Futur module: b-cart.js (même module §7)

  /**
   * Ferme le stepper actuellement ouvert et remet le bouton 🧺 panier à sa place.
   */
  function closeActiveStepper() {
    if (!activeStepperBtn) return;
    const stepper = activeStepperBtn.querySelector('.k-card-add-stepper');
    if (stepper) {
      stepper.classList.add('k-stepper-closing');
      setTimeout(() => stepper.remove(), 250);
    }
    activeStepperBtn.classList.remove('stepper-open');
    activeStepperBtn = null;
    if (autoCloseTimer) { clearTimeout(autoCloseTimer); autoCloseTimer = null; }
  }

  /**
   * Remet à zéro le timer d'auto-fermeture du stepper (3s sans interaction).
   */
  function resetAutoClose() {
    if (autoCloseTimer) clearTimeout(autoCloseTimer);
    autoCloseTimer = setTimeout(closeActiveStepper, STEPPER_AUTOCLOSE_MS);
  }

  /**
   * Ouvre le stepper inline sur une carte produit et anime son apparition.
   * @param {HTMLElement} btn - Bouton 🧺 qui déclenche l'ouverture
   */
  function openStepper(btn) {
    // Fermer tout autre stepper ouvert
    closeActiveStepper();

    const pid = btn.dataset.add;
    if (!pid) return;
    const item = state?.cart?.find(i => String(i.product.id) === String(pid));
    if (!item) return;

    // Vibration haptic sur iOS/Android si disponible
    if (navigator.vibrate) { try { navigator.vibrate(15); } catch(e){} }

    // Construire le stepper flottant
    const stepper = document.createElement('div');
    stepper.className = 'k-card-add-stepper';
    stepper.innerHTML =
      '<button class="k-stepper-minus" aria-label="Moins">−</button>' +
      '<span class="k-stepper-qty">' + item.qty + '</span>' +
      '<button class="k-stepper-plus" aria-label="Plus">+</button>';

    // Positionner au-dessus du panier tressé
    btn.appendChild(stepper);
    btn.classList.add('stepper-open');
    activeStepperBtn = btn;

    // Bind les +/- du stepper
    stepper.querySelector('.k-stepper-minus').addEventListener('click', function(e) {
      e.stopPropagation();
      e.preventDefault();
      const curItem = state?.cart?.find(i => String(i.product.id) === String(pid));
      if (!curItem) return closeActiveStepper();
      if (curItem.qty <= 1) {
        // Retirer du panier → ferme le stepper
        document.dispatchEvent(new CustomEvent('cart:setqty', { detail: { pid: pid, qty: 0 } }));
        closeActiveStepper();
      } else {
        document.dispatchEvent(new CustomEvent('cart:setqty', { detail: { pid: pid, qty: curItem.qty - 1 } }));
        stepper.querySelector('.k-stepper-qty').textContent = curItem.qty - 1;
        resetAutoClose();
      }
    });

    stepper.querySelector('.k-stepper-plus').addEventListener('click', function(e) {
      e.stopPropagation();
      e.preventDefault();
      const curItem = state?.cart?.find(i => String(i.product.id) === String(pid));
      if (!curItem) return;
      document.dispatchEvent(new CustomEvent('cart:setqty', { detail: { pid: pid, qty: curItem.qty + 1 } }));
      stepper.querySelector('.k-stepper-qty').textContent = curItem.qty + 1;
      resetAutoClose();
    });

    resetAutoClose();
  }

  /**
   * Démarre le chrono de long-press sur un bouton stepper (−/+).
   * Déclenche une répétition accélérée après 500ms.
   * @param {Event} e - Événement pointerdown
   */
  function startPress(e) {
    const btn = e.target.closest('.k-card-add.in-cart');
    if (!btn) return;

    isLongPress = false;
    btn.classList.add('is-long-pressing');

    pressTimer = setTimeout(() => {
      isLongPress = true;
      btn.classList.remove('is-long-pressing');
      openStepper(btn);
    }, LONG_PRESS_MS);
  }

  /**
   * Arrête la répétition du long-press et libère le pointeur.
   * @param {Event} e - Événement pointerup/pointerleave
   */
  function endPress(e) {
    const btn = e.target.closest('.k-card-add.in-cart');
    if (btn) btn.classList.remove('is-long-pressing');

    if (pressTimer) {
      clearTimeout(pressTimer);
      pressTimer = null;
    }
    // Si long-press déclenché, on bloque le click normal (qui ferait +1)
    if (isLongPress) {
      e.preventDefault();
      e.stopPropagation();
    }
    isLongPress = false;
  }

  /**
   * Annule le long-press en cours sans déclencher d'action répétée.
   */
  function cancelPress() {
    if (pressTimer) { clearTimeout(pressTimer); pressTimer = null; }
    document.querySelectorAll('.k-card-add.is-long-pressing').forEach(b => {
      b.classList.remove('is-long-pressing');
    });
    isLongPress = false;
  }

  // Bindings globaux (delegation car les cartes sont dynamiques)
  document.addEventListener('mousedown', startPress);
  document.addEventListener('touchstart', startPress, { passive: true });

  document.addEventListener('mouseup', endPress);
  document.addEventListener('touchend', endPress);

  document.addEventListener('mouseleave', cancelPress);
  document.addEventListener('touchcancel', cancelPress);

  // Click ailleurs → ferme le stepper
  document.addEventListener('click', function(e) {
    if (!activeStepperBtn) return;
    // Si on tape DANS le stepper, on ne ferme pas
    if (e.target.closest('.k-card-add-stepper')) return;
    // Si on tape sur le panier tressé qui a le stepper, on ne ferme pas (géré par le bouton lui-même)
    if (e.target.closest('.k-card-add.stepper-open')) return;
    closeActiveStepper();
  });

  // Si un click normal sur .k-card-add se déclenche ET qu'un long-press vient de finir,
  // on bloque (sinon le +1 s'ajoute en plus du stepper ouvert)
  document.addEventListener('click', function(e) {
    const btn = e.target.closest('.k-card-add');
    if (btn && btn.classList.contains('stepper-open')) {
      e.preventDefault();
      e.stopPropagation();
    }
  }, true);  // capture phase pour intercepter avant le handler normal

  // closeActiveStepper est exporté pour que d'autres modules puissent fermer le stepper
})();



// ═══════════════════════════════════════════════════════════════════════
// Placeholder adaptatif sur la barre de recherche (évite troncature)
// ═══════════════════════════════════════════════════════════════════════
(function adaptivePlaceholder() {
  /**
   * Met à jour le texte placeholder de la barre de recherche selon la catégorie active.
   * Utilise un cycle rotatif de suggestions thématiques.
   */
  const updatePlaceholder = () => {
    const input = document.getElementById('k-search-input');
    if (!input) return;
    const w = window.innerWidth;
    if (w < 380) {
      input.placeholder = 'Rechercher...';
    } else if (w < 768) {
      input.placeholder = 'Rechercher un produit...';
    } else {
      input.placeholder = 'Rechercher un produit dans le catalogue...';
    }
  };
  // À l'init et au redimensionnement
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', updatePlaceholder);
  } else {
    updatePlaceholder();
  }
  window.addEventListener('resize', updatePlaceholder);
})();



  /* ── Capture-phase listener REMOVED — handled by setupCats v2 ── */

    // ── Index flottant vertical à droite (sauts rapides entre sections) ──
  // Apparaît uniquement en mode "Tout" (sections verticales actives).
  // Se met à jour à chaque re-render de la grille sectionnée.
  /**
   * Rend l'index flottant des catégories (visible sur desktop, masqué sur mobile).
   * Génère les ancres de navigation rapide entre sections.
   */
  function _renderFloatingIndex() {
    const existing = document.getElementById('k-section-index');
    if (existing) existing.remove();

    // Uniquement en mode sections
    if (state.activeCat !== 'all' || state.activeSubcat) return;

    // Récupérer toutes les sections actuellement dans le DOM
    const headers = document.querySelectorAll('.k-sec-header');
    if (headers.length < 2) return; // inutile s'il n'y a qu'une section

    // Emoji résolu depuis shop-schema — source de vérité unique.
    // normalizeCategoryKey gère la rétrocompat dbKeys (Mode, Sur-mesure, etc.)
    const EMOJI_CAT = new Proxy({}, {
      get(_, cat) {
        const key = normalizeCategoryKey(cat);
        return getCategoryIcon(key) || '📦';
      }
    });

    const nav = document.createElement('nav');
    nav.id = 'k-section-index';
    nav.setAttribute('aria-label', 'Index des catégories');

    headers.forEach(function(h) {
      const cat = h.getAttribute('data-cat');
      const emoji = EMOJI_CAT[cat] || '📦';
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'k-section-index-btn';
      btn.setAttribute('data-cat', cat);
      btn.setAttribute('aria-label', cat);
      btn.title = cat;
      btn.innerHTML = '<span class="k-section-index-emoji">' + emoji + '</span><span class="k-section-index-label">' + cat + '</span>';
      btn.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        scrollToCategorySection(cat);
      });
      nav.appendChild(btn);
    });

    document.body.appendChild(nav);

    // ── IntersectionObserver — sync pills with visible section (vertical scroll) ──
    if (_sectionObserver) _sectionObserver.disconnect();
    // Skip on mobile pager (horizontal scroll handles sync)
    if (!isDesktop() && dom.pageScroll &&
        dom.pageScroll.classList.contains('k-pager-active')) return;
    let scroller = dom.pageScroll;
    if (scroller) {
      _sectionObserver = new IntersectionObserver(function(entries) {
        if (scroll.scrollingToSection) return;
        entries.forEach(function(entry) {
          if (!entry.isIntersecting) return;
          let cat = entry.target.dataset.cat;
          if (!cat) return;
          // Floating index buttons
          document.querySelectorAll('.k-section-index-btn').forEach(function(b) {
            b.classList.toggle('active', b.dataset.cat === cat);
          });
          // Main nav chips
          if (state.activeCat === 'all') {
            document.querySelectorAll('.k-chip').forEach(function(c) {
              c.classList.toggle('active', c.dataset.cat === cat);
            });
            let activeChip = document.querySelector('.k-chip.active');
            if (activeChip && typeof centerActiveChip === 'function') centerActiveChip(activeChip);
          }
        });
      }, { root: scroller, threshold: 0.3 });
      let sections = document.querySelectorAll('.k-cat-section');
      sections.forEach(function(sec) { _sectionObserver.observe(sec); });
    }
  }
  let _sectionObserver = null;

  /* ══════════════════════════════════════════════════════════════════ */
  /* ── TEMU-STYLE MOBILE PAGER — horizontal category page sync ───── */
  /* ══════════════════════════════════════════════════════════════════ */
  // _pagerRaf declared in _syncChipToScroll block above

// ══════════════════════════════════════════════════════════════════
// SIDE CART — Aperçu permanent desktop + total mobile bnav
// ══════════════════════════════════════════════════════════════════
function renderSideCart() {
  const sc       = document.getElementById('k-side-cart');
  const bnavLbl  = document.getElementById('k-bnav-cart-label');
  const items    = state.cart;
  const hasItems = items.length > 0;

  // Mobile bnav label : "Panier" → total ou retour
  if (bnavLbl) {
    if (hasItems) {
      bnavLbl.textContent = fmtPrice(cartTotal());
      bnavLbl.classList.add('has-total');
    } else {
      bnavLbl.textContent = 'Panier';
      bnavLbl.classList.remove('has-total');
    }
  }

  if (!sc) return;
  sc.classList.toggle('has-items', hasItems);

  // Réserve la place du side cart en bordure droite du body.
  // Double-mécanisme avec body:has(.k-side-cart.has-items) en CSS :
  // si :has() n'est pas supporté (Firefox <121), cette classe prend le relais.
  document.body.classList.toggle('sc-reserve', hasItems);

  // (--sc-offset / sc-open : plus utilisés depuis que .k-side-cart est en
  // position: fixed. La réserve de place est gérée par body.sc-reserve +
  // body:has(.k-side-cart.has-items) en CSS — voir boutique-desktop.css.)
  if (!hasItems) {
    // Vider explicitement la liste DOM pour éviter les items fantômes
    // si renderSideCart() est rappelé plus tard avec un panier de nouveau plein.
    const itemsElEmpty = sc.querySelector('#k-sc-items');
    if (itemsElEmpty) itemsElEmpty.innerHTML = '';
    return;
  }

  const qty = cartQty();

  // Sous-total
  const totalEl = sc.querySelector('#k-sc-total');
  if (totalEl) totalEl.textContent = fmtPrice(cartTotal());

  // Compteur inline dans le bouton Commander
  const countInline = sc.querySelector('#k-sc-count-inline');
  if (countInline) countInline.textContent = qty;

  // Articles (plus récents en premier)
  const itemsEl = sc.querySelector('#k-sc-items');
  if (itemsEl) {
    itemsEl.innerHTML = '';
    [...items].reverse().forEach(item => {
      const el       = document.createElement('div');
      el.className   = 'k-sc-item';
      const imgSrc   = item.product.image_url ? optimizeImgUrl(item.product.image_url, 120) : '';
      const unitPrice = item.product.price_kmf || 0;
      const linePrice = fmtPrice(unitPrice * item.qty);
      const pid      = String(item.product.id || item.id || '');
      const lineId   = lineIdOf(item);
      el.dataset.pid = pid;
      el.dataset.lineId = lineId;

      // Prix barré si promo
      const promoPct = item.product.promo_pct || 0;
      const oldPriceHtml = promoPct > 0
        ? `<span class="k-sc-item-old-price">${fmtPrice(Math.round(unitPrice / (1 - promoPct / 100)) * item.qty)}</span>`
        : '';

      // Variant sélectionné (taille, couleur…)
      const variant = item.variant_label || item.product.variant_label || '';
      const variantHtml = variant
        ? `<span class="k-sc-item-variant">${sanitize(variant)}</span>`
        : '';

      el.innerHTML =
        `<img class="k-sc-item-img" src="${imgSrc}" alt="" loading="lazy">` +
        `<div class="k-sc-item-info">` +
          `<div class="k-sc-item-name">${sanitize(item.product.name || '')}</div>` +
          variantHtml +
          `<div class="k-sc-item-meta">` +
            `<div class="k-sc-item-price-wrap">` +
              `<span class="k-sc-item-price">${linePrice}</span>` +
              oldPriceHtml +
            `</div>` +
            `<div class="k-sc-item-actions">` +
              `<div class="k-sc-item-stepper">` +
                `<button class="k-sc-step-minus" data-pid="${pid}" aria-label="Retirer un">−</button>` +
                `<span class="k-sc-item-stepper-qty">${item.qty}</span>` +
                `<button class="k-sc-step-plus" data-pid="${pid}" aria-label="Ajouter un">+</button>` +
              `</div>` +
              `<button class="k-sc-item-remove" data-pid="${pid}" aria-label="Supprimer l'article">` +
                `<svg width="11" height="11" viewBox="0 0 11 11" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><line x1="1.5" y1="1.5" x2="9.5" y2="9.5"/><line x1="9.5" y1="1.5" x2="1.5" y2="9.5"/></svg>` +
              `</button>` +
            `</div>` +
          `</div>` +
        `</div>`;
      el.querySelectorAll('.k-sc-step-minus, .k-sc-step-plus, .k-sc-item-remove')
        .forEach((button) => { button.dataset.lineId = lineId; });
      itemsEl.appendChild(el);
    });

    // Câbler les steppers (délégation sur itemsEl)
    if (!itemsEl._scWired) {
      itemsEl._scWired = true;
      itemsEl.addEventListener('click', e => {
        const minus  = e.target.closest('.k-sc-step-minus');
        const plus   = e.target.closest('.k-sc-step-plus');
        const remove = e.target.closest('.k-sc-item-remove');
        const target = minus || plus || remove;
        const lineId = target ? target.dataset.lineId : null;
        if (!lineId) return;
        const currentItem = findCartLineById(state.cart, lineId);
        if (!currentItem) return;
        if (minus) {
          setCartLineQty(lineId, currentItem.qty - 1);
        } else if (plus) {
          setCartLineQty(lineId, currentItem.qty + 1);
        } else if (remove) {
          removeCartLine(lineId);
        }
      });
    }
  }

  // Bouton "Voir le panier"
  const cta = sc.querySelector('#k-sc-cta');
  if (cta && !cta._wired) {
    cta._wired = true;
    cta.addEventListener('click', () => {
      // Desktop : ouvrir le tiroir complet (le side cart est déjà visible,
      // "Voir le panier" = accéder aux détails complets + WhatsApp + Commander)
      renderCartBody();
      dom.cartHeaderTitle.textContent = 'Mon Panier (' + cartQty() + ')';
      dom.cartOverlay.classList.add('open');
      dom.cartDrawer.classList.add('open');
      scroll.savedY = getScrollY();
      document.body.classList.add('cart-open');
    });
  }

  // SC-EDIT-04/05/06/07/08 — Mode édition panier collectif
  // Quand state.editSharedCart est actif, masquer les CTAs classiques
  // et afficher uniquement "Mettre à jour le panier collectif" + "Annuler".
  const editCtx = state.editSharedCart;

  // Gérer la visibilité des CTAs classiques
  const scCheckout = sc.querySelector('#k-sc-checkout');
  const scShare    = sc.querySelector('#k-sc-share');
  const scSharedBadge = sc.querySelector('#k-sc-shared-badge');
  if (scCheckout)   scCheckout.style.display   = editCtx ? 'none' : '';
  if (scShare)      scShare.style.display       = editCtx ? 'none' : '';
  if (scSharedBadge && editCtx) scSharedBadge.hidden = true;

  // Injecter ou mettre à jour le bandeau d'édition
  let editBar = sc.querySelector('#k-sc-edit-bar');
  if (editCtx) {
    if (!editBar) {
      editBar = document.createElement('div');
      editBar.id = 'k-sc-edit-bar';
      // Lot 2 — styles inline supprimés ; owner : cart.css § k-sc-edit-bar
      editBar.innerHTML = `
        <div class="k-sc-edit-header">
          <span>✏️</span>
          <span>Mode édition — Panier collectif</span>
        </div>
        <button id="k-sc-edit-update" type="button">
          ✅ Mettre à jour le panier collectif
        </button>
        <button id="k-sc-edit-cancel" type="button">
          ✕ Annuler les modifications
        </button>
        <p id="k-sc-edit-err"></p>`;

      // Insérer après le bloc total/sous-total, avant items
      const scHeader = sc.querySelector('.k-sc-header');
      if (scHeader) scHeader.appendChild(editBar);
      else sc.prepend(editBar);
    }

    // SC-EDIT-06 — Câbler "Mettre à jour le panier collectif"
    const updateBtn = editBar.querySelector('#k-sc-edit-update');
    if (updateBtn && !updateBtn._wired) {
      updateBtn._wired = true;
      updateBtn.addEventListener('click', async () => {
        const ctx = state.editSharedCart;
        if (!ctx) return;
        const errEl = editBar.querySelector('#k-sc-edit-err');
        if (errEl) errEl.textContent = '';

        const cartItems = (state.cart || [])
          .map(it => ({ product_id: it.product?.id || it.id, quantity: Number(it.qty) || 1 }))
          .filter(it => it.product_id);

        if (!cartItems.length) {
          if (errEl) errEl.textContent = 'Le panier est vide. Ajoutez au moins un article.';
          return;
        }

        updateBtn.disabled = true;
        updateBtn.textContent = '⏳ Mise à jour en cours…';

        try {
          // SC-EDIT-06 — Appel PUT /api/shared-carts/:id/items
          await fetch(`/api/shared-carts/${ctx.shared_cart_id}/items`, {
            method: 'PUT',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cart_items: cartItems }),
          }).then(async r => {
            if (!r.ok) {
              const d = await r.json().catch(() => ({}));
              throw new Error(d?.error || d?.message || `Erreur ${r.status}`);
            }
            return r.json();
          });

          // SC-EDIT-07 — Succès : vider panier boutique, supprimer contexte, retour onglet Groupe.
          // Le snapshot est maintenant sauvegardé en DB — le panier boutique redevient
          // disponible pour des achats normaux (même logique que N4-CLEAR à la création).
          state.editSharedCart = null;
          clearCart(); // vide state.cart + localStorage + re-render

          showToast('✅ Panier collectif mis à jour. Les participants ont été notifiés.', 'success');

          // Retour onglet Groupe + refresh de la vue groupe
          import('./b-nav.js').then(({ switchView }) => {
            document.querySelectorAll('.k-bnav-item, .k-header-nav-btn')
              .forEach(i => i.classList.toggle('active', i.dataset.tab === 'group'));
            switchView('group');
            import('./b-group-view.js').then(({ renderGroupView }) => renderGroupView());
          });
        } catch (err) {
          if (errEl) errEl.textContent = err?.message || 'Impossible de mettre à jour.';
          updateBtn.disabled = false;
          updateBtn.textContent = '✅ Mettre à jour le panier collectif';
        }
      });
    }

    // SC-EDIT-08 — Câbler "Annuler les modifications"
    const cancelBtn = editBar.querySelector('#k-sc-edit-cancel');
    if (cancelBtn && !cancelBtn._wired) {
      cancelBtn._wired = true;
      cancelBtn.addEventListener('click', () => {
        if (!confirm('Annuler les modifications ? Vous revenez dans l\'onglet Groupe sans sauvegarder.')) return;
        // SC-EDIT-08 — Supprimer le contexte d'édition — le panier boutique est laissé intact.
        state.editSharedCart = null;
        showToast('Modifications annulées.', 'success');
        // Retour onglet Groupe sans PUT
        import('./b-nav.js').then(({ switchView }) => {
          document.querySelectorAll('.k-bnav-item, .k-header-nav-btn')
            .forEach(i => i.classList.toggle('active', i.dataset.tab === 'group'));
          switchView('group');
          import('./b-group-view.js').then(({ renderGroupView }) => renderGroupView());
        });
      });
    }
  } else {
    // Plus de contexte edit : retirer le bandeau s'il existait
    editBar?.remove();
  }

  // Bouton "Commander"
  const ctaCheckout = sc.querySelector('#k-sc-checkout');
  if (ctaCheckout && !ctaCheckout._wired) {
    ctaCheckout._wired = true;
    ctaCheckout.addEventListener('click', () => {
      // ARCH-1 : remplace l'appel window.__kmrcCheckout → bus.emit.
      // boutique.js écoute 'checkout:open' et appelle checkoutCart().
      bus.emit('checkout:open');
    });
  }

  // Bouton "Partager" side-cart desktop — géré par b-share-cart.js (installé au boot)

  // Bouton "Vider" — purge complète du panier, avec confirmation native.
  // Réutilise clearCart() (mutation centralisée) — pas de duplication de
  // logique métier. La visibilité du bouton est gérée par CSS via
  // .k-side-cart.has-items (cf. boutique-desktop.css).
  const ctaClear = sc.querySelector('#k-sc-clear');
  if (ctaClear && !ctaClear._wired) {
    ctaClear._wired = true;
    ctaClear.addEventListener('click', () => {
      if (state.cart.length === 0) return;
      const ok = window.confirm('Vider le panier ? Cette action ne peut pas être annulée.');
      if (!ok) return;
      clearCart();
      showToast('🗑 Panier vidé');
    });
  }
}

// ARCH-1 : remplace window.__kmrcSideCart par un listener bus.
// Appelé par updateCartBadge (b-cart-core.js) et les surfaces qui
// ont besoin de forcer un re-rendu du side-cart desktop.
bus.on('side-cart:render', renderSideCart);

/* ── MUTATIONS CENTRALISÉES ─────────────────────────────────
 * Toute écriture sur state.cart doit passer par ces fonctions
 * pour garantir la cohérence saveCart() + rendu + badge.
 * ──────────────────────────────────────────────────────────── */

/**
 * Vide complètement le panier.
 * Remplace les patterns state.cart = []; saveCart(); renderCart();
 */
export function clearCart() {
  state.cart = [];
  saveCart();
  renderCartBody();
}

/**
 * Retire du panier les produits dont l'ID n'est plus dans validIdSet.
 * Appelé après le chargement du catalogue pour nettoyer les items obsolètes.
 * @param {Set<string>} validIdSet - Set des IDs produits valides (strings)
 */
export function pruneObsoleteCart(validIdSet) {
  const before = state.cart.length;
  state.cart = state.cart.filter(i => validIdSet.has(String(i.product.id)));
  if (state.cart.length !== before) saveCart();
}

export {
  addToCart, quickAdd, quickRemove, toggleFav, setQty,
  setCartLineQty, removeCartLine,
  openCart, closeCart, openCartWithHighlight,
  renderCartBody,
  removeFromCart, markAllCartButtons,
  shareCartWhatsApp, showShareChoiceModal, loadSharedCart,
};
// Alias pour boutique.js qui importe 'renderCart'
export { renderCartBody as renderCart };

