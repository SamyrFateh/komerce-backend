/**
 * @komerce-arch
 * @role          desktop-product-modal-renderer
 * @domain        catalog
 * @layer         ui-renderer
 * @criticality   high
 * @inputs        product_detail_v1, modal_selection_state
 * @outputs       desktop_product_modal_dom
 * @depends       b-store.js, b-utils.js, b-scroll-owner.js, b-modal-product.js, b-modal-image-ux.js, view-models/modal-selection-model.js, view-models/product-content-model.js
 * @used-by       b-modal-product-detail-bootstrap.js
 * @db-read       none
 * @db-write      none
 * @db-txn        none
 * @doctrine      docs/doctrine/DOCTRINE_PRODUCT_DETAIL_CONTRACT.md, docs/boutique/BOUTIQUE_MODAL_ARCHITECTURE.md
 * @impact-areas  product-modal, desktop, sku-selection, delivery-options, media-carousel, product-content
 * @version       2026-07 — Lot Content, commit 4 (contenu enrichi partagé)
 */

'use strict';

import { state, dom, modalZone } from './b-store.js';
import { fmtPrice, optimizeImgUrl } from './b-utils.js';
import { isDesktop } from './b-scroll-owner.js';
import {
  OPTION_STATE,
  selectModalOption,
} from './view-models/modal-selection-model.js';
import { buildCarouselSlides, goToSlide } from './b-modal-product.js';
import { setupImageUX } from './b-modal-image-ux.js';
import { getCurrentPrice, renderSubtotalInto, renderPaymentModes, startGroupCartFlow, renderPdpActions } from './b-modal-buybox-shared.js';
import {
  buildProductContentViewModel,
  shouldOfferReadMore,
  CONTENT_LABELS,
} from './view-models/product-content-model.js';

let _qtyObserver = null;
let _qtyObservedEl = null;

function isPhotoAxis(axis) {
  return /couleur|color|coloris|teinte/i.test(axis.key || axis.display_name || '');
}

function activeUnit(detail, selection) {
  return (detail.sellable_units || []).find((unit) => unit.sku_id === selection.selected_sku_id) || null;
}

// MDP-1 : le prix courant n'est plus calculé localement — il vient de
// b-modal-buybox-shared.js, la même fonction que celle utilisée en mobile.
function currentPrice(detail, selection) {
  return getCurrentPrice(detail, selection);
}

function mediaSignature(selection) {
  return (selection.selected_media || []).map((media) => `${media.id}:${media.url}`).join('|');
}

function renderMedia(detail, selection, force = false) {
  const signature = mediaSignature(selection);
  if (!force && state.modalMediaSignature === signature) return;
  state.modalMediaSignature = signature;

  const media = selection.selected_media && selection.selected_media.length
    ? selection.selected_media
    : (detail.media || []);

  buildCarouselSlides({
    name: detail.product.name,
    category: detail.product.category,
    images: media.map((item) => item.url),
    image_url: media[0]?.url || '',
  });
  goToSlide(0);
  setupImageUX();
}

function renderIdentity(detail) {
  if (dom.modalName) dom.modalName.textContent = detail.product.name;
  if (dom.modalDesc) {
    dom.modalDesc.textContent = detail.product.description || '';
    dom.modalDesc.classList.remove('is-expanded');
  }
  if (dom.modalCat) dom.modalCat.textContent = detail.product.category || '';

  const promo = Number(detail.pricing.promo_pct || 0);
  if (dom.modalPromoBadge) {
    dom.modalPromoBadge.textContent = promo > 0 ? `-${promo}%` : '';
    dom.modalPromoBadge.classList.toggle('show', promo > 0);
  }
  dom.modal?.classList.toggle('k-modal--has-promo', promo > 0);

  // Les anciennes zones reconstruisaient prix EUR, économie et faux stock depuis
  // le produit brut. PDC-5 les neutralise ; PDC-6 supprimera leur code legacy.
  const aed = document.getElementById('k-modal-aed-price');
  const flash = document.getElementById('k-modal-flash-bar');
  const stockBar = document.getElementById('k-modal-stock-bar');
  if (aed) aed.innerHTML = '';
  if (flash) flash.innerHTML = '';
  if (stockBar) stockBar.innerHTML = '';
}

function renderPriceAndReference(detail, selection) {
  const unit = activeUnit(detail, selection);
  const price = currentPrice(detail, selection);
  if (dom.modalPrice) dom.modalPrice.textContent = price != null ? fmtPrice(price) : '';

  if (dom.modalOldPrice) {
    const oldPrice = detail.pricing.old_price_kmf;
    dom.modalOldPrice.textContent = oldPrice != null ? fmtPrice(oldPrice) : '';
    dom.modalOldPrice.classList.toggle('u-hidden', oldPrice == null);
  }

  if (dom.modalSku) {
    const reference = unit?.sku || detail.product.reference;
    dom.modalSku.textContent = reference ? `Réf. ${reference}` : '';
    dom.modalSku.hidden = !reference;
  }
}

function renderStock(selection) {
  if (!dom.modalStock) return;

  if (!selection.selection_supported) {
    dom.modalStock.textContent = '';
    dom.modalStock.hidden = true;
    return;
  }

  dom.modalStock.hidden = false;
  if (selection.selected_sku_id) {
    dom.modalStock.textContent = '✓ Disponible';
    dom.modalStock.className = 'k-modal-stock k-modal-stock--ok';
    return;
  }

  dom.modalStock.textContent = Object.keys(selection.selected_options).length > 0
    ? 'Choisissez la suite'
    : 'Choisissez vos options';
  dom.modalStock.className = 'k-modal-stock';
}

// État des CTA partagé avec le renderer mobile : voir
// b-modal-buybox-shared.js#renderPdpActions. Aucun état panier local ne doit
// être réintroduit ici, afin de conserver une seule machine d'état PDP.


function optionReason(optionState) {
  if (optionState === OPTION_STATE.OUT_OF_STOCK) return 'Rupture';
  if (optionState === OPTION_STATE.INCOMPATIBLE) return 'Non proposé';
  return '';
}

function renderSelectionMessage(root, selection) {
  const message = document.createElement('p');
  message.id = 'k-modal-selection-message';
  message.className = 'k-modal-selection-message';
  message.setAttribute('role', 'status');
  message.setAttribute('aria-live', 'polite');
  message.textContent = selection.selection_message || '';
  message.hidden = !selection.selection_message;
  root.appendChild(message);
}

function renderAxis(detail, selection, axis, onSelectionChanged) {
  const group = document.createElement('section');
  group.className = 'k-vg';
  group.dataset.axisKey = axis.key;

  const label = document.createElement('div');
  label.className = 'k-vg-label';
  const type = document.createElement('span');
  type.className = 'k-vg-label-type';
  type.textContent = axis.display_name;
  const sep = document.createElement('span');
  sep.className = 'k-vg-label-sep';
  sep.textContent = '·';
  const value = document.createElement('span');
  value.className = 'k-vg-label-val';
  value.textContent = selection.selected_options[axis.key] || 'Choisir';
  label.append(type, sep, value);
  group.appendChild(label);

  const photo = isPhotoAxis(axis);
  const wrap = document.createElement('div');
  wrap.className = photo ? 'k-vg-skus' : 'k-vg-sizes';
  const states = new Map(
    (selection.option_states[axis.key] || []).map((entry) => [entry.value, entry.state])
  );

  axis.values.forEach((option) => {
    const stateValue = states.get(option.value) || OPTION_STATE.INCOMPATIBLE;
    const active = selection.selected_options[axis.key] === option.value;
    const unavailable = stateValue !== OPTION_STATE.AVAILABLE;
    const button = document.createElement('button');
    button.type = 'button';
    button.dataset.optionValue = option.value;
    button.dataset.optionState = stateValue;
    button.setAttribute('aria-pressed', active ? 'true' : 'false');
    button.setAttribute(
      'aria-label',
      `${axis.display_name} ${option.value}${unavailable ? ` — ${optionReason(stateValue)}` : ''}`
    );

    if (photo && option.thumbnail_url) {
      button.className = `k-sku${active ? ' k-sku--active' : ''}${unavailable ? ' k-vp--out' : ''}`;
      const image = document.createElement('img');
      image.src = optimizeImgUrl(option.thumbnail_url, 140);
      image.alt = '';
      image.loading = 'lazy';
      const name = document.createElement('span');
      name.className = 'k-sku-name';
      name.textContent = option.value;
      button.append(image, name);
    } else {
      button.className = `k-vp${active ? ' k-vp--active' : ''}${unavailable ? ' k-vp--out' : ''}`;
      button.textContent = option.value;
    }

    button.addEventListener('click', () => {
      state.modalSelection = selectModalOption(
        detail,
        state.modalSelection,
        axis.key,
        option.value
      );
      onSelectionChanged();
    });

    wrap.appendChild(button);
  });

  group.appendChild(wrap);
  return group;
}

function deliveryMeta(option) {
  const parts = [];
  if (option.price_kmf != null) parts.push(fmtPrice(option.price_kmf));
  if (option.eta_label) parts.push(option.eta_label);
  if (!option.available && option.unavailable_reason) parts.push(option.unavailable_reason);
  return parts.join(' · ');
}

function renderDeliveryOptions(detail) {
  const el = document.getElementById('k-modal-delivery');
  if (!el) return;
  el.innerHTML = '';

  const title = document.createElement('div');
  title.className = 'k-modal-section-title';
  title.textContent = 'Livraison';
  el.appendChild(title);

  const options = detail?.delivery_options || [];
  if (!options.length) {
    const empty = document.createElement('div');
    empty.className = 'k-modal-delivery-opt';
    empty.textContent = 'Option de livraison communiquée à la commande.';
    el.appendChild(empty);
    return;
  }

  options.forEach((option) => {
    const row = document.createElement('div');
    row.className = 'k-modal-delivery-opt';
    row.dataset.deliveryCode = option.code;

    const body = document.createElement('div');
    body.className = 'k-modal-opt-body';
    const row1 = document.createElement('div');
    row1.className = 'k-modal-opt-row1';
    const icon = document.createElement('span');
    icon.className = 'k-modal-opt-icon';
    icon.textContent = '📦';
    const label = document.createElement('span');
    label.textContent = option.label;
    row1.append(icon, label);

    const metaText = deliveryMeta(option);
    body.appendChild(row1);
    if (metaText) {
      const row2 = document.createElement('div');
      row2.className = 'k-modal-opt-row2';
      row2.textContent = metaText;
      body.appendChild(row2);
    }

    row.appendChild(body);
    el.appendChild(row);
  });
}

/* ── Lot Content, commit 4 : contenu enrichi sous la zone transactionnelle ──
 * Même view-model que le mobile (view-models/product-content-model.js) —
 * seule la composition DOM diffère. Aucun recalcul métier ici : tri,
 * filtrage, regroupement et décision "Lire la suite" viennent tous du
 * view-model partagé.
 */

function appendEnrichedTextBlock(container, { heading, text, offerReadMore }) {
  const block = document.createElement('div');
  block.className = 'k-modal-enriched-block';

  const title = document.createElement('h3');
  title.className = 'k-modal-section-title';
  title.textContent = heading;
  block.appendChild(title);

  const textEl = document.createElement('p');
  textEl.className = offerReadMore ? 'k-modal-enriched-text' : 'k-modal-enriched-text is-expanded';
  textEl.textContent = text;
  block.appendChild(textEl);

  if (offerReadMore) {
    const readMore = document.createElement('button');
    readMore.type = 'button';
    readMore.className = 'k-modal-enriched-read-more';
    readMore.textContent = 'Lire la suite';
    readMore.addEventListener('click', () => {
      const expanded = textEl.classList.toggle('is-expanded');
      readMore.textContent = expanded ? 'Réduire' : 'Lire la suite';
    });
    block.appendChild(readMore);
  }

  container.appendChild(block);
}

function appendEnrichedBulletBlock(container, { heading, items, variant }) {
  if (!items.length) return;
  const block = document.createElement('div');
  block.className = `k-modal-enriched-block k-modal-enriched-block--${variant}`;

  const title = document.createElement('h3');
  title.className = 'k-modal-section-title';
  title.textContent = heading;
  block.appendChild(title);

  const list = document.createElement('ul');
  list.className = 'k-modal-enriched-bullet-list';
  items.forEach((item) => {
    const li = document.createElement('li');
    li.textContent = item;
    list.appendChild(li);
  });
  block.appendChild(list);
  container.appendChild(block);
}

function appendEnrichedKeyValueBlock(container, { heading, entries }) {
  const block = document.createElement('div');
  block.className = 'k-modal-enriched-block k-modal-enriched-block--specs';

  const title = document.createElement('h3');
  title.className = 'k-modal-section-title';
  title.textContent = heading;
  block.appendChild(title);

  const dl = document.createElement('dl');
  dl.className = 'k-modal-enriched-spec-list';
  entries.forEach(({ label, value }) => {
    const dt = document.createElement('dt');
    dt.textContent = label;
    const dd = document.createElement('dd');
    dd.textContent = value;
    dl.appendChild(dt);
    dl.appendChild(dd);
  });
  block.appendChild(dl);
  container.appendChild(block);
}

function appendEnrichedSpecifications(container, specificationGroups) {
  if (!specificationGroups.length) return;
  const block = document.createElement('div');
  block.className = 'k-modal-enriched-block k-modal-enriched-block--specs';

  const title = document.createElement('h3');
  title.className = 'k-modal-section-title';
  title.textContent = CONTENT_LABELS.specifications;
  block.appendChild(title);

  specificationGroups.forEach((group) => {
    if (group.group) {
      const groupLabel = document.createElement('div');
      groupLabel.className = 'k-modal-enriched-spec-group-label';
      groupLabel.textContent = group.group;
      block.appendChild(groupLabel);
    }
    const dl = document.createElement('dl');
    dl.className = 'k-modal-enriched-spec-list';
    group.items.forEach((item) => {
      const dt = document.createElement('dt');
      dt.textContent = item.label;
      const dd = document.createElement('dd');
      dd.textContent = item.unit ? `${item.value} ${item.unit}` : item.value;
      dl.appendChild(dt);
      dl.appendChild(dd);
    });
    block.appendChild(dl);
  });

  container.appendChild(block);
}

/**
 * Rend content.* dans #k-modal-enriched-content, sous la zone transactionnelle
 * (galerie + buy box). No-op si le conteneur est absent du shell (compat
 * markup non encore migré) ou si le produit n'a aucune matière enrichie —
 * jamais de bloc vide, comme en mobile.
 */
function renderEnrichedContent(detail) {
  const container = document.getElementById('k-modal-enriched-content');
  if (!container) return;
  container.innerHTML = '';

  const vm = buildProductContentViewModel(detail.content);
  if (!vm.hasEnrichedContent) {
    container.hidden = true;
    return;
  }
  container.hidden = false;

  appendEnrichedBulletBlock(container, { heading: CONTENT_LABELS.highlights, items: vm.highlights.map((h) => h.label), variant: 'highlights' });
  appendEnrichedSpecifications(container, vm.specificationGroups);
  appendEnrichedBulletBlock(container, { heading: CONTENT_LABELS.materials, items: vm.materials, variant: 'materials' });
  appendEnrichedBulletBlock(container, { heading: CONTENT_LABELS.care, items: vm.care, variant: 'care' });
  appendEnrichedBulletBlock(container, { heading: CONTENT_LABELS.warnings, items: vm.warnings, variant: 'warnings' });

  vm.sections.forEach((section) => {
    if (section.type === 'TEXT') {
      appendEnrichedTextBlock(container, { heading: section.title, text: section.text, offerReadMore: section.offer_read_more });
    } else if (section.type === 'BULLETS') {
      appendEnrichedBulletBlock(container, { heading: section.title, items: section.items, variant: 'editorial' });
    } else if (section.type === 'KEY_VALUE') {
      appendEnrichedKeyValueBlock(container, { heading: section.title, entries: section.entries });
    }
  });
}

function renderSubtotal(detail, selection) {
  const actions = modalZone('.k-modal-actions');
  if (!actions) return;
  let subtotal = actions.querySelector('.k-modal-subtotal');
  if (!subtotal) {
    subtotal = document.createElement('div');
    subtotal.className = 'k-modal-subtotal';
    actions.appendChild(subtotal);
  }

  renderSubtotalInto(subtotal, detail, selection, state.modalQty);
}

function renderPaymentSection(detail, selection) {
  const el = document.getElementById('k-modal-payment');
  if (!el) return;

  renderPaymentModes(el, {
    activeMode: state.modalPaymentMode,
    onModeChange: (key) => { state.modalPaymentMode = key; },
    onGroupSelect: () => {
      startGroupCartFlow(state.modalProduct, state.modalQty, el);
    },
  });
}

function ensureQtyObserver() {
  const qtyEl = dom.modalQtyVal;
  if (!qtyEl || typeof MutationObserver === 'undefined') return;
  if (_qtyObserver && _qtyObservedEl === qtyEl) return;

  if (_qtyObserver) _qtyObserver.disconnect();
  _qtyObservedEl = qtyEl;
  _qtyObserver = new MutationObserver(() => {
    if (!isDesktop() || !state.modalProductDetail || !state.modalSelection) return;
    renderSubtotal(state.modalProductDetail, state.modalSelection);
  });
  _qtyObserver.observe(qtyEl, {
    childList: true,
    characterData: true,
    subtree: true,
  });
}

/**
 * Composition desktop : galerie à gauche et Buy Box à droite. Toute disponibilité
 * provient de `selection`; ce renderer ne lit jamais product_variants.stock.
 */
export function renderDesktopProductDetail(detail, selection, { forceMedia = false } = {}) {
  const container = dom.modalVariants || document.getElementById('k-modal-variants');
  if (!container || !isDesktop()) return;

  state.modalProductDetail = detail;
  state.modalSelection = selection;
  state.modalVariantCombo = selection.selection_supported
    ? { ...selection.selected_options }
    : {};

  function rerender() {
    renderDesktopProductDetail(detail, state.modalSelection);
  }

  container.innerHTML = '';
  const root = document.createElement('div');
  root.dataset.pdc5Root = '1';
  container.appendChild(root);

  if (selection.selection_supported) {
    (detail.option_axes || []).forEach((axis) => {
      root.appendChild(renderAxis(detail, selection, axis, rerender));
    });
  }
  renderSelectionMessage(root, selection);

  renderIdentity(detail);
  renderPriceAndReference(detail, selection);
  renderStock(selection);
  renderPdpActions(detail, selection);
  renderDeliveryOptions(detail);
  renderSubtotal(detail, selection);
  renderPaymentSection(detail, selection);
  renderEnrichedContent(detail);
  renderMedia(detail, selection, forceMedia);
  ensureQtyObserver();
}

export function refreshDesktopProductSubtotal() {
  if (!state.modalProductDetail || !state.modalSelection) return;
  renderSubtotal(state.modalProductDetail, state.modalSelection);
}

export function clearDesktopProductDetailState() {
  if (_qtyObserver) _qtyObserver.disconnect();
  _qtyObserver = null;
  _qtyObservedEl = null;
}
