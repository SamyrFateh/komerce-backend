/**
 * @komerce-arch
 * @role          cart-line-identity
 * @domain        catalog
 * @layer         pure-logic
 * @criticality   high
 * @inputs        cart_item, product, variant_combo
 * @outputs       line_id
 * @depends       none
 * @used-by       b-cart.js, view-models/modal-cart-state.js
 * @doctrine      docs/doctrine/DOCTRINE_PRODUCT_DETAIL_CONTRACT.md
 * @impact-areas  cart, product-modal, side-cart
 * @version       2026-07 — lot PDP-1
 */

'use strict';

/**
 * Une ligne panier = un produit + une combinaison de variante (ou aucune).
 * Deux ajouts du même produit avec des combinaisons différentes sont deux
 * lignes distinctes (cf. pdp-mobile-spec.md §6 : "Un changement de variante
 * ou de taille = nouvelle identité produit").
 *
 * AVANT ce module, `setQty`/`removeFromCart` (js/b-cart.js) et le stepper du
 * panier latéral (`k-sc-item-stepper`) résolvaient la ligne à modifier par
 * SEUL `product.id`, via `state.cart.find(i => i.product.id === pid)` — le
 * PREMIER match. Avec deux variantes du même produit dans le panier (courant
 * depuis la migration SKU), incrémenter/retirer la ligne B pouvait muter la
 * ligne A. `line_id` élimine cette ambiguïté : c'est la SEULE clé qui
 * identifie une ligne panier dans toute la boutique (fiche produit,
 * suggestions, panier latéral, tiroir panier).
 */
/**
 * A1 (rapport pré-merge) : `combo` est un objet dont l'ordre des clés
 * dépend de l'ordre de sélection utilisateur (ex. Couleur puis Taille, ou
 * l'inverse) — deux sélections logiquement identiques produisaient donc
 * deux line_id différents via JSON.stringify (qui préserve l'ordre
 * d'insertion). On trie les clés avant sérialisation pour garantir une
 * représentation canonique indépendante de l'ordre de sélection.
 */
function canonicalizeCombo(combo) {
  const sortedEntries = Object.keys(combo).sort().map((key) => [key, combo[key]]);
  return Object.fromEntries(sortedEntries);
}

export function computeLineId(product, combo) {
  const productId = String(product?.id ?? '');
  const comboKey = combo && Object.keys(combo).length > 0
    ? JSON.stringify(canonicalizeCombo(combo))
    : 'null';
  return `${productId}::${comboKey}`;
}

/**
 * line_id d'un item panier déjà existant. Utilise `item.line_id` s'il est
 * présent (items créés après ce lot), sinon le recalcule depuis
 * `product`/`variant_combo` (items déjà persistés en localStorage avant ce
 * lot — aucune migration de données nécessaire, le recalcul est stable).
 */
export function lineIdOf(item) {
  if (!item) return null;
  if (item.line_id) return item.line_id;
  const product = item.product || { id: item.id };
  return computeLineId(product, item.variant_combo || null);
}

export function findCartLine(cart, product, combo) {
  const target = computeLineId(product, combo);
  return (cart || []).find((item) => lineIdOf(item) === target) || null;
}

export function findCartLineById(cart, lineId) {
  if (!lineId) return null;
  return (cart || []).find((item) => lineIdOf(item) === lineId) || null;
}
