/**
 * @komerce-arch
 * @role          product-modal-buybox-shared-logic
 * @domain        catalog
 * @layer         view-model
 * @criticality   high
 * @inputs        product_detail_v1, modal_selection_state, modal_qty, modal_payment_mode
 * @outputs       buybox_price_projection, buybox_payment_dom
 * @depends       b-utils.js, b-modal.js, b-cart.js, b-share-cart.js
 * @used-by       b-modal-mobile-product.js, b-modal-desktop-product.js, b-modal-approche-c-hybrid.js
 * @db-read       none
 * @db-write      none
 * @db-txn        none
 * @doctrine      docs/doctrine/DOCTRINE_PRODUCT_DETAIL_CONTRACT.md, docs/boutique/BOUTIQUE_MODAL_ARCHITECTURE.md
 * @impact-areas  product-modal, mobile, desktop, sku-selection, checkout-entry
 * @version       2026-07
 */

'use strict';

/**
 * MDP-1 / MDP-2 — Logique Buy Box partagée entre les deux compositions.
 *
 * Ce module ne rend rien de lui-même dans une zone fixe : il expose des
 * fonctions pures (prix, sous-total) et un rendu de sélecteur de paiement
 * paramétré par l'élément cible, pour que mobile et desktop appellent
 * exactement le même calcul et la même logique de bascule de mode, chacun
 * avec son propre placement DOM.
 *
 * UNE VÉRITÉ (prix SKU du Product Detail Contract, modes de paiement,
 * handler "panier partagé") + PLUSIEURS PROJECTIONS UI (mobile / desktop).
 * Aucun état de sélection ou de prix n'est dupliqué ici : tout est dérivé de
 * `detail`/`selection` reçus en paramètre, jamais lu depuis un state legacy.
 */

import { fmtPrice } from './b-utils.js';
import { state, dom } from './b-store.js';
import { closeModal } from './b-modal.js';
import { addToCart, setCartLineQty, removeCartLine } from './b-cart.js';
import { startShareFlow } from './b-share-cart.js';
import { resolvePdpCartState, PDP_CART_STATUS } from './view-models/modal-cart-state.js';

/**
 * Prix courant : celui de l'unité SKU sélectionnée si elle existe, sinon le
 * prix produit du contrat. Jamais de fallback vers un champ produit legacy
 * (ex. state.modalProduct.price_kmf).
 */
export function getCurrentPrice(detail, selection) {
  const unit = (detail?.sellable_units || [])
    .find((candidate) => candidate.sku_id === selection?.selected_sku_id) || null;
  return unit?.price_kmf ?? detail?.pricing?.price_kmf ?? null;
}

/**
 * Sous-total = prix courant × quantité (bornée à 1 minimum). Retourne null
 * si aucun prix n'est disponible (contrat incomplet) : c'est à l'appelant de
 * décider comment refléter cette absence (ex. vider le texte).
 */
export function computeSubtotal(detail, selection, qty) {
  const price = getCurrentPrice(detail, selection);
  if (price == null) return null;
  const safeQty = Math.max(1, Number(qty) || 1);
  return price * safeQty;
}

/**
 * Rend le sous-total texte dans `el` (élément déjà positionné par la
 * composition appelante). Ne crée ni ne déplace `el` : c'est le rôle du
 * renderer viewport.
 */
export function renderSubtotalInto(el, detail, selection, qty) {
  if (!el) return;
  const total = computeSubtotal(detail, selection, qty);
  if (total == null) {
    el.textContent = '';
    return;
  }
  el.textContent = 'Sous-total : ';
  const strong = document.createElement('strong');
  strong.textContent = fmtPrice(total);
  el.appendChild(strong);
}

export const PAYMENT_MODES = Object.freeze({
  stripe: { icon: '💳', tab: 'Carte', title: 'Carte bancaire', sub: 'Visa, Mastercard — Stripe sécurisé', badge: 'Stripe' },
  cash:   { icon: '💵', tab: 'Livraison', title: 'Paiement à la livraison', sub: 'En espèces à la réception', badge: 'Cash' },
  group:  { icon: '👥', tab: 'Partagé', title: 'Panier partagé', sub: 'Invitez des proches à contribuer', badge: 'Partage' },
  pot:    { icon: '🎁', tab: 'Cagnotte', title: 'Cagnotte collective', sub: 'Offrir ensemble, payer ensemble', badge: 'Collectif' },
});

function buildPaymentDetail(key) {
  const mode = PAYMENT_MODES[key] || PAYMENT_MODES.stripe;
  const detail = document.createElement('div');
  detail.className = 'k-buybox-payment-detail';
  detail.dataset.payDetail = key;

  const check = document.createElement('span');
  check.className = 'k-buybox-payment-check';
  check.setAttribute('aria-hidden', 'true');

  const icon = document.createElement('span');
  icon.className = 'k-buybox-payment-icon';
  icon.setAttribute('aria-hidden', 'true');
  icon.textContent = mode.icon;

  const copy = document.createElement('span');
  copy.className = 'k-buybox-payment-copy';
  const title = document.createElement('strong');
  title.textContent = mode.title;
  const sub = document.createElement('small');
  sub.textContent = mode.sub;
  copy.append(title, sub);

  const badge = document.createElement('span');
  badge.className = 'k-buybox-payment-badge';
  badge.textContent = mode.badge;

  detail.append(check, icon, copy, badge);
  return detail;
}

/**
 * Démarre le parcours "panier partagé" : ajoute le produit courant au
 * panier, ferme la modal, puis ouvre le flux de partage. Logique unique,
 * appelable depuis n'importe quelle composition (mobile ou desktop) sans la
 * réécrire.
 */
export function startGroupCartFlow(product, qty, sourceEl) {
  if (!product) return;
  addToCart(product, qty || 1, sourceEl);
  closeModal();
  setTimeout(() => startShareFlow(), 250);
}

/**
 * Rend le sélecteur de mode de paiement (tabs + détail du mode actif) dans
 * `el`. `el` est fourni par la composition appelante (mobile ou desktop) ;
 * ce module ne décide jamais de son emplacement dans le DOM ni de son style
 * — seulement de sa structure et de son comportement.
 *
 * @param {HTMLElement} el
 * @param {Object}   opts
 * @param {string}   [opts.activeMode]   mode actif ('stripe' par défaut)
 * @param {Function} [opts.onModeChange] (key) => void, appelé quand l'utilisateur change de mode (hors "group")
 * @param {Function} [opts.onGroupSelect] (tabEl) => void, appelé quand "Panier partagé" est choisi ; si absent, startGroupCartFlow n'est PAS déclenché automatiquement
 */
export function renderPaymentModes(el, { activeMode, onModeChange, onGroupSelect } = {}) {
  if (!el) return;
  const active = (activeMode && PAYMENT_MODES[activeMode]) ? activeMode : 'stripe';

  while (el.firstChild) el.removeChild(el.firstChild);

  const title = document.createElement('div');
  title.className = 'k-modal-section-title';
  title.textContent = 'Mode de paiement';

  const tabs = document.createElement('div');
  tabs.className = 'k-buybox-payment-tabs';
  tabs.setAttribute('role', 'tablist');
  tabs.setAttribute('aria-label', 'Mode de paiement');

  const wrap = document.createElement('div');
  wrap.className = 'k-buybox-payment-detail-wrap';

  Object.keys(PAYMENT_MODES).forEach((key) => {
    const mode = PAYMENT_MODES[key];
    const tab = document.createElement('button');
    tab.type = 'button';
    tab.className = 'k-buybox-payment-tab' + (key === active ? ' is-active' : '');
    tab.dataset.pay = key;
    tab.setAttribute('role', 'tab');
    tab.setAttribute('aria-selected', key === active ? 'true' : 'false');

    const icon = document.createElement('span');
    icon.setAttribute('aria-hidden', 'true');
    icon.textContent = mode.icon;
    const label = document.createElement('span');
    label.textContent = mode.tab;
    tab.append(icon, label);

    tab.addEventListener('click', () => {
      if (key === 'group') {
        onGroupSelect && onGroupSelect(tab);
        return;
      }

      tabs.querySelectorAll('.k-buybox-payment-tab').forEach((button) => {
        const isActive = button === tab;
        button.classList.toggle('is-active', isActive);
        button.setAttribute('aria-selected', isActive ? 'true' : 'false');
      });
      while (wrap.firstChild) wrap.removeChild(wrap.firstChild);
      wrap.appendChild(buildPaymentDetail(key));
      onModeChange && onModeChange(key);
    });

    tabs.appendChild(tab);
  });

  wrap.appendChild(buildPaymentDetail(active));
  el.append(title, tabs, wrap);
}

/* ── PDP-1 (2026-07) : machine d'état panier partagée mobile/desktop ──
 *
 * pdp-mobile-spec.md §6/§7.3-7.5, pdp-desktop-spec.md §9.7-9.8/§13 : les
 * CTA de la fiche produit basculent entre deux compositions qui se
 * remplacent (jamais côte à côte) :
 *
 *   AVAILABLE_EMPTY    → "Ajouter au panier" + "Acheter maintenant"
 *   AVAILABLE_FILLED   → Stepper (qty déjà au panier) + "Acheter maintenant"
 *   OUT_OF_STOCK       → un seul bouton pleine largeur "Me prévenir"
 *   SELECTION_REQUIRED → CTA désactivés (comportement déjà existant)
 *
 * Ce module ne connaît ni mobile ni desktop : il reçoit les éléments DOM
 * concrets (déjà placés par la composition appelante) et pilote leur
 * visibilité/état à partir de resolvePdpCartState(). Câblage des listeners
 * fait une seule fois par jeu d'éléments (WeakSet) — rappelé à chaque
 * render, jamais dupliqué.
 *
 * Périmètre volontaire : uniquement `inventory_model === 'SKU'`. Pour un
 * produit legacy, `sellable_units` est vide (doctrine §6) donc il n'existe
 * aucune vérité de rupture par unité — le comportement historique (CTA
 * toujours actifs, stepper de pré-ajout désactivé) reste inchangé pour lui,
 * en attendant PDC-7.
 */

const _wiredActionRoots = new WeakSet();

function currentPdpContext() {
  return { detail: state.modalProductDetail, selection: state.modalSelection };
}

function handleAdd(sourceBtn) {
  const { detail } = currentPdpContext();
  if (!detail) return;
  addToCart(detail.product, 1, sourceBtn || null);
}

function handleIncrement() {
  const { detail, selection } = currentPdpContext();
  if (!detail || !selection) return;
  const cartState = resolvePdpCartState(detail, selection, state.cart);
  if (cartState.status === PDP_CART_STATUS.AVAILABLE_FILLED) {
    setCartLineQty(cartState.lineId, cartState.qty + 1);
  } else if (cartState.status === PDP_CART_STATUS.AVAILABLE_EMPTY) {
    addToCart(detail.product, 1, null);
  }
}

function handleDecrement() {
  const { detail, selection } = currentPdpContext();
  if (!detail || !selection) return;
  const cartState = resolvePdpCartState(detail, selection, state.cart);
  if (cartState.status !== PDP_CART_STATUS.AVAILABLE_FILLED) return;
  if (cartState.qty <= 1) removeCartLine(cartState.lineId);
  else setCartLineQty(cartState.lineId, cartState.qty - 1);
}

/**
 * Rend l'état courant des CTA panier dans les éléments fournis et câble
 * leurs interactions (une seule fois par jeu d'éléments).
 *
 * @param {Object} elements
 * @param {HTMLElement} elements.addBtn    - "Ajouter au panier"
 * @param {HTMLElement} elements.buyBtn    - "Acheter maintenant"
 * @param {HTMLElement} elements.qtyWrap   - conteneur stepper (masqué/affiché en bloc)
 * @param {HTMLElement} [elements.qtyMinus]
 * @param {HTMLElement} [elements.qtyPlus]
 * @param {HTMLElement} [elements.qtyVal]
 * @param {HTMLElement} [elements.notifyBtn] - "Me prévenir" (rupture)
 * @param {Object} [detail]    - product_detail_v1 ; par défaut state.modalProductDetail
 * @param {Object} [selection] - modal_selection_state ; par défaut state.modalSelection
 */
export function syncBuyboxActions(elements, detail, selection) {
  const { addBtn, buyBtn, qtyWrap, qtyMinus, qtyPlus, qtyVal, notifyBtn } = elements || {};
  if (!addBtn || !buyBtn || !qtyWrap) return;

  if (detail === undefined) ({ detail, selection } = currentPdpContext());
  if (!detail || !selection || detail.inventory_model !== 'SKU') return;

  const cartState = resolvePdpCartState(detail, selection, state.cart);
  const { status } = cartState;

  const outOfStock = status === PDP_CART_STATUS.OUT_OF_STOCK;
  const filled = status === PDP_CART_STATUS.AVAILABLE_FILLED;
  const selectionRequired = status === PDP_CART_STATUS.SELECTION_REQUIRED;

  if (notifyBtn) notifyBtn.hidden = !outOfStock;
  addBtn.hidden = outOfStock || filled;
  buyBtn.hidden = outOfStock;
  qtyWrap.hidden = !filled;

  // B2 (rapport pré-merge) : la disposition du footer (empty / filled /
  // out-of-stock) doit être pilotée par un attribut explicite plutôt que
  // devinée depuis la visibilité individuelle des boutons — data-cart-state
  // est l'unique source de vérité consommée par le CSS (modal-shell.css).
  const actionsRoot = qtyWrap.closest('.k-modal-actions');
  if (actionsRoot) {
    actionsRoot.dataset.cartState = outOfStock
      ? 'out-of-stock'
      : filled
        ? 'filled'
        : 'empty';
  }

  addBtn.disabled = selectionRequired;
  buyBtn.disabled = selectionRequired;
  if (selectionRequired) {
    addBtn.setAttribute('aria-describedby', 'k-modal-selection-message');
    buyBtn.setAttribute('aria-describedby', 'k-modal-selection-message');
  } else {
    addBtn.removeAttribute('aria-describedby');
    buyBtn.removeAttribute('aria-describedby');
  }
  if (qtyMinus) qtyMinus.disabled = !filled;
  if (qtyPlus) qtyPlus.disabled = !filled;

  if (filled && qtyVal) qtyVal.textContent = String(cartState.qty);

  if (!_wiredActionRoots.has(qtyWrap)) {
    _wiredActionRoots.add(qtyWrap);
    addBtn.addEventListener('click', () => {
      if (addBtn.disabled) return;
      handleAdd(addBtn);
      syncBuyboxActions(elements);
    });
    qtyMinus?.addEventListener('click', () => {
      handleDecrement();
      syncBuyboxActions(elements);
    });
    qtyPlus?.addEventListener('click', () => {
      handleIncrement();
      syncBuyboxActions(elements);
    });
  }
}

/**
 * Point d'entrée unique pour l'état des CTA transactionnels de la fiche
 * produit (Ajouter/Acheter/Stepper/Me prévenir), appelé à l'identique par
 * b-modal-mobile-product.js et b-modal-desktop-product.js.
 *
 * Remplace les deux fonctions `renderActions(detail, selection)` qui
 * existaient auparavant en double, mot pour mot, dans les deux fichiers —
 * violation directe du principe "une seule logique produit partagée" (une
 * des deux aurait fini par diverger de l'autre au premier correctif oublié
 * d'un côté). Une seule implémentation, deux appelants.
 *
 * - Produit non-SKU (LEGACY_VARIANTS, doctrine §6, PDC-7 non livré) :
 *   comportement historique inchangé — CTA actifs/désactivés selon la
 *   sélection, stepper de pré-ajout désactivé (mutation product-id-first
 *   invalide pour cette voie, cf. PDC-6).
 * - Produit SKU : délègue entièrement à syncBuyboxActions(), qui pilote la
 *   machine d'état complète (AVAILABLE_EMPTY/FILLED/OUT_OF_STOCK/
 *   SELECTION_REQUIRED) sur les mêmes boutons statiques.
 */
export function renderPdpActions(detail, selection) {
  const isSku = detail.inventory_model === 'SKU';

  if (isSku) {
    syncBuyboxActions({
      addBtn: dom.addCartBtn,
      buyBtn: dom.buyNowBtn,
      qtyWrap: dom.qtyWrap,
      qtyMinus: dom.qtyMinus,
      qtyPlus: dom.qtyPlus,
      qtyVal: dom.modalQtyVal,
      notifyBtn: dom.notifyBtn,
    }, detail, selection);
    return;
  }

  // Legacy (non-SKU) : comportement historique, aucune notion de rupture
  // par unité (PDC-7 non livré) — jamais de OUT_OF_STOCK ici. Les 3 CTA
  // (stepper + ajouter + acheter) restent visibles simultanément, ce qui
  // ne correspond à aucun des 3 états du nouveau modèle SKU (B2) : on pose
  // un data-cart-state dédié pour que le CSS conserve l'ancienne grille
  // 2-lignes uniquement pour cette voie, sans toucher au flux SKU.
  if (dom.notifyBtn) dom.notifyBtn.hidden = true;
  if (dom.qtyWrap) dom.qtyWrap.hidden = false;
  const legacyActionsRoot = dom.qtyWrap?.closest('.k-modal-actions');
  if (legacyActionsRoot) legacyActionsRoot.dataset.cartState = 'legacy';

  const enabled = true; // non-SKU : toujours actif (pas de vérité de rupture par unité, PDC-7)
  [dom.addCartBtn, dom.buyNowBtn].forEach((button) => {
    if (!button) return;
    button.hidden = false;
    button.disabled = !enabled;
    if (!enabled) button.setAttribute('aria-describedby', 'k-modal-selection-message');
    else button.removeAttribute('aria-describedby');
  });

  [dom.qtyMinus, dom.qtyPlus].forEach((control) => {
    if (control) control.disabled = false;
  });
}

export const _buyboxSharedTestApi = Object.freeze({
  buildPaymentDetail,
  handleAdd,
  handleIncrement,
  handleDecrement,
});
