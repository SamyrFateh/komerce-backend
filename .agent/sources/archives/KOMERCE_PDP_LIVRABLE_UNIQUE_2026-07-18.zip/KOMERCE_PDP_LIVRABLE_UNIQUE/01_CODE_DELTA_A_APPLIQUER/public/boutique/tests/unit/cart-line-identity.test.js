'use strict';

/**
 * tests/unit/cart-line-identity.test.js
 *
 * cart-line-identity.js est le module pur qui remplace le lookup
 * `product.id` seul (bug : deux variantes du même produit au panier
 * fusionnaient sous le premier match). Couvre computeLineId / lineIdOf /
 * findCartLine / findCartLineById — cf. diagnostic PDP-1.
 */

const {
  computeLineId,
  lineIdOf,
  findCartLine,
  findCartLineById,
} = require('../../js/cart-line-identity.js');

describe('cart-line-identity — computeLineId', () => {
  test('même produit, même combo → même line_id', () => {
    const p = { id: 'p1' };
    expect(computeLineId(p, { Couleur: 'Rouge' })).toBe(computeLineId(p, { Couleur: 'Rouge' }));
  });

  test('même produit, combo différent → line_id différent (le bug PDP-1)', () => {
    const p = { id: 'p1' };
    const a = computeLineId(p, { Couleur: 'Rouge', Taille: '44' });
    const b = computeLineId(p, { Couleur: 'Bleu', Taille: '42' });
    expect(a).not.toBe(b);
  });

  test('combo null/undefined/vide → tous équivalents ("aucune variante")', () => {
    const p = { id: 'p1' };
    expect(computeLineId(p, null)).toBe(computeLineId(p, undefined));
    expect(computeLineId(p, {})).toBe(computeLineId(p, null));
  });

  test('produit différent, même combo → line_id différent', () => {
    const combo = { Couleur: 'Rouge' };
    expect(computeLineId({ id: 'p1' }, combo)).not.toBe(computeLineId({ id: 'p2' }, combo));
  });

  test('A1 (rapport pré-merge) — ordre des clés du combo indifférent : même sélection logique → même line_id', () => {
    const p = { id: 'p1' };
    const a = computeLineId(p, { Couleur: 'Rouge', Taille: '44' });
    const b = computeLineId(p, { Taille: '44', Couleur: 'Rouge' });
    expect(a).toBe(b);
  });
});

describe('cart-line-identity — lineIdOf (items déjà en panier)', () => {
  test('utilise item.line_id si présent (items créés après ce lot)', () => {
    const item = { line_id: 'explicit-id', product: { id: 'p1' }, variant_combo: { Couleur: 'Rouge' } };
    expect(lineIdOf(item)).toBe('explicit-id');
  });

  test('recalcule depuis product/variant_combo si line_id absent (items persistés avant ce lot — aucune migration nécessaire)', () => {
    const item = { product: { id: 'p1' }, variant_combo: { Couleur: 'Rouge' } };
    expect(lineIdOf(item)).toBe(computeLineId({ id: 'p1' }, { Couleur: 'Rouge' }));
  });

  test('item null/undefined → null (fail-safe)', () => {
    expect(lineIdOf(null)).toBeNull();
    expect(lineIdOf(undefined)).toBeNull();
  });
});

describe('cart-line-identity — findCartLine / findCartLineById', () => {
  const product = { id: 'p1' };
  const cart = [
    { product, qty: 2, variant_combo: { Couleur: 'Rouge', Taille: '44' } },
    { product, qty: 1, variant_combo: { Couleur: 'Bleu', Taille: '42' } },
  ];

  test('findCartLine résout la ligne EXACTE parmi plusieurs variantes du même produit', () => {
    const line = findCartLine(cart, product, { Couleur: 'Bleu', Taille: '42' });
    expect(line.qty).toBe(1);
  });

  test('findCartLine ne confond jamais deux variantes du même produit (régression du bug diagnostiqué)', () => {
    const rouge = findCartLine(cart, product, { Couleur: 'Rouge', Taille: '44' });
    const bleu = findCartLine(cart, product, { Couleur: 'Bleu', Taille: '42' });
    expect(rouge.qty).toBe(2);
    expect(bleu.qty).toBe(1);
    expect(rouge).not.toBe(bleu);
  });

  test('findCartLine renvoie null si aucune ligne ne correspond', () => {
    expect(findCartLine(cart, product, { Couleur: 'Vert' })).toBeNull();
  });

  test('findCartLineById résout par line_id direct', () => {
    const id = computeLineId(product, { Couleur: 'Rouge', Taille: '44' });
    expect(findCartLineById(cart, id).qty).toBe(2);
  });

  test('findCartLineById fail-safe sur lineId/cart vides', () => {
    expect(findCartLineById(cart, null)).toBeNull();
    expect(findCartLineById(undefined, 'whatever')).toBeNull();
  });
});
