/**
 * @komerce-arch
 * @role          product-modal-cart-state-resolver
 * @domain        catalog
 * @layer         view-model
 * @criticality   high
 * @inputs        product_detail_v1, modal_selection_state, cart_items
 * @outputs       pdp_cart_state
 * @depends       cart-line-identity.js
 * @used-by       b-modal-buybox-shared.js
 * @db-read       none
 * @db-write      none
 * @db-txn        none
 * @doctrine      docs/doctrine/DOCTRINE_PRODUCT_DETAIL_CONTRACT.md, docs/boutique/BOUTIQUE_MODAL_ARCHITECTURE.md
 * @impact-areas  product-modal, mobile, desktop, sku-selection, checkout-entry
 * @version       2026-07 — lot PDP-1 (B2, rapport pré-merge PDP1/PDP2)
 */

'use strict';

import { computeLineId, findCartLineById } from '../cart-line-identity.js';

/**
 * B2 (rapport pré-merge) : la fiche produit a besoin d'une SEULE source de
 * vérité pour savoir dans laquelle des 4 compositions CTA elle se trouve
 * (cf. pdp-mobile-spec.md §6, pdp-desktop-spec.md §9.7-9.8/§13) :
 *
 *   SELECTION_REQUIRED → sélection de variante incomplète, CTA désactivés
 *   OUT_OF_STOCK       → sélection complète mais aucune unité disponible
 *   AVAILABLE_EMPTY    → SKU disponible résolu, pas encore au panier
 *   AVAILABLE_FILLED   → SKU disponible résolu, déjà au panier (qty ≥ 1)
 *
 * Ce module ne calcule PAS l'état de sélection lui-même (c'est le rôle de
 * view-models/modal-selection-model.js, en amont) : il reçoit un
 * `selection` déjà résolu (selected_options / selected_sku_id) et le
 * confronte à `detail.sellable_units` (rupture) et au panier (déjà ajouté).
 */
export const PDP_CART_STATUS = Object.freeze({
  SELECTION_REQUIRED: 'SELECTION_REQUIRED',
  OUT_OF_STOCK: 'OUT_OF_STOCK',
  AVAILABLE_EMPTY: 'AVAILABLE_EMPTY',
  AVAILABLE_FILLED: 'AVAILABLE_FILLED',
});

/**
 * @param {Object} detail    - product_detail_v1 (inventory_model === 'SKU')
 * @param {Object} selection - modal_selection_state (selected_options, selected_sku_id)
 * @param {Array}  cart      - state.cart courant
 * @returns {{status: string, lineId: (string|null), qty: number}}
 */
export function resolvePdpCartState(detail, selection, cart) {
  const selectedOptions = (selection && selection.selected_options) || {};
  const axisCount = (detail && detail.option_axes ? detail.option_axes.length : 0);
  const selectionComplete = Object.keys(selectedOptions).length >= axisCount;

  if (!selectionComplete) {
    return { status: PDP_CART_STATUS.SELECTION_REQUIRED, lineId: null, qty: 0 };
  }

  const skuId = (selection && selection.selected_sku_id) || null;
  const unit = skuId
    ? (detail.sellable_units || []).find((candidate) => candidate.sku_id === skuId)
    : null;

  if (!unit || unit.stock_status !== 'AVAILABLE') {
    return { status: PDP_CART_STATUS.OUT_OF_STOCK, lineId: null, qty: 0 };
  }

  const lineId = computeLineId(detail.product, selectedOptions);
  const existing = findCartLineById(cart, lineId);

  if (existing) {
    return { status: PDP_CART_STATUS.AVAILABLE_FILLED, lineId, qty: existing.qty || 0 };
  }

  return { status: PDP_CART_STATUS.AVAILABLE_EMPTY, lineId, qty: 0 };
}
