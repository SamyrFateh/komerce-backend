'use strict';

/**
 * tests/unit/b-modal-buybox-shared-cart-state.test.js
 *
 * B2 (rapport pré-merge PDP-1/PDP-2) : le footer sticky doit exposer un
 * data-cart-state explicite ("empty" | "filled" | "out-of-stock" | "legacy")
 * sur .k-modal-actions, seule source de vérité consommée par le CSS pour
 * disposer les CTA côte à côte selon l'état. Ce test couvre la logique JS
 * (syncBuyboxActions) — le rendu visuel lui-même (display:none via [hidden],
 * disposition flex) est hors de portée de jsdom et reste vérifié par les
 * tests navigateur (cf. RAPPORT_TEST_PREMERGE_PDP1_PDP2.md).
 */

jest.mock('../../js/b-utils.js', () => ({
  fmtPrice: (value) => (value == null ? '' : `${value} KMF`),
}));
jest.mock('../../js/b-modal.js', () => ({ closeModal: jest.fn() }));
jest.mock('../../js/b-cart.js', () => ({
  addToCart: jest.fn(),
  setCartLineQty: jest.fn(),
  removeCartLine: jest.fn(),
}));
jest.mock('../../js/b-share-cart.js', () => ({ startShareFlow: jest.fn() }));

const { syncBuyboxActions } = require('../../js/b-modal-buybox-shared.js');
const { state } = require('../../js/b-store.js');

function buildFooter() {
  document.body.innerHTML = `
    <div class="k-modal-actions">
      <div class="k-qty" id="qty"><button id="qtyMinus"></button><span id="qtyVal"></span><button id="qtyPlus"></button></div>
      <button class="k-add-cart-btn" id="add"></button>
      <button class="k-buy-now-btn" id="buy"></button>
      <button class="k-notify-btn" id="notify"></button>
    </div>
  `;
  return {
    qtyWrap: document.getElementById('qty'),
    qtyMinus: document.getElementById('qtyMinus'),
    qtyPlus: document.getElementById('qtyPlus'),
    qtyVal: document.getElementById('qtyVal'),
    addBtn: document.getElementById('add'),
    buyBtn: document.getElementById('buy'),
    notifyBtn: document.getElementById('notify'),
  };
}

function skuDetail({ axisCount = 1 } = {}) {
  return {
    inventory_model: 'SKU',
    product: { id: 'p1' },
    option_axes: Array.from({ length: axisCount }, (_, i) => ({ name: `axis${i}` })),
    sellable_units: [{ sku_id: 'sku-1', price_kmf: 1000, stock_status: 'AVAILABLE' }],
  };
}

describe('syncBuyboxActions — data-cart-state (B2)', () => {
  beforeEach(() => {
    state.cart = [];
  });

  test('aucun SKU résolu, sélection incomplète → data-cart-state="empty"', () => {
    const elements = buildFooter();
    const detail = skuDetail({ axisCount: 1 });
    const selection = { selected_sku_id: null, selected_options: {} };
    syncBuyboxActions(elements, detail, selection);
    expect(elements.qtyWrap.closest('.k-modal-actions').dataset.cartState).toBe('empty');
  });

  test('SKU sélectionné, pas encore au panier → data-cart-state="empty"', () => {
    const elements = buildFooter();
    const detail = skuDetail();
    const selection = { selected_sku_id: 'sku-1', selected_options: { Couleur: 'Rouge' } };
    syncBuyboxActions(elements, detail, selection);
    const root = elements.qtyWrap.closest('.k-modal-actions');
    expect(root.dataset.cartState).toBe('empty');
    expect(elements.addBtn.hidden).toBe(false);
    expect(elements.buyBtn.hidden).toBe(false);
    expect(elements.qtyWrap.hidden).toBe(true);
  });

  test('SKU sélectionné déjà au panier → data-cart-state="filled"', () => {
    const elements = buildFooter();
    const detail = skuDetail();
    const selection = { selected_sku_id: 'sku-1', selected_options: { Couleur: 'Rouge' } };
    state.cart = [{ product: { id: 'p1' }, variant_combo: { Couleur: 'Rouge' }, qty: 2 }];
    syncBuyboxActions(elements, detail, selection);
    const root = elements.qtyWrap.closest('.k-modal-actions');
    expect(root.dataset.cartState).toBe('filled');
    expect(elements.addBtn.hidden).toBe(true);
    expect(elements.qtyWrap.hidden).toBe(false);
    expect(elements.buyBtn.hidden).toBe(false);
  });

  test('sélection complète mais rupture → data-cart-state="out-of-stock", seul notify visible', () => {
    const elements = buildFooter();
    const detail = skuDetail({ axisCount: 1 });
    const selection = { selected_sku_id: null, selected_options: { Couleur: 'Rouge' } };
    syncBuyboxActions(elements, detail, selection);
    const root = elements.qtyWrap.closest('.k-modal-actions');
    expect(root.dataset.cartState).toBe('out-of-stock');
    expect(elements.notifyBtn.hidden).toBe(false);
    expect(elements.addBtn.hidden).toBe(true);
    expect(elements.buyBtn.hidden).toBe(true);
    expect(elements.qtyWrap.hidden).toBe(true);
  });
});
