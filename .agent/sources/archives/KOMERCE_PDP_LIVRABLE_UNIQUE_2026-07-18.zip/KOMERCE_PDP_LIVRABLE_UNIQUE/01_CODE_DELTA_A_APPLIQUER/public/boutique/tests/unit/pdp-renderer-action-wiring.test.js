'use strict';

/**
 * Garde d'intégration PDP : la machine d'état des CTA doit rester partagée.
 * Un correctif antérieur avait laissé renderPdpActions() correct mais mort,
 * après réintroduction de renderActions() dans les deux renderers.
 */

const fs = require('fs');
const path = require('path');

const CASES = [
  'b-modal-mobile-product.js',
  'b-modal-desktop-product.js',
];

describe('PDP renderer action wiring', () => {
  test.each(CASES)('%s utilise le point d’entrée partagé', (filename) => {
    const source = fs.readFileSync(path.join(__dirname, '../../js', filename), 'utf8');

    expect(source).toMatch(/import\s*\{[^}]*renderPdpActions[^}]*\}\s*from\s*['"]\.\/b-modal-buybox-shared\.js['"]/s);
    expect(source).toMatch(/renderPdpActions\(detail,\s*selection\);/);
    expect(source).not.toMatch(/function\s+renderActions\s*\(/);
  });
});
