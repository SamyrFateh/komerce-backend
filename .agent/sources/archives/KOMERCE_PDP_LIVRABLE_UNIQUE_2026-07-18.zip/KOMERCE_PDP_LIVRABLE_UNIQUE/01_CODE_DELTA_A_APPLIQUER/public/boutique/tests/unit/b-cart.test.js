'use strict';

/**
 * tests/unit/b-cart.test.js
 *
 * Module #2 du plan d'attaque frontend — js/b-cart.js (1562L), 0% → couverture
 * de la logique métier critique du panier (§7 CART INTERACTIONS + §10 CART
 * PANEL, hors partage WhatsApp / long-press stepper / fly animation détaillée
 * qui restent en dette assumée pour ce lot — cf. plan point 2).
 *
 * Périmètre couvert :
 *   - addToCart (nouvel article, incrément existant, feedback bouton, modal-add,
 *     buy-now, toast)
 *   - setQty (update, suppression si < 1, item introuvable)
 *   - removeFromCart
 *   - quickAdd / quickRemove
 *   - toggleFav
 *   - markAllCartButtons
 *   - openCart / closeCart / openCartWithHighlight (dont bascule desktop)
 *   - clearCart / pruneObsoleteCart
 *   - renderCartBody est exercée indirectement (appelée par setQty/removeFromCart/
 *     openCart) : on vérifie son rendu de surface (vide vs rempli) sans dupliquer
 *     tout le détail DOM déjà couvert ailleurs.
 *
 * state/dom viennent du vrai b-store.js (objets mutables partagés, pattern déjà
 * utilisé pour b-paypal.test.js / b-modal-cart.test.js). Les modules périphériques
 * lourds (réseau, scroll, catalogue, schéma catégories) sont mockés.
 */

jest.mock('../../js/b-catalog.js', () => ({
  scrollToCategorySection: jest.fn(),
}));

jest.mock('../../js/b-utils.js', () => ({
  sanitize: jest.fn((s) => s),
  fmt: jest.fn((n) => String(n) + ' KMF'),
  fmtPrice: jest.fn((n) => String(n)),
  optimizeImgUrl: jest.fn((url) => url),
  productEmoji: jest.fn(() => '📦'),
  _currency: 'KMF',
  apiGet: jest.fn(),
  apiPost: jest.fn(),
}));

jest.mock('../../js/b-cart-core.js', () => ({
  showToast: jest.fn(),
  updateCartBadge: jest.fn(),
  saveCart: jest.fn(),
  cartQty: jest.fn(() => 0),
  cartTotal: jest.fn(() => 0),
  saveFavs: jest.fn(),
}));

jest.mock('../../js/b-scroll-owner.js', () => ({
  isDesktop: jest.fn(() => false),
  getScrollY: jest.fn(() => 0),
  scrollToPosition: jest.fn(),
}));

jest.mock('../../js/shop-schema.js', () => ({
  getCategoryIcon: jest.fn(),
  normalizeCategoryKey: jest.fn((k) => k),
}));

const { state, dom, scroll } = require('../../js/b-store.js');
const { showToast, updateCartBadge, saveCart, cartQty, saveFavs } =
  require('../../js/b-cart-core.js');
const { isDesktop, getScrollY, scrollToPosition } = require('../../js/b-scroll-owner.js');
const { bus } = require('../../js/b-bus.js');

const {
  addToCart, quickAdd, quickRemove, toggleFav, setQty,
  setCartLineQty, removeCartLine,
  openCart, closeCart, openCartWithHighlight,
  renderCartBody, removeFromCart, markAllCartButtons,
  clearCart, pruneObsoleteCart,
} = require('../../js/b-cart.js');

/**
 * Reconstruit les refs DOM minimales attendues par b-cart.js.
 * Pas de fixture HTML globale dans ce projet (contrairement à b-modal-cart) :
 * on peuple `dom` directement, comme le fait initDom() en prod.
 */
function resetDom() {
  // jsdom ne fournit pas scrollIntoView : b-cart.js l'appelle (highlight scroll,
  // clic image/nom → réouverture modal). Stub global sur Element.prototype.
  if (!Element.prototype.scrollIntoView) {
    Element.prototype.scrollIntoView = jest.fn();
  }
  dom.cartBody = document.createElement('div');
  dom.cartFooter = document.createElement('div');
  dom.cartHeaderTitle = document.createElement('div');
  dom.cartHeader = document.createElement('div');
  dom.cartOverlay = document.createElement('div');
  dom.cartDrawer = document.createElement('div');
  dom.cartTotalVal = document.createElement('div');
  dom.cartTotalConv = document.createElement('div');
  dom.cartBtn = document.createElement('button');
  dom.addCartBtn = document.createElement('button');
  document.body.innerHTML = '';
  document.body.classList.remove('cart-open', 'cart-empty');
}

function makeProduct(overrides) {
  return Object.assign({
    id: 1,
    name: 'Riz basmati 5kg',
    price_kmf: 5000,
    image_url: '',
  }, overrides);
}

describe('b-cart', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    resetDom();
    state.cart = [];
    state.favs = [];
    state.products = [];
    state.editSharedCart = null;
    scroll.savedY = 0;
    isDesktop.mockReturnValue(false);
  });

  describe('addToCart', () => {
    it("ajoute un nouvel article au panier avec qty par défaut = 1", () => {
      const product = makeProduct();
      addToCart(product);
      expect(state.cart).toHaveLength(1);
      expect(state.cart[0]).toMatchObject({
        id: 1, name: 'Riz basmati 5kg', price: 5000, qty: 1,
      });
      expect(saveCart).toHaveBeenCalled();
    });

    it('respecte la qty explicite passée en argument', () => {
      addToCart(makeProduct(), 3);
      expect(state.cart[0].qty).toBe(3);
    });

    it('incrémente la qty si le produit est déjà dans le panier', () => {
      const product = makeProduct();
      addToCart(product, 2);
      addToCart(product, 1);
      expect(state.cart).toHaveLength(1);
      expect(state.cart[0].qty).toBe(3);
    });


    it('canonicalise l’ordre des clés de variante : même combinaison logique = une seule ligne', () => {
      const product = makeProduct({ id: 77 });
      state.modalProduct = product;

      state.modalVariantCombo = { Couleur: 'Rouge', Taille: '44' };
      addToCart(product, 1);

      state.modalVariantCombo = { Taille: '44', Couleur: 'Rouge' };
      addToCart(product, 1);

      expect(state.cart).toHaveLength(1);
      expect(state.cart[0].qty).toBe(2);
      expect(state.cart[0].line_id).toBeTruthy();
    });

    it('complète les champs manquants (id/name/price/image) sur un item existant incomplet', () => {
      state.cart = [{ product: null, id: null, name: null, price: null, image: '', qty: 1 }];
      // Simule un item pré-existant retrouvé par id via product?.id ?? id → id doit matcher
      state.cart[0].id = 1;
      const product = makeProduct({ image_url: 'https://img/x.jpg' });
      addToCart(product, 1);
      const item = state.cart[0];
      expect(item.qty).toBe(2);
      expect(item.product).toBe(product);
      expect(item.name).toBe('Riz basmati 5kg');
      expect(item.image).toBe('https://img/x.jpg');
    });

    it('fallback price sur `price` si `price_kmf` absent, 0 si aucun des deux', () => {
      addToCart(makeProduct({ price_kmf: undefined, price: 999 }));
      expect(state.cart[0].price).toBe(999);

      state.cart = [];
      addToCart(makeProduct({ price_kmf: undefined, price: undefined }));
      expect(state.cart[0].price).toBe(0);
    });

    it('sans sourceBtn : pas de fly animation, pas de toast, pas de crash', () => {
      expect(() => addToCart(makeProduct())).not.toThrow();
      expect(showToast).not.toHaveBeenCalled();
    });

    it('avec un bouton grid classique : feedback added→in-cart après 800ms + toast succès', () => {
      jest.useFakeTimers();
      const btn = document.createElement('button');
      addToCart(makeProduct(), 1, btn);

      expect(btn.classList.contains('added')).toBe(true);
      expect(btn.disabled).toBe(true);
      expect(showToast).toHaveBeenCalledWith(expect.stringContaining('ajouté'), 'success');

      jest.advanceTimersByTime(800);
      expect(btn.classList.contains('added')).toBe(false);
      expect(btn.classList.contains('in-cart')).toBe(true);
      expect(btn.disabled).toBe(false);
      jest.useRealTimers();
    });

    it('bouton modal (dom.addCartBtn) : pas de classe added/in-cart immédiate, feedback différé "confirmed"', () => {
      jest.useFakeTimers();
      addToCart(makeProduct(), 1, dom.addCartBtn);

      // Pas de feedback "grid" pour le bouton modal
      expect(dom.addCartBtn.classList.contains('added')).toBe(false);
      expect(showToast).not.toHaveBeenCalled();

      cartQty.mockReturnValue(1);
      jest.advanceTimersByTime(700);
      expect(dom.addCartBtn.classList.contains('confirmed')).toBe(true);
      expect(dom.addCartBtn.innerHTML).toContain('Ajouté');
      jest.useRealTimers();
    });

    it('bouton buy-now (id=k-buy-now-btn) sur desktop : émet side-cart:render, pas de toast', () => {
      isDesktop.mockReturnValue(true);
      const busSpy = jest.spyOn(bus, 'emit');
      const buyNowBtn = document.createElement('button');
      buyNowBtn.id = 'k-buy-now-btn';

      addToCart(makeProduct(), 1, buyNowBtn);

      expect(busSpy).toHaveBeenCalledWith('side-cart:render');
      expect(showToast).not.toHaveBeenCalled();
      busSpy.mockRestore();
    });

    it('appelle markAllCartButtons (synchronise les boutons .k-card-add existants)', () => {
      const gridBtn = document.createElement('button');
      gridBtn.className = 'k-card-add';
      gridBtn.dataset.add = '1';
      document.body.appendChild(gridBtn);

      addToCart(makeProduct({ id: 1 }));

      expect(gridBtn.classList.contains('in-cart')).toBe(true);
      expect(gridBtn.innerHTML).toContain('k-add-qty');
    });
  });

  describe('setQty', () => {
    beforeEach(() => {
      state.cart = [{ product: { id: 1 }, id: 1, name: 'X', price: 100, image: '', qty: 2 }];
    });

    it('met à jour la quantité et sauvegarde/rafraîchit', () => {
      setQty(1, 5);
      expect(state.cart[0].qty).toBe(5);
      expect(saveCart).toHaveBeenCalled();
      expect(updateCartBadge).toHaveBeenCalled();
    });

    it('newQty < 1 → supprime l\'article via removeFromCart', () => {
      setQty(1, 0);
      expect(state.cart).toHaveLength(0);
    });

    it('produit introuvable → ne modifie rien, ne throw pas', () => {
      expect(() => setQty(999, 3)).not.toThrow();
      expect(state.cart[0].qty).toBe(2);
    });

    it('compare les IDs en string (id numérique vs string)', () => {
      setQty('1', 7);
      expect(state.cart[0].qty).toBe(7);
    });
  });

  describe('setCartLineQty / removeCartLine (line-identity-aware — A1)', () => {
    const { computeLineId } = require('../../js/cart-line-identity.js');

    beforeEach(() => {
      // Deux variantes du même produit dans le panier : le scénario que
      // setQty/removeFromCart (product.id seul) ne peuvent pas distinguer.
      state.cart = [
        { product: { id: 1 }, id: 1, name: 'T-shirt', price: 100, image: '', qty: 2, variant_combo: { Couleur: 'Rouge' } },
        { product: { id: 1 }, id: 1, name: 'T-shirt', price: 100, image: '', qty: 3, variant_combo: { Couleur: 'Bleu' } },
      ];
    });

    it('setCartLineQty met à jour uniquement la ligne ciblée par line_id, pas les autres variantes du même produit', () => {
      const lineId = computeLineId({ id: 1 }, { Couleur: 'Bleu' });
      setCartLineQty(lineId, 9);
      expect(state.cart.find(i => i.variant_combo.Couleur === 'Bleu').qty).toBe(9);
      expect(state.cart.find(i => i.variant_combo.Couleur === 'Rouge').qty).toBe(2);
      expect(saveCart).toHaveBeenCalled();
      expect(updateCartBadge).toHaveBeenCalled();
    });

    it('setCartLineQty avec newQty < 1 → supprime uniquement cette ligne via removeCartLine', () => {
      const lineId = computeLineId({ id: 1 }, { Couleur: 'Rouge' });
      setCartLineQty(lineId, 0);
      expect(state.cart).toHaveLength(1);
      expect(state.cart[0].variant_combo.Couleur).toBe('Bleu');
    });

    it('setCartLineQty avec line_id introuvable → ne modifie rien, ne throw pas', () => {
      expect(() => setCartLineQty('999::null', 5)).not.toThrow();
      expect(state.cart[0].qty).toBe(2);
      expect(state.cart[1].qty).toBe(3);
    });

    it('removeCartLine retire uniquement la ligne ciblée, laisse les autres variantes intactes', () => {
      const lineId = computeLineId({ id: 1 }, { Couleur: 'Rouge' });
      removeCartLine(lineId);
      expect(state.cart).toHaveLength(1);
      expect(state.cart[0].variant_combo.Couleur).toBe('Bleu');
      expect(saveCart).toHaveBeenCalled();
      expect(updateCartBadge).toHaveBeenCalled();
    });

    it('removeCartLine avec line_id introuvable → panier inchangé, pas de crash', () => {
      expect(() => removeCartLine('999::null')).not.toThrow();
      expect(state.cart).toHaveLength(2);
    });

    it('résout la ligne via line_id explicite (item.line_id) plutôt que le recalcul si présent', () => {
      state.cart = [
        { product: { id: 1 }, variant_combo: { Couleur: 'Rouge' }, line_id: 'custom-legacy-id', qty: 4 },
      ];
      setCartLineQty('custom-legacy-id', 7);
      expect(state.cart[0].qty).toBe(7);
    });
  });

  describe('removeFromCart', () => {
    it('retire l\'article correspondant et sauvegarde', () => {
      state.cart = [
        { product: { id: 1 }, qty: 1 },
        { product: { id: 2 }, qty: 1 },
      ];
      removeFromCart(1);
      expect(state.cart).toHaveLength(1);
      expect(state.cart[0].product.id).toBe(2);
      expect(saveCart).toHaveBeenCalled();
    });

    it('id inexistant → panier inchangé, pas de crash', () => {
      state.cart = [{ product: { id: 1 }, qty: 1 }];
      expect(() => removeFromCart(999)).not.toThrow();
      expect(state.cart).toHaveLength(1);
    });
  });

  describe('quickAdd', () => {
    it('trouve le produit dans state.products et appelle addToCart', () => {
      state.products = [makeProduct({ id: 42 })];
      quickAdd(42);
      expect(state.cart).toHaveLength(1);
      expect(state.cart[0].id).toBe(42);
    });

    it('produit introuvable → warn console, pas de crash, panier inchangé', () => {
      const warnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});
      state.products = [];
      expect(() => quickAdd(999)).not.toThrow();
      expect(state.cart).toHaveLength(0);
      expect(warnSpy).toHaveBeenCalled();
      warnSpy.mockRestore();
    });
  });

  describe('quickRemove', () => {
    it('qty === 1 → supprime complètement l\'article', () => {
      state.cart = [{ product: { id: 1 }, qty: 1 }];
      quickRemove(1);
      expect(state.cart).toHaveLength(0);
    });

    it('qty > 1 → décrémente via setQty sans supprimer', () => {
      state.cart = [{ product: { id: 1 }, qty: 3 }];
      quickRemove(1);
      expect(state.cart).toHaveLength(1);
      expect(state.cart[0].qty).toBe(2);
    });

    it('item introuvable → ne fait rien', () => {
      state.cart = [];
      expect(() => quickRemove(1)).not.toThrow();
    });
  });

  describe('toggleFav', () => {
    it('ajoute aux favoris (coeur plein, toast, classe liked+pop)', () => {
      jest.useFakeTimers();
      const btn = document.createElement('button');
      state.favs = [];
      toggleFav(7, btn);
      expect(state.favs).toContain(7);
      expect(btn.classList.contains('liked')).toBe(true);
      expect(btn.innerHTML).toBe('❤️');
      expect(showToast).toHaveBeenCalledWith(expect.stringContaining('Ajouté aux favoris'));
      expect(saveFavs).toHaveBeenCalled();
      jest.advanceTimersByTime(300);
      expect(btn.classList.contains('k-pop')).toBe(false);
      jest.useRealTimers();
    });

    it('retire des favoris (coeur vide, toast retrait)', () => {
      const btn = document.createElement('button');
      btn.classList.add('liked');
      state.favs = [7];
      toggleFav(7, btn);
      expect(state.favs).not.toContain(7);
      expect(btn.classList.contains('liked')).toBe(false);
      expect(btn.innerHTML).toBe('🤍');
      expect(showToast).toHaveBeenCalledWith(expect.stringContaining('Retiré des favoris'));
      expect(saveFavs).toHaveBeenCalled();
    });
  });

  describe('markAllCartButtons', () => {
    it('affiche le stepper − qty + pour un produit dans le panier', () => {
      state.cart = [{ product: { id: 5 }, qty: 4 }];
      const btn = document.createElement('button');
      btn.className = 'k-card-add';
      btn.dataset.add = '5';
      document.body.appendChild(btn);

      markAllCartButtons();

      expect(btn.classList.contains('in-cart')).toBe(true);
      expect(btn.innerHTML).toContain('k-add-qty">4');
    });

    it('remet le bouton "+" simple pour un produit absent du panier', () => {
      state.cart = [];
      const btn = document.createElement('button');
      btn.className = 'k-card-add';
      btn.classList.add('in-cart');
      btn.dataset.add = '5';
      document.body.appendChild(btn);

      markAllCartButtons();

      expect(btn.classList.contains('in-cart')).toBe(false);
      expect(btn.innerHTML).toContain('panier_tresse_vert.png');
    });
  });

  describe('openCart / closeCart / openCartWithHighlight', () => {
    it('openCart (mobile) : ouvre le drawer, sauvegarde le scroll', () => {
      isDesktop.mockReturnValue(false);
      getScrollY.mockReturnValue(123);
      openCart();
      expect(dom.cartOverlay.classList.contains('open')).toBe(true);
      expect(dom.cartDrawer.classList.contains('open')).toBe(true);
      expect(document.body.classList.contains('cart-open')).toBe(true);
      expect(scroll.savedY).toBe(123);
    });

    it('openCart (desktop) : n\'ouvre pas de drawer, émet checkout:open', () => {
      isDesktop.mockReturnValue(true);
      const busSpy = jest.spyOn(bus, 'emit');
      openCart();
      expect(busSpy).toHaveBeenCalledWith('checkout:open');
      expect(dom.cartOverlay.classList.contains('open')).toBe(false);
      busSpy.mockRestore();
    });

    it('closeCart : ferme le drawer et restaure le scroll sauvegardé', () => {
      dom.cartOverlay.classList.add('open');
      dom.cartDrawer.classList.add('open');
      document.body.classList.add('cart-open', 'cart-empty');
      scroll.savedY = 456;

      closeCart();

      expect(dom.cartOverlay.classList.contains('open')).toBe(false);
      expect(dom.cartDrawer.classList.contains('open')).toBe(false);
      expect(document.body.classList.contains('cart-open')).toBe(false);
      expect(document.body.classList.contains('cart-empty')).toBe(false);
      expect(scrollToPosition).toHaveBeenCalledWith(456);
      expect(scroll.savedY).toBe(0);
    });

    it('closeCart : sans scroll sauvegardé, ne rappelle pas scrollToPosition', () => {
      scroll.savedY = 0;
      closeCart();
      expect(scrollToPosition).not.toHaveBeenCalled();
    });

    it('openCartWithHighlight (mobile) : ouvre le drawer + bandeau célébration puis restore le titre après 2400ms', () => {
      jest.useFakeTimers();
      isDesktop.mockReturnValue(false);
      cartQty.mockReturnValue(2);
      state.cart = [{ product: { id: 9, price_kmf: 100 }, qty: 1 }];

      openCartWithHighlight(9);

      expect(dom.cartHeader.classList.contains('celebrating')).toBe(true);
      expect(dom.cartHeaderTitle.textContent).toContain('dans le panier');
      expect(dom.cartOverlay.classList.contains('open')).toBe(true);

      jest.advanceTimersByTime(2400);
      expect(dom.cartHeader.classList.contains('celebrating')).toBe(false);
      expect(dom.cartHeaderTitle.textContent).toBe('Mon Panier (2)');
      jest.useRealTimers();
    });

    it('openCartWithHighlight (desktop) : pas de drawer mobile ouvert', () => {
      isDesktop.mockReturnValue(true);
      state.cart = [{ product: { id: 9, price_kmf: 100 }, qty: 1 }];
      openCartWithHighlight(9);
      expect(dom.cartOverlay.classList.contains('open')).toBe(false);
      expect(document.body.classList.contains('cart-open')).toBe(false);
    });
  });

  describe('renderCartBody (rendu de surface)', () => {
    it('panier vide → message vide affiché, footer masqué, body marqué cart-empty', () => {
      state.cart = [];
      renderCartBody();
      expect(dom.cartBody.innerHTML).toContain('Votre panier est vide');
      expect(dom.cartFooter.classList.contains('u-hidden')).toBe(true);
      expect(document.body.classList.contains('cart-empty')).toBe(true);
    });

    it('panier rempli → une ligne par article, footer visible, body pas marqué vide', () => {
      state.cart = [
        { product: { id: 1, name: 'Riz', price_kmf: 1000 }, qty: 2 },
        { product: { id: 2, name: 'Huile', price_kmf: 2000 }, qty: 1 },
      ];
      renderCartBody();
      const rows = dom.cartBody.querySelectorAll('.k-cart-item');
      expect(rows).toHaveLength(2);
      expect(dom.cartFooter.classList.contains('u-hidden')).toBe(false);
      expect(document.body.classList.contains('cart-empty')).toBe(false);
    });

    it('highlightId correspondant → marque la ligne .new-item avec badge', () => {
      state.cart = [{ product: { id: 3, name: 'Sucre', price_kmf: 500 }, qty: 1 }];
      renderCartBody(3);
      const row = dom.cartBody.querySelector('.k-cart-item');
      expect(row.classList.contains('new-item')).toBe(true);
      expect(row.querySelector('.k-cart-item-badge')).not.toBeNull();
    });


    it('le stepper du drawer cible la variante exacte via line_id', () => {
      state.cart = [
        { product: { id: 5, name: 'T-shirt', price_kmf: 100 }, qty: 2, variant_combo: { Couleur: 'Rouge' }, variant_label: 'Rouge' },
        { product: { id: 5, name: 'T-shirt', price_kmf: 100 }, qty: 3, variant_combo: { Couleur: 'Bleu' }, variant_label: 'Bleu' },
      ];
      renderCartBody();
      let rows = dom.cartBody.querySelectorAll('.k-cart-item');
      rows[1].querySelectorAll('.k-qty-btn')[1].click();
      expect(state.cart.find((item) => item.variant_combo.Couleur === 'Rouge').qty).toBe(2);
      expect(state.cart.find((item) => item.variant_combo.Couleur === 'Bleu').qty).toBe(4);

      rows = dom.cartBody.querySelectorAll('.k-cart-item');
      rows[1].querySelectorAll('.k-qty-btn')[0].click();
      expect(state.cart.find((item) => item.variant_combo.Couleur === 'Rouge').qty).toBe(2);
      expect(state.cart.find((item) => item.variant_combo.Couleur === 'Bleu').qty).toBe(3);

      rows = dom.cartBody.querySelectorAll('.k-cart-item');
      rows[1].querySelector('.k-cart-item-remove').click();
      expect(state.cart).toHaveLength(1);
      expect(state.cart[0].variant_combo.Couleur).toBe('Rouge');
    });
  });

  describe('side-cart multi-variantes', () => {
    function mountSideCart() {
      document.body.insertAdjacentHTML('beforeend', `
        <aside id="k-side-cart">
          <div id="k-sc-total"></div>
          <span id="k-sc-count-inline"></span>
          <div id="k-sc-items"></div>
          <button id="k-sc-cta"></button>
          <button id="k-sc-checkout"></button>
          <button id="k-sc-share"></button>
          <button id="k-sc-clear"></button>
          <div class="k-sc-header"></div>
        </aside>
        <span id="k-bnav-cart-label"></span>
      `);
    }

    it('les actions + et supprimer ciblent la ligne exacte, jamais le seul product.id', () => {
      mountSideCart();
      state.cart = [
        { product: { id: 5, name: 'T-shirt', price_kmf: 100 }, qty: 2, variant_combo: { Couleur: 'Rouge' }, variant_label: 'Rouge' },
        { product: { id: 5, name: 'T-shirt', price_kmf: 100 }, qty: 3, variant_combo: { Couleur: 'Bleu' }, variant_label: 'Bleu' },
      ];

      bus.emit('side-cart:render');
      let firstRendered = document.querySelector('.k-sc-item'); // ordre inversé : Bleu
      firstRendered.querySelector('.k-sc-step-plus').click();
      expect(state.cart.find((item) => item.variant_combo.Couleur === 'Rouge').qty).toBe(2);
      expect(state.cart.find((item) => item.variant_combo.Couleur === 'Bleu').qty).toBe(4);

      bus.emit('side-cart:render');
      firstRendered = document.querySelector('.k-sc-item');
      firstRendered.querySelector('.k-sc-step-minus').click();
      expect(state.cart.find((item) => item.variant_combo.Couleur === 'Rouge').qty).toBe(2);
      expect(state.cart.find((item) => item.variant_combo.Couleur === 'Bleu').qty).toBe(3);

      bus.emit('side-cart:render');
      firstRendered = document.querySelector('.k-sc-item');
      firstRendered.querySelector('.k-sc-item-remove').click();
      expect(state.cart).toHaveLength(1);
      expect(state.cart[0].variant_combo.Couleur).toBe('Rouge');
    });
  });

  describe('clearCart', () => {
    it('vide le panier et sauvegarde', () => {
      state.cart = [{ product: { id: 1 }, qty: 1 }];
      clearCart();
      expect(state.cart).toHaveLength(0);
      expect(saveCart).toHaveBeenCalled();
    });
  });

  describe('pruneObsoleteCart', () => {
    it('retire les articles dont l\'id n\'est plus dans validIdSet et sauvegarde', () => {
      state.cart = [
        { product: { id: 1 }, qty: 1 },
        { product: { id: 2 }, qty: 1 },
      ];
      pruneObsoleteCart(new Set(['1']));
      expect(state.cart).toHaveLength(1);
      expect(state.cart[0].product.id).toBe(1);
      expect(saveCart).toHaveBeenCalled();
    });

    it('rien à retirer → ne sauvegarde pas (pas de changement de longueur)', () => {
      state.cart = [{ product: { id: 1 }, qty: 1 }];
      pruneObsoleteCart(new Set(['1']));
      expect(saveCart).not.toHaveBeenCalled();
    });
  });
});
