# PDP-2 — Fidélité mockup (hero overlays + desktop 3 colonnes)

Suite de PDP-1 (livré : hero mobile 240px fixe, state machine panier partagée,
notify-btn OUT_OF_STOCK). Écart identifié entre le mockup cible et le rendu
réel — voir mockup de référence (capture Mobile/Desktop "Chaussure Elite Pro").

Statut global : **Lots A/B/C/D terminés (cf. README_SUITE_PDP2.md).**

---

## Lot A — Overlay hero partagé (mobile + desktop)
**Risque : faible** — logique déjà partagée (module carousel commun mobile/desktop).

- [x] `index.html` — markup `.k-modal-hero-meta` (2 lignes) + `.k-modal-hero-decor` (2 cercles)
- [x] `js/b-modal-product.js` (`buildCarouselSlides`) — peupler ligne 1 = `product.name`,
      ligne 2 = `product.category` (optionnelle, masquée si absente — **aucun champ
      inventé** : le contrat `product_detail_v1` n'expose ni "collection" ni "série")
- [x] `js/b-modal-mobile-product.js` / `js/b-modal-desktop-product.js` — ajouter `category`
      à l'objet passé à `buildCarouselSlides`
- [x] `css/modal-media.css` — position absolue des 2 lignes + des cercles dans
      `.k-modal-img-wrap` (déjà `position:relative`)

## Lot B — Compteur "N/Total" toujours visible (mobile ET desktop)
**Risque : faible.**

- [x] `js/b-modal-image-ux.js` — `_isEnrichedMobileDetail()` limité à `max-width:899px`
      → étendre au desktop dès qu'un `product_detail_v1` est chargé
- [x] `css/modal-shell.css` ~L497 — `#k-modal .k-modal-counter { display:none; }` écrase
      `.is-visible` par spécificité (ID > 2 classes) → retirer

## Lot C — Bouton "agrandir" conforme spec (icône cercle, pas de pastille texte)
**Risque : faible, cosmétique, non bloquant.** Composant déjà fonctionnel
(`_injectViewFullBtn` + lightbox plein écran) — écart uniquement visuel.

- [x] `js/b-modal-image-ux.js` — retirer le texte "Voir en grand", garder l'icône seule
      (`aria-label` conserve l'accessibilité)
- [x] `css/modal-media.css` `.k-modal-view-full` — cercle 32×32, fond clair
      (`--overlay-light`) au lieu de la pastille sombre actuelle

## Lot D — Vrai desktop 3 colonnes (miniatures | hero | panneau commercial)
**Risque : moyen.** Cartographié entièrement — un seul point d'assignation par
propriété (invariant gouverné B-M-11 : `grid-template-columns` déclaré une fois).

- [x] `css/modal-product-lot4-hybrid.css` (**seul propriétaire** de
      `grid-template-columns`) — 2 colonnes → 3 (miniatures / hero / panneau)
- [x] `css/modal-shell.css` — réassignation `grid-column` :
      `.k-modal-img-wrap` (1→2), `.k-modal-details` (2→3), `.k-modal-actions` (2→3) ;
      `.k-modal-thumbs` : sort de l'`absolute` overlay → colonne de grille statique
      (`grid-column:1; grid-row:1/3`)
- [x] `js/b-modal-product.js` — point d'injection des miniatures : actuellement
      *dans* `.k-modal-img-wrap` (`imgWrap.insertBefore(...)`) → devient un **sibling**
      dans `.k-modal-product-zone`, inséré avant l'image. Aucun changement HTML requis ;
      classe `.k-modal-thumbs` inchangée donc tous les sélecteurs existants
      (`dom.modal.querySelector('.k-modal-thumbs')`, `.k-modal-thumb`) restent valides.
- Vérifié en amont : aucune autre media query ne réassigne ces mêmes
  `grid-column`/`grid-row` (le bloc tablette 900–1120px touche autre chose) —
  changement localisé aux deux fichiers CSS ci-dessus.

## Lot E — Non-régression + gouvernance
À lancer après chaque lot (ou groupé en fin de chantier) :

```
npm run test:unit
node scripts/css-guard.js --strict
node scripts/check-important.js --strict
node scripts/audit-boutique-arch.js
node scripts/check-html-balance.js
node scripts/check-js-imports.js
```

---

## Ordre recommandé
**A → B → C → D → E.** Permet un état intermédiaire toujours testé/fonctionnel
même si D est interrompu ou reporté. D peut être avancé en premier si la
priorité visuelle desktop prime — pas de dépendance dure entre B/C/D.
