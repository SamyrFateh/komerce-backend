# Komerce PDP Mobile — spécification développeur

## 1. Overview

Page produit affichée en modal plein écran par-dessus le catalogue. Optimise pour l'achat immédiat (prix + CTA visibles sans scroll) tout en préservant l'esthétique premium de la marque. Cible : audience francophone e-commerce débutante à intermédiaire (Comores et diaspora).

## 2. Viewport cible

- Largeur : 360-430px (iPhone SE à iPhone 15 Pro Max, Samsung S8+ et équivalents Android)
- Hauteur : full screen, respect des safe areas iOS et Android
- Orientation : portrait uniquement
- Pas de scroll horizontal, jamais

## 3. Design tokens

### Couleurs

```css
--page-bg: #FAF7F0;              /* Fond page (crème clair) */
--hero-bg: #F5EFDF;              /* Fond hero et fond des vignettes */
--sticky-bg: #FFFFFF;            /* Fond du sticky footer */
--text-primary: #2C2C2A;         /* Texte principal, quasi-noir */
--text-secondary: #5F5E5A;       /* Texte secondaire, gris foncé */
--text-muted: #B4B2A9;           /* Texte discret (référence, tips) */
--border: #ECE7DA;               /* Bordure crème */
--border-strong: #D3D1C7;        /* Bordure plus marquée */
--accent-blue: #185FA5;          /* Sélection variante, liens */
--accent-orange: #D85A30;        /* Badge HOT */
--success: #4CAF50;              /* En stock, CTA acheter, badge panier */
--success-bg: rgba(76,175,80,0.12);
--success-text: #2C6B2E;
--warning: #EF9F27;              /* Stock faible */
--warning-bg: rgba(239,159,39,0.12);
--warning-text: #854F0B;
--tap-highlight: rgba(0,0,0,0.05);
--overlay-dark: rgba(44,44,42,0.7);
--overlay-light: rgba(255,255,255,0.85);
```

### Typographie

- Family : system UI stack (`-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif`)
- Weights autorisés : **400** (regular) et **500** (medium) uniquement, jamais 600+
- Titre produit : 16px / 500 / line-height 1.2
- Référence : 11px / 400 / color muted
- Prix entier : 24px / 500 / letter-spacing -0.5px
- Prix devise : 12px / 500 / color secondary
- Libellés de section : 12px / 400 / color secondary
- Valeur sélectionnée dans les libellés : 12px / 500 / color primary
- Boutons CTA : 14px / 500
- Overlays (compteur, badges) : 10-11px / 500

### Spacing scale

`4, 6, 8, 12, 14, 16, 20, 24` px

### Radius

- Boutons, pills : `8px`
- Cards, vignettes : `6px`
- Grands conteneurs : `12px`
- Cercles, badges : `999px`

## 4. Structure verticale

De haut en bas, sans scroll dans les blocs individuels (sauf zone de contenu principale) :

1. Status bar système
2. Header (44px)
3. Hero image (240px, hauteur fixe)
4. Zone scrollable (flex 1) : infos produit + variantes + suggestions teasées
5. Sticky footer (72px + `env(safe-area-inset-bottom)`)

Le sticky footer ne doit **jamais** couvrir plus de 30 % de la hauteur d'écran.

## 5. Composants

### 5.1 Header

- Hauteur : 44px
- Padding : `0 16px`
- Background : `--page-bg` (pas de bordure)
- Layout : flex, justify-between, align-center

**Groupe gauche :**
- Bouton retour : icône `ti-arrow-left` 20px, touch target 44x44
- Label "Catalogue" : 14px / 500 / color primary, margin-left 4px

**Groupe droit :**
- Bouton panier : 32x32 circle, `background: --tap-highlight`
  - Icône `ti-shopping-bag` 16px color primary
  - Badge : positionné `top: -4px; right: -4px`
    - `min-width: 16px; height: 16px; padding: 0 4px`
    - `background: --success; border: 1.5px solid --page-bg; border-radius: 999px`
    - Texte : 10px / 500 / white, centré
    - Affiché uniquement si `cartCount > 0`
    - Contenu : `cartCount` si ≤ 99, sinon `"99+"`
- Bouton fermer : 28x28 circle, `background: --tap-highlight`, icône `ti-x` 16px
- Gap entre les deux : 8px

### 5.2 Hero image

- Hauteur : **240px** (fixe, ne change pas selon la taille d'écran)
- Background : `--hero-bg`
- Padding : `12px 16px`
- Position : relative (pour les overlays)

**Meta en haut à gauche :**
- Ligne 1 : "ELITE PRO" — 11px / 500 / letter-spacing 1.5px / color secondary
- Ligne 2 (optionnelle) : "GOLDEN PERFORMANCE SERIES" — 9px / 400 / letter-spacing 0.5px / color muted

**Formes décoratives :**
- Cercle 60x60 top-right : `background: #EAE3CE; opacity: 0.7`
- Cercle 50x50 bottom-left : `background: #EAE3CE; opacity: 0.5`

**Image produit :**
- Centrée, max-height 180px, object-fit contain
- Format : PNG transparent ou SVG, ratio 4:3, source minimum 800x600px
- Fallback : illustration générique + icône `ti-photo`

**Overlays absolus :**
- Bouton agrandir : bottom 12px, left 16px
  - 32x32 circle, `background: --overlay-light; border: 0.5px solid rgba(0,0,0,0.08)`
  - Icône `ti-arrows-maximize` 14px color primary
- Compteur de page : bottom 12px, right 16px
  - Pill : `padding: 4px 10px; background: --overlay-dark; border-radius: 999px`
  - Texte : 11px / 500 / white, format `"1 / 5"`

### 5.3 Bloc infos produit

- Padding : `12px 16px 8px`
- Background : `--page-bg`

**Titre :**
- 16px / 500 / color primary / line-height 1.2
- Truncate ligne 2 avec ellipsis si dépassement

**Référence :**
- Margin-top 4px
- 11px / 400 / color muted
- Format : `"Réf. GOLD-BLU-44"`

**Ligne prix + stock (flex justify-between, align-baseline, margin-top 8px) :**
- Prix : entier 24px / 500 / letter-spacing -0.5px + espace + devise 12px / 500 / color secondary
  - Format entier : séparateur des milliers = espace insécable étroit (`&#8239;`), ex. `"45 000"`
  - Fonction : `Intl.NumberFormat('fr-KM', { useGrouping: true }).format(value)`
- Badge stock : voir 5.5

### 5.4 Sélecteur de couleur

- Padding container : identique aux infos produit
- Margin-top 12px

**Libellé :**
- Format : `"Couleur · <valeur>"` où "Couleur" en 12px / 400 / color secondary et `<valeur>` en 12px / 500 / color primary
- Margin-bottom 6px

**Rangée de vignettes :**
- Flex, gap 6px, overflow-x auto (scroll horizontal si > 5 items)
- Hide scrollbar : `::-webkit-scrollbar { display: none; }` + `scrollbar-width: none`

**Chaque vignette :**
- Dimensions : 44x44px
- Radius : 6px
- Padding : 4px
- Background : `--hero-bg` pour valoriser l'image
- Contient : image produit (SVG ou PNG) centrée
- Touch target minimum 44x44 → OK avec ces dimensions
- États :
  - Défaut : `border: 0.5px solid --border-strong`
  - Sélectionné : `border: 1.5px solid --text-primary` (pas de fond différent)
  - Pressed : opacity 0.6 pendant le tap

**Badge HOT (optionnel, sur certaines variantes) :**
- Position : `top: -4px; left: -4px`
- `padding: 2px 5px; background: --accent-orange; border-radius: 3px`
- Texte : 8px / 500 / white / letter-spacing 0.3px / uppercase, contenu `"HOT"`

**Comportement au tap :**
- Fade transition 150ms sur l'image principale
- Update SKU, prix (si variante à prix différent), stock, tailles disponibles
- Update URL query : `?variant=<sku>` sans navigation

### 5.5 Badge stock

- Pill : `padding: 4px 8px; border-radius: 999px`
- Layout : flex align-center, gap 4px
- Contient : point 6x6 + label
- Texte : 11px / 500

Trois états :

| Condition | Background | Point | Texte | Label |
|---|---|---|---|---|
| `stock > 5` | `--success-bg` | `--success` | `--success-text` | `"En stock"` |
| `1 ≤ stock ≤ 5` | `--warning-bg` | `--warning` | `--warning-text` | `"Plus que N"` (N = stock) |
| `stock = 0` | `rgba(0,0,0,0.05)` | `--text-secondary` | `--text-secondary` | `"Épuisé"` |

### 5.6 Sélecteur de taille

- Margin-top 12px, padding container identique
- Libellé : même format que couleur, `"Taille · <valeur>"`

**Chips :**
- Flex, gap 6px, overflow-x auto si > 6 tailles
- Chaque chip : `padding: 8px 12px; border-radius: 6px`
- Texte : 12px / 500
- Touch target : au moins 40x40 (padding interne compense)

États :

| État | Background | Border | Texte |
|---|---|---|---|
| Défaut | `#FFF` | `0.5px solid --border-strong` | color secondary |
| Sélectionné | `--text-primary` | `--text-primary` | white |
| Indisponible | `--border` | `0.5px solid --border-strong` | color muted + `text-decoration: line-through` |

### 5.7 Bloc "Nos suggestions" (teasé)

- Séparateur en haut : `border-top: 0.5px dashed --border-strong; margin-top: 16px`
- Padding : `12px 16px 0`

**Header :**
- Flex justify-between align-baseline
- Titre : "Nos suggestions" 13px / 500
- Lien : "Voir tout ›" 11px / 400 / color secondary, tap → navigation vers la catégorie

**Carrousel horizontal :**
- Flex, gap 8px, overflow-x scroll, hide scrollbar
- Chaque card : 80px de large, flex-shrink 0
- Structure card :
  - Image : `aspect-ratio: 1; background: --hero-bg; border-radius: 8px; padding: 8px`, illustration centrée
  - Titre : 11px / 500 / color primary, margin-top 4px, single-line ellipsis
  - Prix : 11px / 400 / color secondary

**Le bloc est intentionnellement coupé par le sticky footer** pour signaler qu'il y a plus de contenu. Ne pas ajouter de dégradé de fade, la coupure nette suffit.

### 5.8 Sticky footer

- Position : `sticky bottom: 0` (dans son conteneur scroll)
- Background : `--sticky-bg`
- Border-top : `0.5px solid --border`
- Padding : `12px 12px calc(16px + env(safe-area-inset-bottom))`

**Deux états qui se remplacent (pas côte à côte, pas simultanés) :**

#### État empty — `productInCart === false`

Rangée flex, gap 8px :
- Bouton "Ajouter au panier" (flex 1.05) :
  - Height 44px, radius 8px
  - Background white, border `0.5px solid --text-primary`, color primary
  - Icône `ti-shopping-bag` 16px + label 14px / 500, gap 6px
  - Centré horizontalement et verticalement
- Bouton "Acheter maintenant" (flex 1) :
  - Height 44px, radius 8px
  - Background `--success`, color white, pas de border
  - Icône `ti-bolt` 16px + label 14px / 500, gap 6px

#### État filled — `productInCart === true`

Rangée flex, gap 8px :
- Stepper (width auto, flex-shrink 0) :
  - Height 44px, radius 8px, background `--hero-bg`, padding `0 12px`
  - Layout : icône `−` 14px + nombre 14px / 500 min-width 16px center + icône `+` 14px
  - Gap entre éléments : 12px
- Bouton "Acheter maintenant" (flex 1) : identique à l'état empty

**Transition entre les deux états** : morph animation 200ms ease-out :
- Le bouton "Ajouter au panier" rétrécit et se transforme en stepper
- Le bouton "Acheter" se réajuste automatiquement grâce à flex

**Home indicator visuel** : après la rangée de boutons, ne rien ajouter — c'est `env(safe-area-inset-bottom)` qui gère l'espace pour la barre système iOS.

## 6. États et logique

Variables d'état :
- `cartCount`: nombre total d'items dans le panier (tous produits)
- `productInCart`: booléen, true si ce produit (variante actuelle) est dans le panier
- `productQtyInCart`: quantité de ce produit dans le panier
- `stock`: nombre d'unités disponibles pour la variante sélectionnée
- `selectedVariant`: SKU sélectionné
- `selectedSize`: taille sélectionnée (ou null)

Règles :
- Un changement de variante ou de taille = nouvelle "identité produit". Si l'utilisateur ajoute, puis change de couleur, le panier contient deux entrées distinctes.
- `productInCart` se recalcule à chaque changement de variante/taille pour piloter l'affichage du sticky.
- Si `stock === 0` sur la variante sélectionnée, le sticky affiche un seul bouton "Me prévenir" pleine largeur (mail capture).

## 7. Interactions et transitions

### 7.1 Tap sur vignette variante
1. Fade out image principale (100ms)
2. Update SKU / prix / stock / tailles dispo
3. Fade in nouvelle image (100ms)
4. Update URL query sans navigation
5. Recalculer `productInCart` et morph du sticky si nécessaire

### 7.2 Tap sur image principale
1. Ouvrir un lightbox fullscreen
2. Body scroll lock
3. Toutes les vues du produit swipables horizontalement
4. Pinch-to-zoom natif
5. Close button top-right (X 24px sur fond overlay dark)
6. Page dots en bas
7. Swipe down ou tap sur X → ferme

### 7.3 Tap "Ajouter au panier"
1. Haptic feedback : `light impact`
2. Optimistic update immédiat : morph du sticky vers l'état filled avec quantité 1
3. Badge panier du header s'incrémente (ou apparaît)
4. Call API `POST /cart` avec `{ sku, size, qty: 1 }`
5. Si erreur : revert visuel + toast d'erreur en bas ("Impossible d'ajouter, réessayez")
6. Animation morph : 200ms ease-out

### 7.4 Tap `+` du stepper
1. Haptic light
2. Quantité +1, badge +1
3. Debounce API 300ms puis `PATCH /cart/:itemId` avec la nouvelle qty

### 7.5 Tap `−` du stepper
- Si `qty > 1` :
  1. Haptic light
  2. Quantité -1, badge -1
  3. Debounce API 300ms
- Si `qty === 1` :
  1. Haptic soft
  2. Morph vers l'état empty (ajouter au panier + acheter)
  3. Badge -1
  4. Call API `DELETE /cart/:itemId`

### 7.6 Tap "Acheter maintenant"
1. Ne modifie pas le panier existant
2. Direct redirect vers `/checkout?buyNow=<sku>&qty=<n>` (qty = 1 si empty, sinon quantité actuelle)
3. Fin de session PDP

### 7.7 Tap icône panier du header
1. Fade out modal PDP (150ms)
2. Navigation vers `/panier`

### 7.8 Tap X (fermer)
1. Fade down modal (200ms)
2. Retour au catalogue
3. Préserve les sélections et le panier

## 8. Accessibilité

- Tous les touch targets ≥ 44x44px (WCAG 2.5.5)
- `aria-label` sur les boutons icônes :
  - Retour : "Retour au catalogue"
  - Panier : "Voir le panier, N articles" (N dynamique)
  - Fermer : "Fermer la fiche produit"
  - Agrandir : "Voir l'image en grand"
  - Stepper +/− : "Augmenter la quantité", "Diminuer la quantité"
- Contraste : AA minimum vérifié pour tous les textes sur fonds crème et blanc
- Focus visible pour navigation clavier externe : `outline: 2px solid --accent-blue; outline-offset: 2px`
- Screen reader : annonce à chaque ajout au panier via `aria-live="polite"` — ex. "Article ajouté au panier"
- Sélection variante annoncée : "Bleu sélectionné, 4 autres coloris disponibles"
- Réduire les animations si `prefers-reduced-motion: reduce`

## 9. Edge cases

- **Nom produit long (>2 lignes)** : truncate ligne 2 avec `text-overflow: ellipsis`
- **Une seule image** : hide compteur `1/1`, garder icône agrandir
- **Une seule variante couleur** : hide tout le bloc Couleur
- **8+ tailles** : scroll horizontal avec un léger fade sur le bord droit pour signaler
- **Rupture de stock** : sticky remplacé par un unique bouton "Me prévenir" pleine largeur
- **Erreur réseau ajout panier** : revert + toast, préserver la sélection utilisateur
- **Slow image load** : skeleton `background: --hero-bg` avec shimmer léger (durée max 3s, puis fallback illustration générique)
- **Modal fermée pendant animation** : cancel animation, ne pas persister d'état intermédiaire

## 10. Assets

Icônes : **Tabler Icons outline** via webfont (5800+ icônes). CDN : `https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css`

Liste utilisée :
- `ti-arrow-left`
- `ti-shopping-bag`
- `ti-x`
- `ti-arrows-maximize`
- `ti-minus`
- `ti-plus`
- `ti-bolt`
- `ti-photo` (fallback image)

Images produit : format PNG transparent ou WebP, ratio 4:3, source minimum 1200x900px, servies via CDN avec conversion automatique WebP + redimensionnement responsive.

## 11. Priorités de dev

1. **P0 — Structure et layout** : header, hero, infos, sticky en état empty. Prix, stock, variantes visuelles.
2. **P0 — Sticky state machine** : morph empty ↔ filled, appels API panier, haptic feedback.
3. **P1 — Variantes fonctionnelles** : tap → update image + attributs, URL sync.
4. **P1 — Suggestions** : carrousel horizontal, données via API `GET /products/:id/related`.
5. **P2 — Lightbox image** : zoom + swipe fullscreen.
6. **P2 — Edge cases** : ruptures de stock, erreurs réseau, skeleton loading.
7. **P3 — Polish** : réduction d'animation, dark mode (si roadmap), analytics events.
