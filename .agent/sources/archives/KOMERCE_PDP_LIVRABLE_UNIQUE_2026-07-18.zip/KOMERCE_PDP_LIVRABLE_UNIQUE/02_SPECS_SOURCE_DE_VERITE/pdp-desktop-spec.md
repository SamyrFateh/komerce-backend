# Komerce PDP Desktop — spécification développeur

## 1. Objectif

Page produit desktop affichée dans une modal ou une vue plein écran au-dessus du catalogue. La composition doit reproduire la maquette desktop validée et placer immédiatement l’information commerciale au premier niveau : image, prix, stock, variantes et actions d’achat.

La fiche technique enrichie ne doit jamais remplacer le panneau commercial. Elle apparaît plus bas dans la page.

Cette spécification est complémentaire à `pdp-mobile-spec.md`. Les deux vues peuvent partager les mêmes données, services panier et composants métiers, mais pas nécessairement le même layout CSS.

---

## 2. Viewports cibles

- Desktop standard : 1280 à 1920 px
- Laptop : 1024 à 1279 px
- Large desktop : jusqu’à 2560 px
- Hauteur minimale supportée : 720 px
- Orientation : paysage
- Aucun scroll horizontal
- Le layout principal reste centré avec une largeur maximale

### Breakpoints

```css
--bp-desktop-min: 1024px;
--bp-desktop-wide: 1440px;
--page-max-width: 1180px;
```

À moins de 1024 px, basculer vers la spécification mobile/tablette existante plutôt que de comprimer le layout desktop.

---

## 3. Design tokens

Réutiliser les tokens de la spécification mobile afin de conserver la cohérence de marque.

```css
--page-bg: #FAF7F0;
--panel-bg: #FFFFFF;
--hero-bg: #F5EFDF;
--text-primary: #2C2C2A;
--text-secondary: #5F5E5A;
--text-muted: #B4B2A9;
--border: #ECE7DA;
--border-strong: #D3D1C7;
--success: #4CAF50;
--success-bg: rgba(76,175,80,0.12);
--success-text: #2C6B2E;
--warning: #EF9F27;
--warning-bg: rgba(239,159,39,0.12);
--warning-text: #854F0B;
--accent-blue: #185FA5;
--accent-orange: #D85A30;
--overlay-dark: rgba(44,44,42,0.72);
--shadow-soft: 0 8px 30px rgba(44,44,42,0.06);
```

### Typographie

- Font stack : `-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif`
- Poids autorisés : 400 et 500
- Nom produit : 18 px / 500 / line-height 1.2
- Référence : 12 px / 400 / muted
- Prix : 28 px / 500
- Devise : 13 px / 500 / secondary
- Labels : 12 px / 400 / secondary
- Valeurs sélectionnées : 12 px / 500 / primary
- Boutons : 13 à 14 px / 500
- Titre section : 15 px / 500

### Radius

- Page/modal : 12 px
- Boutons : 8 px
- Vignettes : 7 px
- Cards produit : 8 px
- Pills : 999 px

---

## 4. Structure générale

```text
PDP Desktop
├── Header compact
├── Zone principale produit
│   ├── Rail de miniatures
│   ├── Hero image
│   └── Panneau commercial
├── Suggestions
├── Contenu enrichi
│   ├── Points forts
│   ├── Caractéristiques
│   ├── Composition
│   ├── Entretien
│   └── À savoir
└── Footer éventuel de la modal
```

### Conteneur principal

```css
.pdp-desktop {
  width: min(1180px, calc(100vw - 48px));
  margin: 24px auto;
  background: var(--page-bg);
  border: 1px solid var(--border);
  border-radius: 12px;
  overflow: hidden;
}
```

La page peut être affichée en modal ou dans une route dédiée, mais la structure interne reste identique.

---

## 5. Header desktop

### Dimensions

- Hauteur : 52 px
- Padding horizontal : 18 px
- Background : `--page-bg`
- Bordure inférieure : `0.5px solid --border`

### Groupe gauche

- Bouton retour : icône 16 px, zone interactive 40 × 40 px
- Label `Catalogue` : 13 px / 500
- Breadcrumb facultatif : `Boutique › Sport`
- Le nom du produit ne doit pas être répété intégralement dans le breadcrumb

### Groupe droit

- Recherche : icône seule 36 × 36 px, uniquement si utile à la navigation catalogue
- Panier : 36 × 36 px avec badge dynamique
- Fermer : 36 × 36 px
- Écart : 6 à 8 px

### Règles de simplification

- Ne pas afficher avatar, navigation produit précédente/suivante et seconde paire de flèches simultanément.
- Si `totalProducts <= 1`, masquer toute navigation précédent/suivant.
- Le compteur `1 / N` appartient à la galerie, pas au header.

---

## 6. Zone principale produit

### Layout

À partir de 1024 px : grille à trois colonnes.

```css
.pdp-main {
  display: grid;
  grid-template-columns: 60px minmax(420px, 1fr) 310px;
  gap: 18px;
  padding: 18px;
  align-items: start;
}
```

À partir de 1440 px :

```css
.pdp-main {
  grid-template-columns: 64px minmax(480px, 1fr) 340px;
  gap: 22px;
  padding: 22px;
}
```

Le panneau commercial doit être visible sans scroll vertical sur un écran 1366 × 768 lorsque le produit possède un nombre standard de variantes.

---

## 7. Rail de miniatures

### Conteneur

- Largeur : 60 à 64 px
- Flex vertical
- Gap : 8 px
- Maximum 4 miniatures visibles dans la zone principale

### Miniature

- Taille : 60 × 60 px
- Background : blanc ou `--hero-bg`
- Border : `0.5px solid --border-strong`
- Radius : 7 px
- Image centrée, `object-fit: contain`

### État sélectionné

- Border : `1.5px solid --text-primary`
- Aucun glow excessif

### Plus d’images

Si le produit contient plus de 4 médias :

- afficher 3 miniatures ;
- la 4e tuile affiche `+N` ;
- tap/clic ouvre la lightbox ou développe le rail.

### Accessibilité

Chaque miniature doit avoir un `aria-label` explicite :

- `Vue 1 du produit`
- `Vue de profil`
- `Vue de la semelle`

---

## 8. Hero image desktop

### Conteneur

- Ratio recommandé : 4:3
- Hauteur cible : 390 à 470 px selon largeur
- Minimum : 360 px
- Maximum : 500 px
- Background : `--hero-bg`
- Radius : 10 px
- Position relative
- Overflow hidden

```css
.pdp-hero {
  aspect-ratio: 4 / 3;
  min-height: 360px;
  max-height: 500px;
}
```

### Image

- `width: 100%`
- `height: 100%`
- `object-fit: contain`
- Padding visuel interne : 24 à 36 px
- Ne jamais étirer l’image

### Meta décorative

En haut à gauche :

- `ELITE PRO`
- sous-titre optionnel `GOLDEN PERFORMANCE SERIES`

Même traitement que mobile, mais légèrement plus espacé.

### Overlays

- Bouton agrandir : bas gauche, 36 × 36 px
- Compteur : bas droite, pill `1 / 5`
- Masquer le compteur s’il n’y a qu’une image

### Interactions

- Clic image ou bouton agrandir → lightbox fullscreen
- Flèches clavier gauche/droite dans la lightbox
- `Esc` ferme la lightbox
- Zoom uniquement dans la lightbox, jamais dans la page principale

---

## 9. Panneau commercial

Le panneau commercial est prioritaire. Il ne doit jamais être remplacé par la fiche technique.

### Conteneur

```css
.pdp-buy-panel {
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-width: 0;
}
```

Sur écrans d’au moins 1200 px et si la page est scrollable :

```css
.pdp-buy-panel {
  position: sticky;
  top: 70px;
}
```

Le sticky est autorisé sur desktop, mais doit être désactivé si le composant est déjà dans une modal interne scrollable qui provoque des conflits.

### 9.1 Titre

- 18 px / 500
- Maximum 3 lignes
- Truncate seulement au-delà de 3 lignes

### 9.2 Référence

- `Réf. GOLD-BLU-44`
- 12 px / muted
- Margin-top : 2 px

### 9.3 Prix

- `45 000 KMF`
- Format via `Intl.NumberFormat('fr-KM')`
- Prix 28 px / 500
- Devise 13 px / 500

Le prix reste visible même lorsque le stock est nul.

### 9.4 Badge stock

Trois états identiques à la spécification mobile :

| Condition | Label |
|---|---|
| `stock > 5` | `En stock` ou `N en stock` |
| `1 <= stock <= 5` | `Plus que N` |
| `stock = 0` | `Épuisé` |

Le badge apparaît immédiatement sous ou à droite du prix.

### 9.5 Couleurs

- Label : `Couleur · Bleu`
- Vignettes : 42 × 42 px
- Maximum 5 visibles avant retour à la ligne
- Wrap autorisé sur desktop
- État sélectionné : bordure 1.5 px foncée
- Badge `HOT` facultatif

### 9.6 Tailles

- Label : `Taille · 44`
- Chips : minimum 42 × 38 px
- Wrap sur plusieurs lignes autorisé
- Indisponible : barrée et non cliquable
- Si une taille est obligatoire et non sélectionnée, les CTA sont désactivés

### 9.7 Quantité

La quantité n’apparaît pas dans le premier état si la variante n’est pas encore dans le panier.

- Avant ajout : deux CTA côte à côte
- Après ajout : stepper + CTA acheter

Cela doit rester cohérent avec la machine d’état mobile.

### 9.8 Boutons d’action

#### État `productInCart === false`

Rangée de deux boutons :

- `Ajouter au panier`
  - secondaire
  - fond blanc
  - bordure foncée
- `Acheter maintenant`
  - primaire
  - fond vert
  - texte blanc

Hauteur : 44 px
Gap : 8 px

#### État `productInCart === true`

- Stepper compact à gauche
- `Acheter maintenant` à droite

#### Rupture de stock

- Un seul bouton pleine largeur `Me prévenir`
- Prix et variantes restent visibles

---

## 10. Suggestions

La section apparaît immédiatement sous la zone principale produit.

### Conteneur

- Border-top : `0.5px dashed --border-strong`
- Padding : `14px 18px 18px`

### Header

- Titre : `Nos suggestions`
- Lien : `Voir tout ›`

### Grille

Desktop standard : 4 cartes visibles.

```css
.pdp-suggestions-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 10px;
}
```

Large desktop : 5 cartes possibles si la largeur le permet.

### Card

- Background image : `--hero-bg`
- Radius : 8 px
- Padding image : 12 px
- Titre : une ligne avec ellipsis
- Prix : ligne secondaire
- Toute la carte est cliquable

Ne pas transformer la section en carrousel horizontal sur desktop sauf en dessous de 1100 px.

---

## 11. Contenu enrichi

Le contenu enrichi apparaît après les suggestions, jamais dans le panneau commercial.

### Ordre

1. Points forts
2. Caractéristiques
3. Composition
4. Entretien
5. À savoir

### Layout

À partir de 1024 px : deux colonnes maximum.

```css
.pdp-details {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 16px 28px;
  padding: 22px;
}
```

Pour les tableaux de caractéristiques :

- label à gauche ;
- valeur à droite ;
- alignement lisible ;
- pas de lignes excessivement longues ;
- max-width des valeurs pour éviter qu’elles collent au bord droit.

### Accordéons

Sur desktop, les sections peuvent être ouvertes par défaut. L’accordéon reste facultatif si le contenu est très long.

---

## 12. Données et mapping

La page doit résoudre les données dans l’ordre suivant :

```text
Produit
  └── Variantes couleur
       └── Tailles
            └── SKU
                 ├── prix
                 ├── stock
                 ├── médias
                 └── disponibilité
```

### Règles

- Le panneau affiche les valeurs de la variante et de la taille sélectionnées.
- Un changement de couleur peut changer : image, SKU, prix, stock et tailles.
- Un changement de taille recalcule le stock et `productInCart`.
- Ne jamais déduire le stock du nombre de variantes.
- Ne jamais masquer le prix parce que `stock === 0`.
- Si aucune variante valide n’est sélectionnée, ne pas envoyer de requête panier.

### API

Réutiliser les stores, hooks, services et endpoints existants. Les noms de routes éventuels dans la spécification mobile sont indicatifs et ne justifient pas la création d’une seconde logique panier.

---

## 13. Machine d’état panier

Variables partagées mobile/desktop :

- `cartCount`
- `productInCart`
- `productQtyInCart`
- `selectedVariant`
- `selectedSize`
- `stock`

### États

```text
AVAILABLE_EMPTY
AVAILABLE_FILLED
OUT_OF_STOCK
SELECTION_REQUIRED
LOADING
ERROR
```

### Comportement

- `AVAILABLE_EMPTY` → Ajouter au panier + Acheter maintenant
- `AVAILABLE_FILLED` → Stepper + Acheter maintenant
- `OUT_OF_STOCK` → Me prévenir
- `SELECTION_REQUIRED` → CTA désactivés + indication de sélection
- `LOADING` → désactiver les doubles clics
- `ERROR` → revert optimiste + toast

---

## 14. Responsive desktop

### 1024 à 1199 px

```css
.pdp-main {
  grid-template-columns: 56px minmax(360px, 1fr) 280px;
  gap: 14px;
  padding: 14px;
}
```

- Titre 17 px
- Prix 26 px
- CTA peuvent passer sur deux lignes uniquement si nécessaire

### 1200 à 1439 px

Layout nominal.

### 1440 px et plus

- Max-width inchangé ou augmenté jusqu’à 1240 px
- Ne pas agrandir excessivement l’image
- Conserver des marges latérales confortables

### Hauteur limitée

Si hauteur viewport < 760 px :

- réduire les paddings verticaux ;
- hero minimum 340 px ;
- panneau commercial non sticky si cela provoque une coupure.

---

## 15. Accessibilité

- Tous les contrôles : focus visible
- Navigation clavier complète
- `Esc` ferme la modal ou la lightbox
- `Enter` et `Space` activent miniatures, variantes et CTA
- `aria-current="true"` sur miniature active
- `aria-pressed="true"` sur variante active
- `aria-disabled="true"` sur taille indisponible
- `aria-live="polite"` pour stock, prix et ajout panier
- Contraste AA minimum
- Les tooltips ne doivent pas contenir une information inaccessible autrement

---

## 16. Performance

- Charger en priorité l’image principale
- Lazy-load les images secondaires et suggestions
- Réserver la place des images pour éviter les layout shifts
- Utiliser `srcset`/`sizes`
- Ne pas importer toutes les icônes d’une librairie via CDN
- Épingler les versions de dépendances
- Respecter la CSP existante

---

## 17. Edge cases

- Une seule image : masquer `1 / 1`, garder agrandir
- Une seule couleur : masquer le bloc Couleur
- Aucune taille : masquer le bloc Taille
- Produit sans suggestions : masquer entièrement la section
- Nom très long : max 3 lignes desktop
- Plus de 10 tailles : wrap sur plusieurs lignes
- Variante épuisée mais autres disponibles : conserver la sélection et suggérer les alternatives disponibles
- Prix différent selon taille : mettre à jour immédiatement
- Image manquante : fallback illustré
- Erreur réseau : toast + état précédent restauré
- Produit déjà au panier avec quantité > stock : limiter la quantité et avertir

---

## 18. Tests attendus

### Visuels

- 1024 × 768
- 1366 × 768
- 1440 × 900
- 1920 × 1080

### Fonctionnels

- produit simple avec stock
- produit en rupture
- une seule image
- plusieurs images
- une seule couleur
- plusieurs couleurs
- plusieurs tailles
- taille obligatoire non sélectionnée
- changement de variante modifiant prix et stock
- ajout panier
- modification quantité
- achat immédiat
- suggestions absentes
- navigation clavier

### Non-régression

- aucun impact sur la spécification mobile validée
- aucune duplication de logique panier
- aucun masquage du prix ou du stock
- aucun double contrôle de navigation dans le header

---

## 19. Priorités de développement

1. **P0 — Layout desktop** : rail, hero, panneau commercial
2. **P0 — Données commerciales** : prix, stock, couleurs, tailles
3. **P0 — CTA et machine d’état panier**
4. **P1 — Suggestions**
5. **P1 — Déplacement du contenu enrichi sous la zone commerciale**
6. **P2 — Lightbox et navigation médias**
7. **P2 — Accessibilité clavier et lecteurs d’écran**
8. **P3 — Polish visuel et performance**

---

## 20. Critères d’acceptation

La version desktop est acceptée lorsque :

- le prix, le stock, les variantes et les CTA sont visibles sans scroll sur 1366 × 768 ;
- le rail de miniatures, l’image principale et le panneau commercial reproduisent la maquette validée ;
- la fiche technique n’occupe plus la place du panneau commercial ;
- les suggestions apparaissent sous la zone produit ;
- aucune navigation inutile ou doublonnée n’est affichée ;
- le stock nul affiche `Épuisé` et ne masque jamais le prix ;
- la logique panier est identique à la version mobile ;
- aucun comportement mobile validé n’est régressé.
