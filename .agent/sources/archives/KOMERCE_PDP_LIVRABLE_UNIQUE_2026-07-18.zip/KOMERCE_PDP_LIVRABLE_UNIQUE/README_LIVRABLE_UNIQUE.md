# KOMERCE — Livrable unique PDP mobile + desktop

**Date :** 18 juillet 2026  
**Contenu :** PDP-1 + PDP-2 + correctif final + spécifications + preuves de validation.

## Référence à appliquer

Le delta final directement applicable au dépôt se trouve dans :

`01_CODE_DELTA_A_APPLIQUER/`

Ce dossier conserve l'arborescence du dépôt, notamment :

- `public/boutique/index.html`
- `public/boutique/js/`
- `public/boutique/css/`
- `public/boutique/tests/unit/`

Superposer ce contenu à la racine du dépôt sur une branche dédiée.

## Sources de vérité

- `02_SPECS_SOURCE_DE_VERITE/pdp-mobile-spec.md`
- `02_SPECS_SOURCE_DE_VERITE/pdp-desktop-spec.md`
- `03_MAQUETTE_ET_CAPTURES/maquette-source-mobile-desktop.png`

## Statut de conformité

### Validé

- architecture commune mobile/desktop ;
- modèle simple conservé lorsque l'enrichissement est absent ;
- machine d'état du footer : panier vide, produit au panier, rupture ;
- rendu responsive mobile et desktop dans le harness Chromium ;
- câblage réel des deux renderers vers `renderPdpActions()` ;
- identité panier multi-variantes par `line_id` canonique ;
- ciblage correct des actions `+`, `−` et suppression ;
- absence de doublon d'identifiants HTML dans la livraison testée ;
- syntaxe JavaScript et contrôles ciblés validés.

### Portée exacte du contrôle visuel

Les captures fournies valident la structure, les proportions générales, les
breakpoints et les états fonctionnels. Le harness utilise des contenus et assets
de substitution. Il ne constitue donc pas une certification pixel-perfect à
100 % des images, textes et données réelles de production.

La conformité finale au mock avec les vrais assets doit être vérifiée après
superposition dans le dépôt complet et lancement de la boutique réelle.

## Contrôles obligatoires avant merge

À exécuter dans le dépôt complet après application du delta :

```bash
npm ci
npm test
npm run build
npm run css:guard
npm run css:specificity-guard
npm run boutique:audit
npm run predeploy
```

Selon le périmètre touché, exécuter également les gates de gouvernance habituels.

## Organisation

- `01_CODE_DELTA_A_APPLIQUER/` : code et tests finaux ;
- `02_SPECS_SOURCE_DE_VERITE/` : spécifications mobile et desktop ;
- `03_MAQUETTE_ET_CAPTURES/` : maquette et captures de validation ;
- `04_VALIDATION_ET_PREUVES/` : rapport final, diff et preuves techniques ;
- `05_HISTORIQUE_AUDIT/` : audits intermédiaires, uniquement pour traçabilité ;
- `SHA256SUMS.txt` : empreintes de tous les fichiers ;
- `MANIFEST.json` : inventaire machine-readable.
