/**
 * @component Boutique / Polish Bootstrap
 * @owner b-boutique-wow-style.js
 *
 * DÉSACTIVÉ — couche wow supprimée.
 * boutique-wow.css vidé. Styles migrés dans boutique-desktop.css.
 * hero-cart-proxy.css et desktop-commerce-skeleton.css chargés
 * directement via <link> dans index.html.
 *
 * Voir docs/BOUTIQUE_COMPONENT_OWNERSHIP.md
 */

'use strict';

export function setupBoutiqueWowStyle() {
  // no-op — wow layer removed
}
